//
//  AiDefence.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 11/02/2021.
//

import UIKit
import QuartzCore
import SceneKit

class AIDefence: SCNNode {

    func createDefenceForce() {
        
    }
    func retreat() {
        
    }
    
}
