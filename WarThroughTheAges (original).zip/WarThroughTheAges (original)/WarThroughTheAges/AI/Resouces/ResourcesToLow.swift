//
//  ResourcesToLow.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 11/02/2021.
//

import UIKit
import QuartzCore
import SceneKit

class ResourcesToLow: SCNNode {
//MARK:- THINGS TO DO
    // finish resoureces in all 3 classes including in Incomings timer
    // test 
    
    var foodLow = Bool()
    
    func measureResourceLevel(resource: Int) {
        
    }
}
class OutGoings {
    
   static var instance = OutGoings()
    var measureResources = false
    var food = Int()
    var coal = Int()
    var power = Int()
}
class Incomings {
    
   static var instance = Incomings()
    var food = Double()
    var coal = Double()
    var power = Double()
    var t = 0
    var intialFood: Double = 0
    
    func addUpResource() {
        
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { (timer) in
            self.t += 1
            if self.t == 300 {
                self.food = 0
                self.coal = 0
                self.power = 0
            }
            if  self.t % 2 == 0 {
                self.intialFood = Resource.instance.food
            }
            if self.t % 2 != 0 {
                self.food += Resource.instance.food - self.intialFood
            }
        }
    }
    
}
