//
//  CreayeArmyUnits.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 11/02/2021.
//

import UIKit
import QuartzCore
import SceneKit

class CreateArmyUnits: SCNNode {

    
    func createMaceMen() {
        
    }
    func craetePhallanx() {
        
    }
    func craeteAxeMen() {
        
    }
}
