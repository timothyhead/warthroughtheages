//
//  CreateCivillianUnits.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 11/02/2021.
//

import UIKit
import QuartzCore
import SceneKit

class CreateCivillianUnits: SCNNode {

    
    func createFarmWorker() {
        
    }
    func createHunter() {
        
    }
    func createGatherer() {
        
    }
    func createWoodsMan() {
        
    }
}
