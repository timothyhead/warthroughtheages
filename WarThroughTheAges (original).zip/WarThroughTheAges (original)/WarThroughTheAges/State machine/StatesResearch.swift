//
//  StatesResearch.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 18/02/2021.
//

import Foundation
import SceneKit




class StatesResearch: SCNNode {
    
    enum StoneTools {
        case none
        case oldStoneAge
        case newStoneAge
        case quarry
    }
    enum Agriculture {
        case none
        case beginningOfAgriculture
    }
    enum AnimalHusbandry {
        case none
        case beginningOfAnimalHusbandry
    }
    
    enum Irrigation {
        case none
        case beginningOfIrrigation
        case enginneredIrragation
    }
    enum Pottery {
        case none
        case beginningOfPottery
        case pottersWheel
    }
    enum Brick {
        case none
        case brick
    }
    enum Building {
        case none
        case beginningOfBuilding
    }
    enum Religion {
        case none
        case beginningOfReligion
    }
    enum Trade {
        case none
        case beginningOfTrade
    }
    enum Manufactoring {
        case none
        case beginningOfManufactoring
    }
    enum PackAnimals {
        case none
        case packAnimals
    }
    enum DugoutCannoes {
        case none
        case dugoutCanoe
    }
    enum Sail {
        case none
        case sail
    }
    enum Metallurgy {
        case none
        case beginningOfMetallurgy
        case metallurgy
    }
    enum Literacy {
        case none
        case literacy
    }
    enum Numeracy {
        case none
        case numeracy
    }
    enum Science {
        case none
        case science
    }
    enum Physics {
        case none
        case physics
    }
    enum Engineering {
        case none
        case engineering
    }
    enum LegalCode {
        case none
        case legalCode
    }
    enum SeaGoingVessel {
        case none
        case seaGoingVessel
    }
    enum Chemistry {
        case none
        case chemistry
    }
    enum BronzeWorking {
        case none
        case bronzeworking
    }
    enum IronWorking {
        case none
        case ironWorking
    }
    enum OilProduction {
        case none
        case oilProduction
    }
    enum PlasticProduction {
        case none
        case plasticProduction
    }
    enum SteelProduction {
        case none
        case steelProduction
    }
    
    var researching = Bool()
    var modifier: TimeInterval = 1
    var stone: StoneTools = .none
    var farming: Agriculture = .none
    var animals: AnimalHusbandry = .none
    var irrigation: Irrigation = .none
    var pottery: Pottery = .none
    var brick: Brick = .none
    var building: Building = .none
    var religion: Religion = .none
    var trade: Trade = .none
    var manufactoring: Manufactoring = .none
    var packAnimals: PackAnimals = .none
    var dugoutCanoe: DugoutCannoes = .none
    var sail: Sail = .none
    var metallurgy: Metallurgy = .none
    var bronzeWorking: BronzeWorking = .none
    var literacy: Literacy = .none
    var numeracy: Numeracy = .none
    var science: Science = .none
    var physics: Physics = .none
    var engineering: Engineering = .none
    var legalCode: LegalCode = .none
    var seaGoingVessel: SeaGoingVessel = .none
    var chemistry: Chemistry = .none
    var ironWorking: IronWorking = .none
    var oilProduction: OilProduction = . none
    var plasticProduction : PlasticProduction  = .none
    var steelProduction: SteelProduction = .none
    var currentlyResearching = CurrentlyResearching.none
    var hasCompletedReseach = Bool()

    
    func researchStone() {
        if researching {
            return
        }
        currentlyResearching = .stone
        switch stone {
        case .none:
            timing1(t: Data.instance.oldStoneAgeResearchTime, newState: .oldStoneAge)
        case .oldStoneAge:
            timing1(t: Data.instance.newStoneAgeResearchTime, newState: .newStoneAge)
        case .newStoneAge:
            timing1(t: Data.instance.quarryResearchTime, newState: .quarry)
        default:
            break
        }
    }
    func timing1(t: TimeInterval, newState: StoneTools) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier , repeats: true) { (timer) in
            self.stone = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchAgricultue() {
        if researching {
            return
        }
        currentlyResearching = .agriculture
        if stone == .newStoneAge || stone == .quarry {
        switch farming {
        case .none:
            timing2(t: Data.instance.beginningOfAgricultureResearchTime, newState: .beginningOfAgriculture)
        default:
            break
        }
    }
    }
    func timing2(t: TimeInterval, newState: Agriculture) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.farming = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchAnimalHusbandry() {
        if researching {
            return
        }
        currentlyResearching = .animalHusbandry
        if stone == .newStoneAge || stone == .quarry {
        switch animals {
        case .none:
            timing3(t: Data.instance.beginningOfAnimalHusbandryResearchTime, newState: .beginningOfAnimalHusbandry)
        default:
            break
        }
        } 
    }
    func timing3(t: TimeInterval, newState: AnimalHusbandry) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.animals = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchIrrigation() {
        if researching {
            return
        }
        currentlyResearching = .irrigation
        if farming == .beginningOfAgriculture {
        switch irrigation {
        case .none:
            timing4(t: Data.instance.beginningOfIrrigationResearchTime, newState: .beginningOfIrrigation)
        case .beginningOfIrrigation:
            timing4(t: Data.instance.enginneredIrragationReasearchTime, newState: .enginneredIrragation)
        default:
            break
        }
        }
    }
    func timing4(t: TimeInterval, newState: Irrigation) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier , repeats: true) { (timer) in
            self.irrigation = newState
       
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchPottery() {
        if researching {
            return
        }
        currentlyResearching = .pottery
        if stone == .newStoneAge || stone == .quarry {
        switch pottery {
        case .none:
            timing5(t: Data.instance.beginningOfPotteryResearchTime, newState: .beginningOfPottery)
        case .beginningOfPottery:
            timing5(t: Data.instance.pottersWheelResearchTime, newState: .pottersWheel)
        default:
            break
        }
    }
    }
    func timing5(t: TimeInterval, newState: Pottery) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.pottery = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchBrick() {
        if researching {
            return
        }
        currentlyResearching = .brick
        if pottery == .beginningOfPottery || pottery == .pottersWheel {
        switch brick {
        case .none:
            timing6(t: Data.instance.brickResearchTime, newState: .brick)
        default:
            break
        }
    }
    }
    func timing6(t: TimeInterval, newState: Brick) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.brick = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchBuilding() {
        if researching {
            return
        }
        currentlyResearching = .building
        if brick == .brick {
        switch building {
        case .none:
            timing7(t: Data.instance.beginningOfBuildingResearchTime, newState: .beginningOfBuilding)
        default:
            break
        }
    }
    }
    func timing7(t: TimeInterval, newState: Building) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.building = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchReligion() {
        if researching {
            return
        }
        currentlyResearching = .religion
        if building == .beginningOfBuilding {
        switch religion {
        case .none:
            timing8(t: Data.instance.beginningOfReligionResearchTime, newState: .beginningOfReligion)
        default:
            break
        }
    }
    }
    func timing8(t: TimeInterval, newState: Religion) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.religion = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchTrade() {
        if researching {
            return
        }
        currentlyResearching = .trade
        if stone == .newStoneAge || stone == .quarry {
        switch trade {
        case .none:
            timing9(t: Data.instance.beginningOfTradeResearchTime, newState: .beginningOfTrade)
        default:
            break
        }
    }
    }
    func timing9(t: TimeInterval, newState: Trade) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.trade = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchManufactoring() {
        if researching {
            return
        }
        currentlyResearching = .manufactoring
        if stone == .newStoneAge || stone == .quarry {
        switch manufactoring {
        case .none:
            timing10(t: Data.instance.beginningOfManufactoringResearchTime, newState: .beginningOfManufactoring)
        default:
            break
        }
    }
    }
    func timing10(t: TimeInterval, newState: Manufactoring) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.manufactoring = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchPackAnimals() {
        if researching {
            return
        }
        currentlyResearching = .packAnimals
        if stone == .newStoneAge || stone == .quarry {
        switch packAnimals {
        case .none:
            timing11(t: Data.instance.packAnimalsResearchTime, newState: .packAnimals)
            default:
                break
        }
    }
    }
    func timing11(t: TimeInterval, newState: PackAnimals) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.packAnimals = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchDugoutCanoe() {
        if researching {
            return
        }
        currentlyResearching = .dugoutCanoe
        if stone == .newStoneAge || stone == .quarry {
        switch dugoutCanoe {
        case .none:
            timing12(t: Data.instance.dugoutCanoeResearchTime, newState: .dugoutCanoe)
        default:
            break
        }
    }
    }
    func timing12(t: TimeInterval, newState: DugoutCannoes) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.dugoutCanoe = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchSail() {
        if researching {
            return
        }
        currentlyResearching = .sail
        if science == .science {
        switch sail {
        case .none:
            timing13(t: Data.instance.sailResearchTime, newState: .sail)
        default:
            break
        }
    }
    }
    func timing13(t: TimeInterval, newState: Sail) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.sail = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchMetallurgy() {
        if researching {
            return
        }
        currentlyResearching = .metallurgy
        if manufactoring == .beginningOfManufactoring {
        switch  metallurgy {
        case .none:
            timing14(t: Data.instance.beginningOfMetallurgyResearchTime, newState: .beginningOfMetallurgy)
        case .beginningOfMetallurgy:
            timing14(t: Data.instance.metallurgyResearchTime, newState: .metallurgy)
        default:
            break
        }
    }
    }
    func timing14(t: TimeInterval, newState: Metallurgy) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.metallurgy = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchBronzeWorking() {
        if researching {
            return
        }
        currentlyResearching = .bronzeWorking
        if metallurgy == .metallurgy {
        switch bronzeWorking {
        case .none:
            timing27(t: Data.instance.bronzeworkingResearchTime, newState: .bronzeworking)
        default:
            break
        }
    }
    }
    func timing27(t: TimeInterval, newState: BronzeWorking) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier , repeats: true) { (timer) in
            self.bronzeWorking = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
   
    func researchLiteracy() {
        if researching {
            return
        }
        currentlyResearching = .literacy
        if metallurgy == .metallurgy {
        switch literacy {
        case .none:
            timing15(t: Data.instance.literacyResearchTime, newState: .literacy)
        default:
            break
        }
    }
    }
    func timing15(t: TimeInterval, newState: Literacy) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.literacy = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchNumeracy() {
        if researching {
            return
        }
        currentlyResearching = .metallurgy
        if metallurgy == .metallurgy {
        switch numeracy {
        case .none:
            timing16(t: Data.instance.numeracyResearchTime, newState: .numeracy)
        default:
            break
        }
    }
    }
    func timing16(t: TimeInterval, newState: Numeracy) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.numeracy = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchScience() {
        if researching {
            return
        }
        currentlyResearching = .science
        if literacy == .literacy && numeracy == .numeracy {
        switch science {
        case .none:
            timing17(t: Data.instance.scienceResearchTime, newState: .science)
        default:
            break
        }
    }
}
    func timing17(t: TimeInterval, newState: Science) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.science = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchPhysics() {
        if researching {
            return
        }
        currentlyResearching = .physics
        if science == .science {
        switch physics {
        case .none:
            timing18(t: Data.instance.physicsResearchTime, newState: .physics)
        default:
            break
        }
    }
    }
    func timing18(t: TimeInterval, newState: Physics) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.physics = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchEngineering() {
        if researching {
            return
        }
        currentlyResearching = .engineering
        if physics == .physics {
        switch engineering {
        case .none:
            timing19(t: Data.instance.engineeringResearchTime, newState: .engineering)
        default:
            break
        }
    }
    }
    func timing19(t: TimeInterval, newState: Engineering) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.engineering = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchLegalCode() {
        if researching {
            return
        }
        currentlyResearching = .legalCode
        if science == .science {
        switch legalCode {
        case .none:
            timing20(t: Data.instance.legalCodeResearchTime, newState: .legalCode)
        default:
            break
        }
    }
    }
    func timing20(t: TimeInterval, newState: LegalCode) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.legalCode = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchSeaGoingVessel() {
        if researching {
            return
        }
        currentlyResearching = .seaGoingVessel
        if sail == .sail {
        switch seaGoingVessel {
        case .none:
            timing21(t: Data.instance.seaGoingVesselResearchTime, newState: .seaGoingVessel)
        default:
            break
        }
    }
    }
    func timing21(t: TimeInterval, newState: SeaGoingVessel) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.seaGoingVessel = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchChemistry() {
        if researching {
            return
        }
        currentlyResearching = .chemistry
        if science == .science {
        switch chemistry {
        case .none:
            timing22(t: Data.instance.chemistryResearchTime, newState: .chemistry)
        default:
            break
        }
    }
    }
    func timing22(t: TimeInterval, newState: Chemistry) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.chemistry = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchIronWorking() {
        if researching {
            return
        }
        currentlyResearching = .ironWorking
        if bronzeWorking == .bronzeworking {
        switch ironWorking {
        case .none:
            timing23(t: Data.instance.ironWorkingResearchTime, newState: .ironWorking)
        default:
            break
        }
    }
    }
    func timing23(t: TimeInterval, newState: IronWorking) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.ironWorking = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchOilProduction() {
        if researching {
            return
        }
        currentlyResearching = .oilProduction
        if chemistry == .chemistry {
        switch oilProduction {
        case .none:
            timing24(t: Data.instance.oilProductionResearchTime, newState: .oilProduction)
        default:
            break
        }
    }
    }
    func timing24(t: TimeInterval, newState: OilProduction) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.oilProduction = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchPlasticProduction() {
        if researching {
            return
        }
        currentlyResearching = .plasticProduction
        if oilProduction == .oilProduction {
        switch plasticProduction {
        case .none:
            timing25(t: Data.instance.plasticProductionResearchTime, newState: .plasticProduction)
        default:
            break
        }
    }
    }
    func timing25(t: TimeInterval, newState: PlasticProduction) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.plasticProduction = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
    func researchSteelProduction() {
        if researching {
            return
        }
        currentlyResearching = .steel
        if ironWorking == .ironWorking {
        switch steelProduction {
        case .none:
            timing26(t: Data.instance.steelProductionResearchTime, newState: .steelProduction)
        default:
            break
        }
    }
    }
    func timing26(t: TimeInterval, newState: SteelProduction) {
        researching = true
        Timer.scheduledTimer(withTimeInterval: t * modifier, repeats: true) { (timer) in
            self.steelProduction = newState
            self.researching = false
            self.hasCompletedReseach = true
            timer.invalidate()
        }
    }
}
