//
//  States.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 16/02/2021.
//

import Foundation
import SceneKit
//MARK: - THING TO DO
// set duration for action in  case .chooseResourceLocationInitialy using speed of villager and distance
class StatesVillager: SCNNode {
    enum State {
        case none
        case chooseResourceLocationInitialy
        case goingToResources
        case collectingResources
        case goingToNearestDepositry
        case examineDepositryExistance
        case inactive
    }
    var currentState: State
    var obj = Node()
    var movementConstant: Float = 10
    var selectedResourceBuildingExists = Bool()
    var depositryExists = Bool()
    
    
    
    init(currentState: State) {
        self.currentState = currentState
        super.init()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func work(node: SCNNode, selectedResourceBuilding: SCNNode, depositry: SCNNode?) {
        if currentState == .none  {
            return
        }
        let node = node as! Villager
        obj.node = node
        obj.selectedResourceBuilding = selectedResourceBuilding
        if let depositry = depositry {
            obj.depositry = depositry
            
        }
        let find = Distance()
        let movementSpeed =  (find.distance(firstNode: selectedResourceBuilding, secondNode: depositry!) * node.movementSpeed)
        if currentState  == .goingToResources {
            for obj in GameViewController.world.childNodes {
                if obj.name == selectedResourceBuilding.name {
                    selectedResourceBuildingExists = true
                }
            }
            if selectedResourceBuildingExists == false  {
                return
            }
            let action = SCNAction.move(to: selectedResourceBuilding.position, duration: TimeInterval(movementSpeed))
            node.runAction(action) {
                self.currentState = .collectingResources
                self.work(node: node, selectedResourceBuilding: selectedResourceBuilding, depositry: depositry)
            }
            
        } else if currentState == .collectingResources
        {
            
            Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { (timer) in
                node.amountOfResourceGathered += 1
                if node.amountOfResourceGathered == node.maxiumResorceGathered {
                    self.currentState = .examineDepositryExistance
                    self.work(node: node, selectedResourceBuilding: selectedResourceBuilding, depositry: depositry)
                    timer.invalidate()
                }
            }
        } else if currentState == .goingToNearestDepositry {
            let action2 = SCNAction.move(to: depositry!.position, duration: TimeInterval(movementSpeed))
            DispatchQueue.main.async {
                node.runAction(action2) {
                    if let storage = GameViewController.world.childNode(withName:(depositry?.name!)!, recursively: true) as? Storage {
                        
                        self.currentState = .goingToResources
                        storage.maxUnits = storage.maxiumumUnitsStored
                        switch node.role {
                        case .food:
                            if storage.numberOFUnitsStored.food >= storage.maxStored.food || storage.currentStorageUnits >= storage.maxStored.food {
                                self.currentState = .none
                                return
                                
                            }
                            Resource.instance.food += node.amountOfResourceGathered
                            storage.numberOFUnitsStored.food += node.amountOfResourceGathered
                            storage.currentStorageUnits += node.amountOfResourceGathered
                            
                        case .coal:
                            if storage.numberOFUnitsStored.coal >= storage.maxStored.coal || storage.currentStorageUnits >= storage.maxStored.coal{
                                self.currentState = .none
                                return
                            }
                            Resource.instance.coal += node.amountOfResourceGathered
                            storage.numberOFUnitsStored.coal += node.amountOfResourceGathered
                            storage.currentStorageUnits += node.amountOfResourceGathered
                            
                        case .power:
                            if storage.numberOFUnitsStored.power >= storage.maxStored.power || storage.currentStorageUnits >= storage.maxStored.power {
                                self.currentState = .none
                                return
                                
                            }
                            Resource.instance.power += node.amountOfResourceGathered
                            storage.numberOFUnitsStored.power += node.amountOfResourceGathered
                            storage.currentStorageUnits += node.amountOfResourceGathered
                            
                        case .stone:
                            if storage.numberOFUnitsStored.stone >= storage.maxStored.stone || storage.currentStorageUnits >= storage.maxStored.stone {
                                self.currentState = .none
                                return
                            }
                            Resource.instance.stone += node.amountOfResourceGathered
                            storage.numberOFUnitsStored.stone += node.amountOfResourceGathered
                            storage.currentStorageUnits += node.amountOfResourceGathered
                        case .clay:
                            if storage.numberOFUnitsStored.clay >= storage.maxStored.clay || storage.currentStorageUnits >= storage.maxStored.clay{
                                self.currentState = .none
                                Resource.instance.clay += node.amountOfResourceGathered
                                storage.numberOFUnitsStored.clay += node.amountOfResourceGathered
                                storage.currentStorageUnits += node.amountOfResourceGathered
                                
                            }
                            
                        case .gold:
                            if storage.numberOFUnitsStored.gold >= storage.maxStored.gold || storage.currentStorageUnits >= storage.maxStored.gold{
                                self.currentState = .none
                                return
                                
                            }
                            Resource.instance.gold += node.amountOfResourceGathered
                            storage.numberOFUnitsStored.gold += node.amountOfResourceGathered
                            storage.currentStorageUnits += node.amountOfResourceGathered
                            
                        case .silver:
                            if storage.numberOFUnitsStored.silver >= storage.maxStored.silver || storage.currentStorageUnits >= storage.maxStored.silver{
                                self.currentState = .none
                                return
                                
                            }
                            Resource.instance.silver  += node.amountOfResourceGathered
                            storage.numberOFUnitsStored.silver += node.amountOfResourceGathered
                            storage.currentStorageUnits += node.amountOfResourceGathered
                            
                        case .copper:
                            if storage.numberOFUnitsStored.copper >= storage.maxStored.copper || storage.currentStorageUnits >= storage.maxStored.copper{
                                self.currentState = .none
                                return
                                
                            }
                            Resource.instance.copper += node.amountOfResourceGathered
                            storage.numberOFUnitsStored.copper += node.amountOfResourceGathered
                            storage.currentStorageUnits += node.amountOfResourceGathered
                            
                        case .tin:
                            
                            if  storage.numberOFUnitsStored.tin >= storage.maxStored.tin || storage.currentStorageUnits >= storage.maxStored.tin {
                                self.currentState = .none
                                return
                                
                            }
                            Resource.instance.tin += node.amountOfResourceGathered
                            storage.numberOFUnitsStored.tin += node.amountOfResourceGathered
                            storage.currentStorageUnits += node.amountOfResourceGathered
                            
                        case .bronze:
                            if storage.numberOFUnitsStored.bronze >= storage.maxStored.bronze || storage.currentStorageUnits >= storage.maxStored.bronze {
                                self.currentState = .none
                                return
                            }
                            Resource.instance.bronze += node.amountOfResourceGathered
                            storage.numberOFUnitsStored.bronze += node.amountOfResourceGathered
                            storage.currentStorageUnits += node.amountOfResourceGathered
                        case .iron:
                            if  storage.numberOFUnitsStored.iron >= storage.maxStored.iron || storage.currentStorageUnits >= storage.maxStored.iron {
                                self.currentState = .none
                                return
                            }
                            Resource.instance.iron += node.amountOfResourceGathered
                            storage.numberOFUnitsStored.iron += node.amountOfResourceGathered
                            storage.currentStorageUnits += node.amountOfResourceGathered
                        case .leather:
                            
                            if storage.numberOFUnitsStored.leather >= storage.maxStored.leather || storage.currentStorageUnits >= storage.maxStored.leather {
                                self.currentState = .none
                                return
                            }
                            Resource.instance.leather += node.amountOfResourceGathered
                            storage.numberOFUnitsStored.leather += node.amountOfResourceGathered
                            storage.currentStorageUnits += node.amountOfResourceGathered
                            
                        case .textiles:
                            
                            if storage.numberOFUnitsStored.textiles >= storage.maxStored.textiles || storage.currentStorageUnits >= storage.maxStored.textiles{
                                self.currentState = .none
                                return
                                
                            }
                            Resource.instance.textiles += node.amountOfResourceGathered
                            storage.numberOFUnitsStored.textiles += node.amountOfResourceGathered
                            storage.currentStorageUnits += node.amountOfResourceGathered
                            
                        default:
                            break
                        }
                        
                        node.amountOfResourceGathered = 0
                        self.work(node: node, selectedResourceBuilding: selectedResourceBuilding, depositry: depositry)
                    }
                }
            }
            
        } else if currentState == .examineDepositryExistance {
            
            
            if let node = node as? VillagerPlayer
            {
                let nearestDepositry = node.findNearestStore()
                currentState = .goingToNearestDepositry
                self.work(node: node, selectedResourceBuilding: selectedResourceBuilding, depositry: nearestDepositry)
                
            }
            if let node = node as? VillagerComputer
            {
                let nearestDepositry = node.findNearestStore()
                currentState = .goingToNearestDepositry
                self.work(node: node, selectedResourceBuilding: selectedResourceBuilding, depositry: nearestDepositry)
                
            }
            
            
            
            
        }
        
    }
    override func updateDelta(delta: TimeInterval) {
        super.updateDelta(delta: delta)
        
        if  currentState == .none {
            if let depositry = obj.depositry as? Storage  {
                if (GameViewController.world.childNode(withName:(depositry.name!), recursively: true) as? Storage) != nil {
                    if let node = obj.node as? VillagerPlayer {
                            let nearestDepositry = node.findNearestStore()
                        if nearestDepositry.name == obj.depositry?.name {
                                node.leaveBuilding.currentState = .leaving
                                node.leaveBuilding.leave(unit: node, inBuilding: nearestDepositry)
                                currentState = .inactive
                            }
                        }
                        if let node = obj.node as? VillagerComputer {
                            if node.leaveBuilding.currentState == .none {
                                return
                            }
                            let nearestDepositry = node.findNearestStore()
                            if nearestDepositry.name == obj.depositry?.name {
                                node.leaveBuilding.currentState = .leaving
                                node.leaveBuilding.leave(unit: node, inBuilding: nearestDepositry)
                                currentState = .inactive
                            }
                        }
                    }
                }
        }
            if currentState == .inactive {
                if (obj.depositry as? Storage) != nil {
                        depositryExists = true
                    }
                
                if let objs = obj.depositry as? Storage {
                    if depositryExists == false || objs.currentStorageUnits < objs.maxUnits {
                        if let node = obj.node as? VillagerPlayer {
                            let nearestDepositry = node.findNearestStore()
                            currentState = .goingToNearestDepositry
                            
                            self.work(node: node, selectedResourceBuilding: obj.selectedResourceBuilding, depositry: nearestDepositry)
                            
                        }
                        if let node = obj.node as? VillagerComputer
                        {
                            let nearestDepositry = node.findNearestStore()
                            currentState = .goingToNearestDepositry
                            self.work(node: node, selectedResourceBuilding: obj.selectedResourceBuilding, depositry: nearestDepositry)
                        
                        }
                } else {
                    return
                }
                        }
               
            }
            
        
    }
    
    
    
    class Node: SCNNode {
        var node = SCNNode()
        var selectedResourceBuilding = SCNNode()
        var depositry: SCNNode?
    }
}


