//
//  ResearchPlayer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 19/02/2021.
//
//
//  ResearchPlayer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 19/02/2021.
//

import Foundation

class StatesResearchPlayer: StatesResearch {
    
    var canBuildHunter = Bool()
    var canBuildVillager = Bool()
    var canBuildPackAnimals = Bool()
    var canBuildVillageHall = Bool()
    var canBuildSmallTownHall = Bool()
    var canBuildMediumTownHall = Bool()
    var canBuildLargeTownHall = Bool()
    var canBuildSmallCastle = Bool()
    var canBuildMediumCastle = Bool()
    var canBuildLargeCastle = Bool()
    var canBuildFarm = Bool()
    var canBuildClayPit = Bool()
    var canBuildStoneQuarry = Bool()
    var canBuildCopperMine = Bool()
    var canBuildTinMine = Bool()
    var canBuildGoldMine = Bool()
    var canBuildSilverMine = Bool()
    var canBuildCoalMine = Bool()
    var canBuildIronMine = Bool()
    var canBuildOilWell = Bool()
    var canBuildGrannary = Bool()
    var canBuildWoodHut = Bool()
    var canBuildLeatherShop = Bool()
    var canBuildClayCellar = Bool()
    var canBuildCoalBunker = Bool()
    var canBuildCopperHut = Bool()
    var canBuildTinHut = Bool()
    var canBuildBronzeHut = Bool()
    var canBuildIronHut = Bool()
    var canBuildGoldAndSilverDepositry = Bool()
    var canBuildPlasticContainers = Bool()
    var canBuildTextileRoom = Bool()
    var canBuildBarracks = Bool()
    var canBuildSeigeWorkShop = Bool()
    
    override func researchStone() {
        if researching {
            return
        }
        
        if ResourcePlayer.instance.food >= Data.instance.oldStoneAgeResearchCost.food! && ResourcePlayer.instance.stone >= Data.instance.oldStoneAgeResearchCost.stone! && stone == .none {
            super.researchStone()
          
          
        }
        
        if ResourcePlayer.instance.food >= Data.instance.newStoneAgeResearchCost.food! && ResourcePlayer.instance.stone >= Data.instance.newStoneAgeResearchCost.stone! && Resource.instance.wood >= Data.instance.newStoneAgeResearchCost.wood! && stone == .oldStoneAge {
            super.researchStone()
        }
        if ResourcePlayer.instance.food >= Data.instance.quarryResearchCost.food! && ResourcePlayer.instance.wood >= Data.instance.quarryResearchCost.wood! && ResourcePlayer.instance.bronze >= Data.instance.quarryResearchCost.bronze! && stone == .newStoneAge {
            super.researchStone()
            
            
            
        }
    }
  
    override func researchAgricultue() {
        if researching {
            return
        }
        if ResourcePlayer.instance.food >= Data.instance.beginningOfAgricultureResearchCost.food! && ResourcePlayer.instance.wood >= Data.instance.beginningOfAgricultureResearchCost.wood! && ResourcePlayer.instance.stone >= Data.instance.beginningOfAgricultureResearchCost.stone! && farming == .none {
            super.researchAgricultue()
         
        }
    }
    override func researchAnimalHusbandry() {
        if researching {
            return
        }
        if ResourcePlayer.instance.food >= Data.instance.beginningOfAnimalHusbandryResearchCost.food! && ResourcePlayer.instance.wood >= Data.instance.beginningOfAnimalHusbandryResearchCost.wood! && ResourcePlayer.instance.stone >= Data.instance.beginningOfAnimalHusbandryResearchCost.stone! &&
            animals == .none {
            super.researchAnimalHusbandry()
           
        }
    }
    
    override func researchIrrigation() {
        if researching {
            return
        }
        if ResourcePlayer.instance.food >= Data.instance.beginningOfIrrigationResearchCost.food! &&
            ResourcePlayer.instance.wood >= Data.instance.beginningOfIrrigationResearchCost.wood! &&
            ResourcePlayer.instance.stone >= Data.instance.beginningOfIrrigationResearchCost.stone! && irrigation == .none {
            super.researchIrrigation()
       
        }
        if ResourcePlayer.instance.food >= Data.instance.enginneredIrragationReasearchCost.food! &&
            ResourcePlayer.instance.wood >= Data.instance.enginneredIrragationReasearchCost.wood! &&
            ResourcePlayer.instance.stone >= Data.instance.enginneredIrragationReasearchCost.stone! && ResourcePlayer.instance.bronze >= Data.instance.enginneredIrragationReasearchCost.bronze! && irrigation == .beginningOfIrrigation && engineering == .engineering {
            super.researchIrrigation()
           
        } 
    }
    override func researchPottery() {
        if researching {
            return
        }
        if ResourcePlayer.instance.food >= Data.instance.beginningOfPotteryResearchCost.food! &&
            ResourcePlayer.instance.wood >= Data.instance.beginningOfPotteryResearchCost.wood! &&
            ResourcePlayer.instance.stone >= Data.instance.beginningOfPotteryResearchCost.stone! && ResourcePlayer.instance.clay >= Data.init().beginningOfPotteryResearchCost.clay! &&
            pottery == .none {
            super.researchPottery()
            
            
        }
        if ResourcePlayer.instance.food >= Data.instance.pottersWheelResearchCost.food! &&
            ResourcePlayer.instance.wood >= Data.instance.pottersWheelResearchCost.wood! &&
            ResourcePlayer.instance.stone >= Data.instance.pottersWheelResearchCost.stone! && ResourcePlayer.instance.bronze >= Data.instance.pottersWheelResearchCost.bronze! && ResourcePlayer.instance.clay >= Data.instance.pottersWheelResearchCost.clay! && pottery == .beginningOfPottery {
            super.researchPottery()
           
        }
    }
    override func researchBrick() {
        if researching {
            return
        }
        if ResourcePlayer.instance.food >= Data.instance.brickResearchCost.food! &&
            ResourcePlayer.instance.clay >= Data.instance.brickResearchCost.clay! && ResourcePlayer.instance.stone >= Data.instance.brickResearchCost.stone! && brick == .none {
            super.researchBrick()
            
        }
    }
    override func researchBuilding() {
        if researching {
            return
        }
        if ResourcePlayer.instance.food >= Data.instance.beginningOfBuildingResearchCost.food! &&
            ResourcePlayer.instance.clay >= Data.instance.beginningOfBuildingResearchCost.clay! &&
            ResourcePlayer.instance.wood >= Data.instance.beginningOfBuildingResearchCost.wood! && ResourcePlayer.instance.stone >= Data.instance.beginningOfBuildingResearchCost.stone! && building == .none {
            super.researchBuilding()
           
            
        }
    }
    override func researchReligion() {
        if researching {
            return
        }
        if ResourcePlayer.instance.food >= Data.instance.beginningOfReligionResearchCost.food! &&
            ResourcePlayer.instance.stone >= Data.instance.beginningOfReligionResearchCost.stone! && religion == .none {
            super.researchReligion()
            
        }
    }
    override func researchTrade() {
        if researching {
            return
        }
        if ResourcePlayer.instance.food >= Data.instance.beginningOfTradeResearchCost.food! &&
            ResourcePlayer.instance.clay >= Data.instance.beginningOfTradeResearchCost.clay! &&
            ResourcePlayer.instance.gold >= Data.instance.beginningOfTradeResearchCost.gold! && ResourcePlayer.instance.silver >= Data.instance.beginningOfTradeResearchCost.silver! && ResourcePlayer.instance.copper >= Data.instance.beginningOfTradeResearchCost.copper! && ResourcePlayer.instance.tin >= Data.instance.beginningOfTradeResearchCost.tin! && ResourcePlayer.instance.textiles >= Data.instance.beginningOfTradeResearchCost.textiles! && trade == .none {
            super.researchTrade()
            
        }
    }
    override func researchManufactoring() {
        if researching {
            return
        }
        if ResourcePlayer.instance.food >= Data.instance.beginningOfManufactoringResearchCost.food! &&
            ResourcePlayer.instance.clay >= Data.instance.beginningOfManufactoringResearchCost.clay!  && ResourcePlayer.instance.textiles >= Data.instance.beginningOfManufactoringResearchCost.textiles! && manufactoring == .none {
            super.researchManufactoring()
           
        }
    }
    override func researchPackAnimals() {
        if researching {
            return
        }
        if ResourcePlayer.instance.food >= Data.instance.packAnimalsResearchCost.food! && packAnimals == .none {
            super.researchPackAnimals()
          
            
        }
    }
    override func researchDugoutCanoe() {
        if researching {
            return
        }
        if ResourcePlayer.instance.wood >= Data.instance.dugoutCanoeResearchCost.wood! && dugoutCanoe == .none {
            super.researchDugoutCanoe()
        
        }
    }
    override func researchSail() {
        if researching {
            return
        }
        if ResourcePlayer.instance.wood >= Data.instance.sailResearchCost.wood! &&
            ResourcePlayer.instance.textiles >= Data.instance.sailResearchCost.textiles! && sail == .none {
            super.researchSail()
           
        }
        
    }
    override func researchMetallurgy() {
        if researching {
            return
        }
        if  ResourcePlayer.instance.silver >= Data.instance.beginningOfMetallurgyResearchCost.silver! && ResourcePlayer.instance.gold >= Data.instance.beginningOfMetallurgyResearchCost.gold! && metallurgy == .none {
            super.researchMetallurgy()
         
            
        }
        if ResourcePlayer.instance.copper >= Data.instance.metallurgyResearchCost .copper! && ResourcePlayer.instance.tin >= Data.instance.metallurgyResearchCost.tin! && metallurgy == .beginningOfMetallurgy {
            super.researchMetallurgy()
            
        }
    }
    override func researchBronzeWorking() {
        if researching {
            return
        }
        if ResourcePlayer.instance.bronze >= Data.instance.bronzeworkingResearchCost.bronze! && bronzeWorking == .none {
            super.researchBronzeWorking()
          
        }
    }
    override func researchLiteracy() {
        if researching {
            return
        }
        if Resource.instance.wood >= Data.instance.literacyResearchCost.wood! && Resource.instance.clay >= Data.instance.literacyResearchCost.clay! && literacy == .none {
            super.researchLiteracy()
          
        }
    }
    override func researchNumeracy() {
        if researching {
            return
        }
        if Resource.instance.wood >= Data.instance.numeracyResearchCost.wood! &&
            Resource.instance.clay >= Data.instance.numeracyResearchCost.clay! && numeracy == .none {
            super.researchNumeracy()
            
        }
    }
    override func researchScience() {
        if researching {
            return
        }
        if Resource.instance.gold >= Data.instance.scienceResearchCost.gold! && science == .none {
            super.researchScience()
           
        }
    }
    override func researchPhysics() {
        if researching {
            return
        }
        if Resource.instance.gold >= Data.instance.physicsResearchCost.gold! && physics == .none {
            super.researchPhysics()
            
        }
        
    }
    override func researchEngineering() {
        if researching {
            return
        }
        if Resource.instance.iron >= Data.instance.engineeringResearchCost.iron! && Resource.instance.coal >= Data.instance.engineeringResearchCost.coal! && Resource.instance.power >= Data.instance.engineeringResearchCost.power! && engineering == .none {
            super.researchEngineering()
          
        }
    }
    override func researchLegalCode() {
        if researching {
            return
        }
        if Resource.instance.wood >= Data.instance.legalCodeResearchCost.wood! &&
            Resource.instance.clay >= Data.instance.legalCodeResearchCost.clay! && legalCode == .none {
            super.researchLegalCode()
           
        }
    }
    override func researchSeaGoingVessel() {
        if researching {
            return
        }
        if Resource.instance.wood >= Data.instance.seaGoingVesselResearchCost.wood! &&
            Resource.instance.textiles >= Data.instance.seaGoingVesselResearchCost.textiles! && seaGoingVessel == .none {
            super.researchSeaGoingVessel()
          
        }
    }
    override func researchChemistry() {
        if researching {
            return
        }
        if Resource.instance.food >= Data.instance.chemistryResearchCost.food! &&  Resource.instance.wood >= Data.instance.chemistryResearchCost.wood! && chemistry == .none {
            super.researchChemistry()
           
        }
    }
    
    override func researchIronWorking() {
        if researching {
            return
        }
        if Resource.instance.wood >= Data.instance.ironWorkingResearchCost.wood! &&  Resource.instance.iron >= Data.instance.ironWorkingResearchCost.iron! && Resource.instance.coal >= Data.instance.ironWorkingResearchCost.coal! && ironWorking == .none {
            super.researchIronWorking()
            
        }
    }
    
    override func researchOilProduction() {
        if researching {
            return
        }
        if Resource.instance.oil >= Data.instance.oilProductionResearchCost.oil! &&  Resource.instance.coal >= Data.instance.oilProductionResearchCost.coal! && oilProduction == .none {
            super.researchOilProduction()
          
        }
    }
    override func researchPlasticProduction() {
        if researching {
            return
        }
        if Resource.instance.oil >= Data.instance.plasticProductionResearchCost.oil! && plasticProduction == .none {
            super.researchPlasticProduction()
           
        }
    }
    override func researchSteelProduction() {
        if researching {
            return
        }
        if Resource.instance.iron >= Data.instance.steelProductionResearchCost.iron! &&  Resource.instance.coal >= Data.instance.steelProductionResearchCost.coal! && steelProduction == .none {
            super.researchSteelProduction()
           
        }
    }
    override func updateDelta(delta: TimeInterval) {
        super.updateDelta(delta: delta)
        if researching {
            return
        } else {
        switch currentlyResearching {
        case .none:
            return
        case .stone:
            switch stone {
            case .oldStoneAge:
                ResourcePlayer.instance.food -= Data.instance.oldStoneAgeResearchCost.food!
                ResourcePlayer.instance.stone -= Data.instance.oldStoneAgeResearchCost.stone!
                canBuildHunter = true
            case .newStoneAge:
                ResourcePlayer.instance.food -= Data.instance.newStoneAgeResearchCost.food!
                ResourcePlayer.instance.stone -= Data.instance.newStoneAgeResearchCost.stone!
                ResourcePlayer.instance.wood -= Data.instance.newStoneAgeResearchCost.wood!
                canBuildWoodHut = true
                canBuildVillageHall = true
                canBuildVillager = true
            case .quarry:
                ResourcePlayer.instance.food -= Data.instance.quarryResearchCost.food!
                ResourcePlayer.instance.wood -= Data.instance.quarryResearchCost.wood!
                ResourcePlayer.instance.bronze -= Data.instance.quarryResearchCost.bronze!
                canBuildStoneQuarry = true
            default:
                break
            }
      
        case .agriculture:
            switch farming {
            case .beginningOfAgriculture:
                ResourcePlayer.instance.food -= Data.instance.beginningOfAgricultureResearchCost.food!
                ResourcePlayer.instance.wood -= Data.instance.beginningOfAgricultureResearchCost.wood!
                ResourcePlayer.instance.stone -= Data.instance.beginningOfAgricultureResearchCost.stone!
                canBuildFarm = true
            default:
                break
            }
        case .animalHusbandry:
            switch animals {
            case .beginningOfAnimalHusbandry:
                ResourcePlayer.instance.food -= Data.instance.beginningOfAgricultureResearchCost.food!
                ResourcePlayer.instance.wood -= Data.instance.beginningOfAgricultureResearchCost.wood!
                ResourcePlayer.instance.stone -= Data.instance.beginningOfAgricultureResearchCost.stone!
                canBuildTextileRoom = true
                canBuildLeatherShop = true
            default:
                break
            }
        case .irrigation:
            switch irrigation {
            case .beginningOfIrrigation:
                ResourcePlayer.instance.food -= Data.instance.beginningOfIrrigationResearchCost.food!
                ResourcePlayer.instance.wood -= Data.instance.beginningOfIrrigationResearchCost.wood!
                ResourcePlayer.instance.stone -= Data.instance.beginningOfIrrigationResearchCost.stone!
            case .enginneredIrragation:
                ResourcePlayer.instance.food -= Data.instance.beginningOfIrrigationResearchCost.food!
                ResourcePlayer.instance.wood -= Data.instance.beginningOfIrrigationResearchCost.wood!
                ResourcePlayer.instance.stone -= Data.instance.beginningOfIrrigationResearchCost.stone!
                ResourcePlayer.instance.bronze -= Data.instance.enginneredIrragationReasearchCost.bronze!
            default:
                break
            }
        case .pottery:
            switch pottery {
            case .beginningOfPottery:
                ResourcePlayer.instance.food -= Data.instance.beginningOfPotteryResearchCost.food!
                ResourcePlayer.instance.wood -= Data.instance.beginningOfPotteryResearchCost.wood!
                ResourcePlayer.instance.stone -= Data.instance.beginningOfPotteryResearchCost.stone!
                ResourcePlayer.instance.clay -= Data.instance.beginningOfPotteryResearchCost.clay!
                canBuildClayPit = true
                canBuildGrannary = true
                canBuildClayCellar = true
            case .pottersWheel:
                ResourcePlayer.instance.food -= Data.instance.pottersWheelResearchCost.food!
                ResourcePlayer.instance.wood -= Data.instance.pottersWheelResearchCost.wood!
                ResourcePlayer.instance.stone -= Data.instance.pottersWheelResearchCost.stone!
                ResourcePlayer.instance.bronze -= Data.instance.pottersWheelResearchCost.bronze!
                ResourcePlayer.instance.clay -= Data.instance.pottersWheelResearchCost.clay!
            default:
                break
            }
        case .brick:
            switch brick {
            case .brick:
                ResourcePlayer.instance.food -= Data.instance.brickResearchCost.food!
                ResourcePlayer.instance.clay -= Data.instance.brickResearchCost.clay!
                ResourcePlayer.instance.stone -= Data.instance.brickResearchCost.stone!
                canBuildSmallTownHall = true
            default:
                break
            }
        case .building:
            switch building {
            case .beginningOfBuilding:
                ResourcePlayer.instance.food -= Data.instance.beginningOfBuildingResearchCost.food!
                ResourcePlayer.instance.clay -= Data.instance.beginningOfBuildingResearchCost.clay!
                ResourcePlayer.instance.wood -= Data.instance.beginningOfBuildingResearchCost.wood!
                ResourcePlayer.instance.stone -= Data.instance.beginningOfBuildingResearchCost.stone!
                canBuildMediumTownHall = true
                canBuildLargeTownHall = true
            default:
                break
            }
        case .religion:
            switch religion {
            case .beginningOfReligion:
                ResourcePlayer.instance.food -= Data.instance.beginningOfReligionResearchCost.food!
                ResourcePlayer.instance.clay -= Data.instance.beginningOfReligionResearchCost.clay!
            default:
                break
            }
        case .trade:
            switch trade {
            case .beginningOfTrade:
                ResourcePlayer.instance.food -= Data.instance.beginningOfTradeResearchCost.food!
                    ResourcePlayer.instance.clay -= Data.instance.beginningOfTradeResearchCost.clay!
                ResourcePlayer.instance.gold -= Data.instance.beginningOfTradeResearchCost.gold!
                ResourcePlayer.instance.silver -= Data.instance.beginningOfTradeResearchCost.silver!
                ResourcePlayer.instance.copper -= Data.instance.beginningOfTradeResearchCost.copper!
                ResourcePlayer.instance.tin -= Data.instance.beginningOfTradeResearchCost.tin!
                ResourcePlayer.instance.textiles -= Data.instance.beginningOfTradeResearchCost.textiles!
            default:
                break
            }
        case .manufactoring:
            switch manufactoring {
            case .beginningOfManufactoring:
                ResourcePlayer.instance.food -= Data.instance.beginningOfManufactoringResearchCost.food!
                ResourcePlayer.instance.stone -= Data.instance.beginningOfManufactoringResearchCost.stone!
            default:
                break
            }
        case .packAnimals:
            switch packAnimals {
            case .packAnimals:
                ResourcePlayer.instance.food -= Data.instance.packAnimalsResearchCost.food!
                canBuildPackAnimals = true
            default:
                break
            }
        case .dugoutCanoe:
            switch dugoutCanoe {
            case .dugoutCanoe:
                ResourcePlayer.instance.wood -= Data.instance.dugoutCanoeResearchCost.wood!
            default:
                break
            }
        case .sail:
            switch sail {
            case .sail:
                ResourcePlayer.instance.wood -= Data.instance.sailResearchCost.wood!
                ResourcePlayer.instance.textiles -= Data.instance.sailResearchCost.textiles!
            default:
                break
            }
        case .metallurgy:
            switch metallurgy {
            case .beginningOfMetallurgy:
             
                ResourcePlayer.instance.silver -= Data.instance.beginningOfMetallurgyResearchCost.silver!
                ResourcePlayer.instance.gold -= Data.instance.beginningOfMetallurgyResearchCost.gold!
                canBuildGoldMine = true
                canBuildSilverMine = true
                canBuildGoldAndSilverDepositry = true
            case .metallurgy:
                ResourcePlayer.instance.copper -=
                Data.instance.beginningOfMetallurgyResearchCost.copper!
                ResourcePlayer.instance.tin -= Data.instance.beginningOfMetallurgyResearchCost.tin!
                canBuildCopperMine = true
                canBuildCopperHut = true
                canBuildTinMine = true
                canBuildTinHut = true
            default:
                break
            }
        case .literacy:
            switch literacy {
            case .literacy:
                Resource.instance.wood -= Data.instance.literacyResearchCost.wood!
                Resource.instance.clay
                    -= Data.instance.literacyResearchCost.clay!
            default:
                break
            }
        case .numeracy:
            switch numeracy {
            case .numeracy:
                Resource.instance.wood -= Data.instance.numeracyResearchCost.wood!
                Resource.instance.clay -= Data.instance.numeracyResearchCost.clay!
            default:
                break
            }
        case .science:
            switch science {
            case .science:
                Resource.instance.gold -= Data.instance.scienceResearchCost.gold!
            default:
                break
            }
        case .physics:
            switch physics {
            case .physics:
                Resource.instance.gold -= Data.instance.physicsResearchCost.gold!
            default:
                break
            }
        case .engineering:
            switch engineering {
            case .engineering:
                Resource.instance.iron -= Data.instance.engineeringResearchCost.iron!
                Resource.instance.coal -= Data.instance.engineeringResearchCost.coal!
                Resource.instance.power -= Data.instance.engineeringResearchCost.power!
                canBuildSmallCastle = true
                canBuildMediumCastle = true
                canBuildLargeCastle = true
                canBuildSeigeWorkShop = true
            default:
                break
            }
        case .legalCode:
            switch legalCode {
            case .legalCode:
                Resource.instance.wood -= Data.instance.legalCodeResearchCost.wood!
                Resource.instance.clay -= Data.instance.legalCodeResearchCost.clay!
            default:
                break
            }
        case .seaGoingVessel:
            switch seaGoingVessel {
            case .seaGoingVessel:
                Resource.instance.wood -= Data.instance.seaGoingVesselResearchCost.wood!
                Resource.instance.textiles -= Data.instance.seaGoingVesselResearchCost.textiles!
            default:
                break
            }
        case .chemistry:
            switch chemistry {
            case .chemistry:
                Resource.instance.food -= Data.instance.chemistryResearchCost.food!
                Resource.instance.wood -= Data.instance.chemistryResearchCost.wood!
            default:
                break
            }
        case .bronzeWorking:
            switch bronzeWorking {
            case .bronzeworking:
                ResourcePlayer.instance.bronze -= Data.instance.metallurgyResearchCost.bronze!
                canBuildBronzeHut = true
                canBuildBarracks = true
                canBuildCoalMine = true
                canBuildCoalBunker = true
            default:
                break
            }
        case .ironWorking:
            switch ironWorking {
            case .ironWorking:
                Resource.instance.wood -= Data.instance.ironWorkingResearchCost.wood!
                Resource.instance.iron -= Data.instance.ironWorkingResearchCost.iron!
                Resource.instance.coal -= Data.instance.ironWorkingResearchCost.coal!
                canBuildIronMine = true
                canBuildIronHut = true
            default:
                break
            }
        case .oilProduction:
            switch oilProduction {
            case .oilProduction:
                Resource.instance.oil -= Data.instance.oilProductionResearchCost.oil!
                Resource.instance.coal -= Data.instance.oilProductionResearchCost.coal!
                canBuildOilWell = true
            default:
                break
            }
        case .plasticProduction:
            switch plasticProduction {
            case .plasticProduction:
                Resource.instance.oil -= Data.instance.plasticProductionResearchCost.oil!
                canBuildPlasticContainers = true
            default:
                break
            }
        case .steel:
            switch steelProduction {
            case .steelProduction:
                Resource.instance.iron -= Data.instance.steelProductionResearchCost.iron!
                Resource.instance.coal -= Data.instance.steelProductionResearchCost.coal!
            default:
                break
            }
        }
        
    }
        currentlyResearching = .none
    }
    
}


