//
//  GathererPlayer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 18/03/2021.
//

import UIKit
import SceneKit

class StatesGatherer {
    
    enum States {
        case goToBerrys
        case pickBerrys
        case goToNearestHut
        case checkForNoBerrys
        case goHome
    }
    
    var pick = States.goToBerrys
    var store = Storage()
    func gather(gatherer: SCNNode, berrys: SCNNode?) {
     
        if let gatherer = gatherer as? Gatherer {
     
            if let berrys = berrys as? Berrys {
              
                switch pick {
                case .goToBerrys:
                    let distance = Distance()
                    let dist = distance.distance(firstNode: gatherer, secondNode: berrys)
                    let action = SCNAction.move(to: berrys.position, duration: TimeInterval(dist / gatherer.movementSpeed))
                    DispatchQueue.main.async {
                    gatherer.runAction(action) {
                        self.pick = .pickBerrys
                        self.gather(gatherer: gatherer as SCNNode, berrys: berrys)
                    }
                    }
                case .pickBerrys:
                    Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { (timer) in
                        if gatherer.amountOfFoodGathered >= gatherer.maximunFoodCarried && berrys.numberOfBerrys >= 0 {
                            self.pick = .goToNearestHut
                            self.gather(gatherer: gatherer, berrys: berrys)
                            timer.invalidate()
                        }
                        gatherer.amountOfFoodGathered += 1
                        berrys.numberOfBerrys -= 1
                        if berrys.numberOfBerrys <= 0 {
                            self.gather(gatherer: gatherer, berrys: berrys)
                           berrys.removeFromParentNode()
                            self.pick = .checkForNoBerrys
                            timer.invalidate()
                           
                        }
                        
                    }
                case .goToNearestHut:
                    store = gatherer.findNearestStore(berrys: berrys) as! Storage
                    let distance = Distance()
                    let dist = distance.distance(firstNode: gatherer, secondNode: store)
                    let action = SCNAction.move(to: store.position, duration: TimeInterval(dist / gatherer.movementSpeed))
                    DispatchQueue.main.async {
                    gatherer.runAction(action) {
                        self.placeBerrysInStore(gatherer: gatherer, store: self.store, states: .checkForNoBerrys, toGather:   true, berrys: berrys)
                      
                    }
                    }
                case .checkForNoBerrys:
                    
                    if berrys.numberOfBerrys <= 0 {
                        if let  moreBerrys = gatherer.findBerrys() as? Berrys {
                    pick = .goToBerrys
                    gather(gatherer: gatherer as SCNNode, berrys: moreBerrys)
                        } else {
                            goHome(gatherer: gatherer, hut: store)
                        }
                    } else {
                        pick = .goToBerrys
                        gather(gatherer: gatherer as SCNNode, berrys: berrys)
                    }
                default:
                    break
                    
                  
                }
                
            }
            
        }
    }
    func goHome(gatherer: Gatherer, hut: Storage) {
        let distance = Distance()
        let dist = distance.distance(firstNode: gatherer, secondNode: hut as SCNNode)
        let action = SCNAction.move(to: hut.position, duration: TimeInterval(dist / gatherer.movementSpeed))
        DispatchQueue.main.async {
           
            gatherer.runAction(action) {
                self.placeBerrysInStore(gatherer: gatherer, store: self.store, states: .goHome, toGather: false, berrys: nil)
            }
        }
      
    }
    func placeBerrysInStore(gatherer: Gatherer, store: Storage, states: States, toGather: Bool, berrys: Berrys?) {
        Timer.scheduledTimer(withTimeInterval: 0, repeats: true) { (timer) in
            self.store.numberOFUnitsStored.food += 1
            gatherer.amountOfFoodGathered -= 1
            if self.store.numberOFUnitsStored.food >= self.store.maxStored.food {
                timer.invalidate()
                return
            }
            if gatherer.amountOfFoodGathered <= 0 {
                if toGather  {
                    self.pick = .checkForNoBerrys
                    self.gather(gatherer: gatherer, berrys: berrys)
                    timer.invalidate()
                } else {
                    timer.invalidate()
                    return
                }
            }
           
        }
    }
}
