//
//  StatesComputerBuildings.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 24/03/2021.
//

import Foundation
import SceneKit

class StatesComputerBuildings: SCNNode {
    
    enum Buildings {
        case barracks
        case bronzeHut
        case clayCellar
        case clayPit
        case coalBunker
        case coalMine
        case copperHut
        case copperMine
        case farm
        case goldAndSilverDepositry
        case goldMine
        case grannary
        case ironHut
        case ironMine
        case largeCastle
        case largeTownHall
        case leatherShop
        case mediumCastle
        case mediumTownHall
        case oilWell
        case plasticContainers
        case seigeWorkShop
        case siverMine
        case smallCastle
        case smallTownHall
        case stoneQuarry
        case textileRoom
        case tinHut
        case tinMine
        case villageHall
        case woodHut
    }
    
    var buildings = [Buildings: Bool]()
    var states = StatesResearchComputer()
    var currentBuildingsAvailable = [Buildings]()
    func build() -> Buildings {
        buildings = [.barracks: states.canBuildBarracks, .bronzeHut: states.canBuildBronzeHut, .clayCellar: states.canBuildClayCellar, .clayPit: states.canBuildClayPit, .coalBunker: states.canBuildCoalBunker, .coalMine: states.canBuildCoalMine, .copperHut: states.canBuildCopperHut,.copperMine: states.canBuildCopperMine, .farm: states.canBuildFarm, .goldAndSilverDepositry: states.canBuildGoldAndSilverDepositry, .goldMine: states.canBuildGoldMine, .grannary: states.canBuildGrannary, .ironHut: states.canBuildIronHut, .ironMine: states.canBuildIronMine, .largeCastle: states.canBuildLargeCastle, .largeTownHall: states.canBuildLargeTownHall, .leatherShop: states.canBuildLeatherShop, .mediumCastle: states.canBuildMediumCastle, .mediumTownHall: states.canBuildMediumTownHall, .oilWell: states.canBuildOilWell, .plasticContainers: states.canBuildPlasticContainers, .seigeWorkShop: states.canBuildSeigeWorkShop, .siverMine: states.canBuildSilverMine, .smallCastle: states.canBuildSmallCastle, .smallTownHall: states.canBuildSmallTownHall, .stoneQuarry: states.canBuildStoneQuarry, .textileRoom: states.canBuildTextileRoom, .tinHut: states.canBuildTinHut, .tinMine: states.canBuildTinMine, .villageHall: states.canBuildVillageHall, .woodHut: states.canBuildWoodHut]
        
        for (key, value) in buildings {
            if value == true {
                currentBuildingsAvailable.append(key)
            }
        }
        let randomIndexNumber = Int.random(in: 0..<currentBuildingsAvailable.count)
        let choosenBuilding = currentBuildingsAvailable[randomIndexNumber]
        return choosenBuilding
    }
   
    
}
