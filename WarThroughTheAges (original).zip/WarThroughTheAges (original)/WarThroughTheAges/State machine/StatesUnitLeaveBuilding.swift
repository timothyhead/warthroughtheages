//
//  StatesUnitLeaveBuilding.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 02/03/2021.
//

import UIKit
import QuartzCore
import SceneKit

class StatesUnitLeaveBuilding {
    enum State {
        case none
        case leaving
        case squareFormation
        case lineFormation
        case ringFormation
    }
    var currentState: State
    let randomNumberX = Int.random(in: -1...1)
    let randomNumberZ = Int.random(in: -1...1)
    var isMoving = Bool()
    var loopCount = 0
    var hasTouched = Bool()
    var isLeaving = Bool()
    
    init(currentState: State) {
        self.currentState = currentState
    }
    func leave(unit: SCNNode, inBuilding: SCNNode?) {
        if currentState == .none || isLeaving == true {
            return
        }
        isLeaving = true
     if currentState == .leaving {
            if let inBuilding = inBuilding {
            if unit.position.x >= 0 {
           
                let action = SCNAction.move(to: SCNVector3(inBuilding.boundingBox.min.x - 1, unit.position.y, unit.position.z), duration: 2)
                    if self.isMoving == false {
                        self.isMoving = true
                unit.runAction(action) {
                    DispatchQueue.main.async {
                        self.currentState = .none
                        self.isMoving = false
                    
                    }
                }
                }
            } else {
                let action = SCNAction.move(to: SCNVector3(inBuilding.boundingBox.max.x + 1, unit.position.y, unit.position.z), duration: 2)
                if isMoving == false {
                    isMoving = true
                unit.runAction(action) {
                    DispatchQueue.main.async {
                        self.currentState = .none
                        self.isMoving = false
                    }
                    }
                }
              
            }
            }
     } else if currentState == .squareFormation {
        
     }
        isLeaving = false
            }

}
  
