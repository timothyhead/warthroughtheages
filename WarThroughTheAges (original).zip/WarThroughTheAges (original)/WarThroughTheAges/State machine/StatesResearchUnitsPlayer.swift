//
//  StatesResearchUnits.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 25/03/2021.
//

import Foundation
import SceneKit

class StatesResearchUnitsPlayer: StatesResearchUnits, ResearchUnitDelegete {
 
    var vc = ResearchUnitTableViewController()
    let storyboard = UIStoryboard(name: "Main", bundle: nil)
    var progressBar = ProgressBar()
    var node = SCNNode()

    
    override init() {
        super.init()
        cost = ResourcePlayer.instance
        states = GameViewController.world.researchStates
       
    }
    func unitResearch(type: UnitEquipment) {
            research(type: type)
        
    }
    func createVC(node: SCNNode) {
      vc = (storyboard.instantiateViewController(identifier: "unitTableVC") as? ResearchUnitTableViewController)!
        vc.delegete = self
    
        for nodes in GameViewController.world.childNodes {
           
        
                for obj in nodes.childNodes {
                    if obj.name == "insideBarracks" {
                        for n in obj.childNodes {
                            if n.name == node.name {
                                self.node = obj
                            
                        }
                    }
                }
             
            }
        }
    
    }

        func updateDelta(delta:TimeInterval) {
            if isResearching == true {
                progressBar.progressBar(node: node, animtionTime: researchTime, node1: "researchButton", node2: "researchProgressBarNode")
            }
            if self.hasResearched == false {
                return
            }
           
            if  self.isResearched.helmetBronze == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.helmetBronze = true
            }
            if self.isResearched.helmetIron == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.helmetIron = true
            }
            if self.isResearched.helmetSteel == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.helmetSteel = true
            }
            if isResearched.spearShort == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.spearShort = true
            }
            if isResearched.spearMedium == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.spearMedium = true
            }
            if isResearched.spearLong == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.spearLong = true
            }
            if isResearched.ax == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.ax = true
            }
            if isResearched.shieldSmall == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.shieldSmall = true
            }
            if isResearched.shieldMedium == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.shieldMedium = true
            }
            if isResearched.shieldLarge == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.shieldLarge = true
            }
            if isResearched.swordSmall == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.swordSmall = true
            }
            if isResearched.swordMedium == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.swordMedium = true
            }
            if isResearched.swordLong == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.swordLong = true
            }
            if isResearched.javelin == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.javelin = true
            }
            if isResearched.sling == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.sling = true   
            }
            if isResearched.bow == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.bow = true
            }
            if isResearched.leather == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.leather = true
            }
            if isResearched.chainMail == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.chainMail = true
            }
            if isResearched.platemail == true {
                StatesResearchUnitsPlayer.IsResearchedPlayer.instance.platemail = true
            }
            hasResearched = false
    }
  
   struct IsResearchedPlayer {
        
        static var instance = IsResearchedPlayer()
        var helmetBronze  = Bool()
        var helmetIron = Bool()
        var helmetSteel = Bool()
        var spearShort = Bool()
        var spearMedium = Bool()
        var spearLong = Bool()
        var ax = Bool()
        var shieldSmall = Bool()
        var shieldMedium = Bool()
        var shieldLarge = Bool()
        var swordSmall = Bool()
        var swordMedium = Bool()
        var swordLong = Bool()
        var javelin = Bool()
        var sling = Bool()
        var bow = Bool()
        var leather = Bool()
        var chainMail = Bool()
        var platemail = Bool()
    }
}
