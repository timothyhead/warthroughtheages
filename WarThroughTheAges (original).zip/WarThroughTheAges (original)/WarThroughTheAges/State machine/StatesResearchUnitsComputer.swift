//
//  StatesResearchUnitsComputer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 26/03/2021.
//


//
//  StatesResearchUnits.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 25/03/2021.
//

import Foundation
import SceneKit

class StatesResearchUnitsComputer {
   var researchUnits = StatesResearchUnits()
    func unitResearch(type: UnitEquipment) {
            researchUnits.research(type: type)
        switch type {
        case .helmetBronze:
            StatesResearchUnitsComputer.IsResearchedComputer.instance.helmetBronze = true
        case .helmetIron:
        StatesResearchUnitsComputer.IsResearchedComputer.instance.helmetIron = true
        case .helmetSteel:
        StatesResearchUnitsComputer.IsResearchedComputer.instance.helmetSteel = true
        case .spearShort:
            StatesResearchUnitsComputer.IsResearchedComputer.instance.spearShort = true
        case .spearMedium:
            StatesResearchUnitsComputer.IsResearchedComputer.instance.spearMedium = true
        case .spearLong:
            StatesResearchUnitsComputer.IsResearchedComputer.instance.spearLong = true
        case .ax:
            StatesResearchUnitsComputer.IsResearchedComputer.instance.ax = true
        case .shieldSmall:
            StatesResearchUnitsComputer.IsResearchedComputer.instance.shieldSmall = true
        case .shieldMedium:
            StatesResearchUnitsComputer.IsResearchedComputer.instance.shieldMedium = true
        case .shieldLarge:
        StatesResearchUnitsComputer.IsResearchedComputer.instance.shieldLarge = true
        case .swordSmall:
            StatesResearchUnitsComputer.IsResearchedComputer.instance.swordShort = true
        case .swordMedium:
            StatesResearchUnitsComputer.IsResearchedComputer.instance.swordMedium = true
        case .swordLong:
            StatesResearchUnitsComputer.IsResearchedComputer.instance.swordLong = true
        case .javelin:
            StatesResearchUnitsComputer.IsResearchedComputer.instance.javelin = true
        case .sling:
            StatesResearchUnitsComputer.IsResearchedComputer.instance.sling = true
        case .bow:
            StatesResearchUnitsComputer.IsResearchedComputer.instance.bow = true
        case .leather:
            StatesResearchUnitsComputer.IsResearchedComputer.instance.leather = true
        case .chainMail:
            StatesResearchUnitsComputer.IsResearchedComputer.instance.chainMail = true
        case .platemail:
            StatesResearchUnitsComputer.IsResearchedComputer.instance.platemail = true
        default:
            break
        }
        
    }
    class IsResearchedComputer {
        
        static var instance = IsResearchedComputer()
    var helmetBronze = Bool()
        var helmetIron = Bool()
        var helmetSteel = Bool()
    var spearShort = Bool()
        var spearMedium = Bool()
        var spearLong = Bool()
    var ax = Bool()
    var shieldSmall = Bool()
        var shieldMedium = Bool()
        var shieldLarge = Bool()
    var swordShort = Bool()
        var swordMedium = Bool()
        var swordLong = Bool()
    var javelin = Bool()
    var sling = Bool()
    var bow = Bool()
    var leather = Bool()
    var chainMail = Bool()
    var platemail = Bool()
    }
}
