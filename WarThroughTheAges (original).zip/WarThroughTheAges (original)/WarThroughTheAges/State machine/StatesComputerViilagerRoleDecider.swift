//
//  StatesComputerViilagerRoleDecider.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 18/02/2021.
//

import SceneKit
import UIKit


//MARK:- THINGS TO DO
// make an if idle state

class StatesComputerViilagerRoleDecider: SCNNode {
    var resourceBuildingArray = [FarmComputer]()
    var villager = Villager()
    var choosenResourceBuilding = SCNNode()
    func chooseRole(villager: Villager) {
        self.villager = villager
        for obj in GameViewController.world.childNodes {
            if obj.name?.contains("resource_computer") == true || obj.name?.contains("woods") == true {
                resourceBuildingArray.append(obj as! FarmComputer)
            }
        }
        let randomNumber = Int.random(in: 0..<resourceBuildingArray.count)
        choosenResourceBuilding = resourceBuildingArray[randomNumber]
        
        chooseVillagerRole(resourceName: "farm_computer", role: .food)
        chooseVillagerRole(resourceName: "clayPit_computer", role: .clay)
        chooseVillagerRole(resourceName: "stoneQuarry_computer", role: .stone)
        chooseVillagerRole(resourceName: "copperMine_computer", role: .copper)
        chooseVillagerRole(resourceName: "tinMine_computer", role: .tin)
        chooseVillagerRole(resourceName: "goldMine_computer", role: .gold)
        chooseVillagerRole(resourceName: "silverMine_computer", role: .silver)
        chooseVillagerRole(resourceName: "coalMine_computer", role: .coal)
        chooseVillagerRole(resourceName: "ironMine_computer", role: .iron)
        chooseVillagerRole(resourceName: "oilWell_computer", role: .oil)
        chooseVillagerRole(resourceName: "woods", role: .wood)
    }
    
    func chooseVillagerRole(resourceName: String, role: Collect) {
        if choosenResourceBuilding.name?.contains(resourceName) == true {
            villager.role = role
        }
        
    }
}
