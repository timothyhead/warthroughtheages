//
//  ResearchUnits.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 25/03/2021.
//

import Foundation
import SceneKit
//MARK: THINGS TO DO
// sling in research func needs a condition to dis able it when no tribal cultures exist

class StatesResearchUnits {
    
    var isResearching = Bool()
    var isResearched = IsResearched()
    var type = UnitEquipment.none
    var cost = Resource.instance
    var states = StatesResearch()
    var hasResearched = false
    var researchTime = TimeInterval()
 
    
    
  
    
    func research(type: UnitEquipment) {
        if isResearching {
            return
        }
        self.type = type
        switch type {
        case .helmetBronze:
            if cost.bronze >= Data.instance.costForHelmetBronzeResearch.bronze! && states.bronzeWorking == .bronzeworking {
                timer(researchTime: Data.instance.timeForHelmetResearchBronze, costs: Data.instance.costForHelmetBronzeResearch)
            }
        case .helmetIron:
            if cost.iron >= Data.instance.costForHelmetIronResearch.iron! && isResearched.helmetBronze == true && states.ironWorking == .ironWorking {
                timer(researchTime: Data.instance.timeForHelmetResearchIron, costs: Data.instance.costForHelmetIronResearch)
            }
        case .helmetSteel:
            if cost.steel >= Data.instance.costForHelmetSteelResearch.steel! && isResearched.helmetIron == true && states.steelProduction == .steelProduction {
                timer(researchTime: Data.instance.timeForHelmetResearchSteel, costs: Data.instance.costForHelmetSteelResearch)
            }
        case .spearShort:
            if cost.stone >= Data.instance.costForSpearResearchSmall.stone! && cost.wood >= Data.instance.costForSpearResearchSmall.wood! && states.stone == .newStoneAge {
                timer(researchTime: Data.instance.timeForSpearResearchSmall, costs: Data.instance.costForSpearResearchSmall)
            }
        case .spearMedium:
            if cost.bronze >= Data.instance.costForSpearResearchMedium.bronze! && cost.wood >= Data.instance.costForSpearResearchMedium.wood! && isResearched.spearShort == true && states.bronzeWorking == .bronzeworking {
                timer(researchTime: Data.instance.timeForSpearResearchMedium, costs: Data.instance.costForSpearResearchMedium)
            }
        case .spearLong:
            if cost.iron >= Data.instance.costForSpearResearchMedium.iron! && cost.wood >= Data.instance.costForSpearResearchMedium.wood! && isResearched.spearMedium == true && states.ironWorking == .ironWorking{
                timer(researchTime: Data.instance.timeForSpearResearchMedium, costs: Data.instance.costForSpearResearchMedium)
            }
        case .ax:
            if cost.wood >= Data.instance.costForAxResearch.wood! && cost.bronze >= Data.instance.costForAxResearch.bronze! && states.bronzeWorking == .bronzeworking {
                timer(researchTime: Data.instance.timeForAxResearch, costs: Data.instance.costForAxResearch)
            }
        case .shieldSmall:
            if cost.wood >= Data.instance.costForShieldResearchSmall.wood! && cost.bronze >= Data.instance.costForShieldResearchSmall.bronze! && states.bronzeWorking == .bronzeworking  {
                timer(researchTime: Data.instance.timeForShieldResearchSmall, costs: Data.instance.costForShieldResearchSmall)
            }
        case .shieldMedium:
            if cost.wood >= Data.instance.costForShieldResearchMedium.wood! && isResearched.shieldSmall == true {
                timer(researchTime: Data.instance.timeForShieldResearchMedium, costs: Data.instance.costForShieldResearchMedium)
            }
        case .shieldLarge:
            if cost.wood >= Data.instance.costForShieldResearchLarge.wood! && cost.leather >= Data.instance.costForShieldResearchLarge.leather! && isResearched.shieldMedium == true && states.animals == .beginningOfAnimalHusbandry {
                timer(researchTime: Data.instance.timeForShieldResearchLarge, costs: Data.instance.costForShieldResearchLarge)
            }
        case .swordSmall:
            if cost.bronze >= Data.instance.costForSwordResearchShort.bronze! && states.bronzeWorking == .bronzeworking {
                timer(researchTime: Data.instance.timeForSwordResearchSmall, costs: Data.instance.costForSwordResearchShort)
            }
        case .swordMedium:
            if cost.iron >= Data.instance.costForSwordResearchMedium.iron! && isResearched.swordSmall == true && states.ironWorking == .ironWorking{
                timer(researchTime: Data.instance.timeForSwordResearchMedium, costs: Data.instance.costForSwordResearchMedium)
            }
        case .swordLong:
            if cost.iron >= Data.instance.costForSwordResearchShort.iron! && isResearched.swordMedium == true {
                timer(researchTime: Data.instance.timeForSwordResearchLarge, costs: Data.instance.costForSwordResearchLong)
            }
        case .javelin:
            if cost.wood >= Data.instance.costForJavelinResearch.wood! && cost.stone >= Data.instance.costForJavelinResearch.stone! && isResearched.spearShort == true {
            timer(researchTime: Data.instance.timeForJavelinResearch, costs: Data.instance.costForJavelinResearch)
        }
        case .sling:
            if cost.stone >= Data.instance.costForSlingResearch.stone! && cost.textiles >= Data.instance.costForSlingResearch.textiles! {
                timer(researchTime: Data.instance.timeForSlingResearch, costs: Data.instance.costForSlingResearch)
            }
        case .bow:
            if cost.wood >= Data.instance.costForBowtResearch.wood! && states.stone == .newStoneAge {
                timer(researchTime: Data.instance.timeForBowResearch, costs: Data.instance.costForBowtResearch)
              
            }
        case .leather:
            if  cost.leather >= Data.instance.costForLeatherResearch.leather! && states.animals == .beginningOfAnimalHusbandry {
                timer(researchTime: Data.instance.timeForLeatherResearch, costs: Data.instance.costForLeatherResearch)
            }
        case .chainMail:
            if cost.iron >= Data.instance.costForChainMailResearch.iron! && states.ironWorking == .ironWorking && StatesResearchUnitsPlayer.IsResearchedPlayer.instance.leather == true {
                timer(researchTime: Data.instance.timeForChainMailResearch, costs: Data.instance.costForChainMailResearch)
            }
        case .platemail:
            if cost.iron >= Data.instance.costForPlateMailResearch.iron! && isResearched.chainMail == true {
                timer(researchTime: Data.instance.timeForPlateMailResearch, costs: Data.instance.costForPlateMailResearch)
            }
        default:
            break
        }
    }
    func timer(researchTime: TimeInterval, costs: ResourceCosts)  {
        isResearching = true
        self.researchTime = researchTime
       
        Timer.scheduledTimer(withTimeInterval: researchTime, repeats: false) { (timer)  in
            DispatchQueue.main.async {
                self.isResearching = false
            switch self.type {
            case .helmetBronze:
                self.isResearched.helmetBronze = true
            case .helmetIron:
                self.isResearched.helmetIron = true
            case .helmetSteel:
                self.isResearched.helmetSteel = true
            case .spearShort:
                self.isResearched.spearShort = true
            case .spearMedium:
                self.isResearched.spearMedium = true
            case .spearLong:
                self.isResearched.spearLong = true
            case .ax:
                self.isResearched.ax = true
            case .shieldSmall:
                self.isResearched.shieldSmall = true
            case .shieldMedium:
                self.isResearched.shieldMedium = true
            case .shieldLarge:
                self.isResearched.shieldLarge = true
            case .swordSmall:
                self.isResearched.swordSmall = true
            case .swordMedium:
                self.isResearched.swordMedium = true
            case .swordLong:
                self.isResearched.swordLong = true
            case .javelin:
                self.isResearched.javelin = true
            case .sling:
                self.isResearched.sling = true
            case .bow:
                self.isResearched.bow = true
            case .leather:
                self.isResearched.leather = true
            case .chainMail:
                self.isResearched.chainMail = true
            case .platemail:
                self.isResearched.platemail = true
            default:
                break
            }
            if let costs = costs.bronze {
                self.cost.bronze -= costs
            }
            if let costs = costs.clay {
                self.cost.clay -= costs
            }
            if let costs = costs.coal {
                self.cost.coal -= costs
            }
            if let costs = costs.copper {
                self.cost.copper -= costs
            }
            if let costs = costs.food {
                self.cost.food -= costs
            }
            if let costs = costs.gold {
                self.cost.gold -= costs
            }
            if let costs = costs.iron {
                self.cost.iron -= costs
            }
            if let costs = costs.leather {
                self.cost.leather -= costs
            }
            if let costs = costs.oil {
                self.cost.oil -= costs
            }
            if let costs = costs.plastic {
                self.cost.plastic -= costs
            }
            if let costs = costs.power {
                self.cost.power -= costs
            }
            if let costs = costs.silver {
                self.cost.silver -= costs
            }
            if let costs = costs.steel {
                self.cost.steel -= costs
            }
            if let costs = costs.stone {
                self.cost.stone -= costs
            }
            if let costs = costs.textiles {
                self.cost.textiles -= costs
            }
            if let costs = costs.tin {
                self.cost.tin -= costs
            }
            if let costs = costs.wood {
                self.cost.wood -= costs
            }
                self.hasResearched = true
            
        }
        }
    }
    class IsResearched {
var helmetBronze  = Bool()
var helmetIron = Bool()
var helmetSteel = Bool()
var spearShort = Bool()
var spearMedium = Bool()
var spearLong = Bool()
var ax = Bool()
var shieldSmall = Bool()
var shieldMedium = Bool()
var shieldLarge = Bool()
var swordSmall = Bool()
var swordMedium = Bool()
var swordLong = Bool()
var javelin = Bool()
var sling = Bool()
var bow = Bool()
var leather = Bool()
var chainMail = Bool()
var platemail = Bool()
    }
}
