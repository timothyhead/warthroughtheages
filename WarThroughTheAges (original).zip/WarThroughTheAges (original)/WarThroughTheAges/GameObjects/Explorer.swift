//
//  Explorer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 05/02/2021.
//

import UIKit
import QuartzCore
import SceneKit

class Explorer: BasicUnit {
    override func moveTo(position: SCNVector3) {
        
    }
}
