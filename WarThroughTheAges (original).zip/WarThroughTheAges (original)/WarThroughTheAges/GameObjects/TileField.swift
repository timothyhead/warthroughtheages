//
//  TileField.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 05/02/2021.
//

import UIKit
import QuartzCore
import SceneKit

class TileField: SCNNode {
 

    override init() {
        super.init()
        for i in -10..<10 {
            for j in -10..<10 {
                let tileField = Tile()
                tileField.position = SCNVector3(i, 0, j)
                tileField.id = (i, j)
                self.addChildNode(tileField)
            }
        }
        self.name = "tileField"
       
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
