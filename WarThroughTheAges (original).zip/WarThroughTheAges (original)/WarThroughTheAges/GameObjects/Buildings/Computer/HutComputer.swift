//
//  HutComputer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 12/02/2021.
//

import Foundation
import SceneKit

class HutComputer: UnitCreationBuilding {
    //MARK: - THINGS TO DO
    // finilise parameter values except for position
    // set up queuee and timer and cost
    var populationSupported: Int
    init(totalHealth: Double, defence: Double, fileNamed: String, modelNamed: String, position: SCNVector3, maxiumumUnitsStored: Double, populationSupported: Int, insideBuildingName: String) {
        self.populationSupported = populationSupported
        PopulationNumbersSupportedPlayer.instance.maximumNumbers = populationSupported
        super.init(health: totalHealth ,totalHealth: totalHealth, defence: defence,level: 1, fileNamed: fileNamed, modelNamed: modelNamed, position: position, maxiumumUnitsStored: maxiumumUnitsStored, insideBuildingName: "")
     
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
     func createGatherer() -> SCNNode {
        let gatherer = GathererComputer(totalHealth: 100, movementSpeed: 5, attackSpeed: 5, range: 0, fileNamed: "testObject", modelNamed: "testObject", position: self.position)
        return gatherer
    }
     func createHunter() -> SCNNode {
        let hunter = HunterComputer(totalHealth: 125, movementSpeed: 10, attackSpeed: 7, range: Data.instance.rangeHunter, fileNamed: "testObject", modelNamed: "testObject", position: self.position)
        return hunter
    }
    override func createVillager() -> SCNNode {
        let villager = VillagerComputer(totalHealth: 110,movementSpeed: 1.5, attackSpeed: 6, fileNamed: "testObject", modelNamed: "testObject", position: self.position)
        return villager
    }
}
