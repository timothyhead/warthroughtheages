//
//  SmallCastleComputer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 12/02/2021.
//

import Foundation

class SmallCastleComputer: HutComputer {
    var maxNumberOFCitizensSupported = Int()
    var maxNumberOfSupportingTroops = Int()
}
