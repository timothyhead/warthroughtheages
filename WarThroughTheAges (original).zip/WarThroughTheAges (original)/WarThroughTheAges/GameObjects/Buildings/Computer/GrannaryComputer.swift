//
//  GrannaryComputer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 17/02/2021.
//

import Foundation
import SceneKit

class GrannaryComputer: Storage {
    // work in level increase with respect to max units stored property
    // work in totalhealth increase for level increase
  
}
