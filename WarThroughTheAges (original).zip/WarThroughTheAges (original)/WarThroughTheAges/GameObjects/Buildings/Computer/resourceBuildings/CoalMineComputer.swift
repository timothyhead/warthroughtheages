//
//  CoalMineComputer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 04/03/2021.
//

import Foundation

class CoalMineComputer: GameObject {
    
}
