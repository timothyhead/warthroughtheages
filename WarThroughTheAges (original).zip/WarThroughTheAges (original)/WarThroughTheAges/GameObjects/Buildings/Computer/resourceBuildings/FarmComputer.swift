//
//  FarmComputer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 16/02/2021.
//

import QuartzCore
import SceneKit
import UIKit

class FarmComputer: GameObject {
    //MARK:- THINGS TO DO
    // set up max number of workers on resource building
    // increase max number of workers for level increase
    // work in totalhealth increase for level increase
    // use _resourceBuilding in name
}
