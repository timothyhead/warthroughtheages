//
//  Barracks.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 19/03/2021.
//

import UIKit
import SceneKit

class BarracksPlayer: UnitCreationBuilding {
    
    override init(health: Double, totalHealth: Double, defence: Double, level: Int, fileNamed: String, modelNamed: String, position: SCNVector3, maxiumumUnitsStored: Double, insideBuildingName: String) {
    
        super.init(health: health, totalHealth: totalHealth, defence: defence, level: level, fileNamed: fileNamed, modelNamed: modelNamed, position: position, maxiumumUnitsStored: maxiumumUnitsStored, insideBuildingName: "insideBarracks")
        self.health = totalHealth
      
       
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    convenience init(totalHealth: Double, defence: Double, fileNamed: String, modelNamed: String, position: SCNVector3) {
        self.init(health: totalHealth, totalHealth: totalHealth, defence: defence, level: 1, fileNamed: fileNamed, modelNamed: modelNamed, position: position, maxiumumUnitsStored: 0, insideBuildingName: "insideBarracks")
    }
    
    override func createStoneMaceMan() -> SCNNode {
        let stoneMaceMan = StoneMaceManPlayer(totalHealth: Data.instance.totalHealthPointsStoneMaceManLevel1, movementSpeed: Data.instance.movementSpeedStoneMaceManLevel1, attackSpeed: Data.instance.attackSpeedStoneMaceManLevel1, range: 0, fileNamed: "militaryUnits", modelNamed: "stoneMaceMan_player_unit", position: self.position)
        stoneMaceMan.weaponType.type = .stoneMace
        return stoneMaceMan
    }
    override func createAxMan() -> SCNNode {
        let axMan = AxManPlayer(totalHealth: Data.instance.totalHealthPointsAxManLevel1, movementSpeed: Data.instance.movementSpeedAxManLevel1, attackSpeed: Data.instance.attackSpeedAxManLevel1, range: 0, fileNamed: "militaryUnits", modelNamed: "axMan_player_unit", position: self.position)
        axMan.weaponType.type = .axe
        return axMan
    }
    override func createSpearMan() -> SCNNode {
        let spearMan = SpearManPlayer(totalHealth: Data.instance.totalHealthPointsSpearManLevel1, movementSpeed: Data.instance.movementSpeedSpearManLevel1, attackSpeed: Data.instance.attackSpeedSpearManLevel1, range: Data.instance.rangeSpearMan, fileNamed: "militaryUnits", modelNamed: "spearMan_player_unit", position: self.position)
//        spearMan.weaponType.type = .spear
        return spearMan
    }
    override func createJavelinMan() -> SCNNode {
        let javelinMan = JavelinManPlayer(totalHealth: Data.instance.totalHealthPointsJavelinLevel1, movementSpeed: Data.instance.movementSpeedJavelinLevel1, attackSpeed: Data.instance.attackSpeedJavelinLevel1, range: Data.instance.rangeJavelinMan, fileNamed: "militaryUnits", modelNamed: "javelinMan_player_unit", position: self.position)
        javelinMan.weaponType.type = .javelin
        return javelinMan
    }
    override func createSlingMan() -> SCNNode {
        let slingMan = SlingManPlayer(totalHealth: Data.instance.totalHealthPointsSlingManLevel1, movementSpeed: Data.instance.movementSpeedSlingManLevel1, attackSpeed: Data.instance.attackSpeedSlingManLevel1, range: Data.instance.rangeSlingMan, fileNamed: "militaryUnits", modelNamed: "slingMan_player_unit", position: self.position)
        slingMan.weaponType.type = .sling
        return slingMan
    }
    override func createArcher() -> SCNNode {
        let archer = ArcherPlayer(totalHealth: Data.instance.totalHealthPointsArcherLevel1, movementSpeed: Data.instance.movementSpeedArcherLevel1, attackSpeed: Data.instance.attackSpeedArcherLevel1, range: Data.instance.rangeArcher, fileNamed: "militaryUnits", modelNamed: "archer_player_unit", position: self.position)
        archer.weaponType.type = .bow
        return archer
    }
    override func createSwordMan() -> SCNNode {
        let swordMan = SwordManPlayer(totalHealth: Data.instance.totalHealthPointsSwordmanLevel1, movementSpeed: Data.instance.movementSpeedSwordmanLevel1, attackSpeed: Data.instance.attackSpeedSwordmanLevel1, range: Data.instance.rangeSwordMan, fileNamed: "militaryUnits", modelNamed: "swordMan_player_unit", position: self.position)
//        swordMan.weaponType.type = .sword
        return swordMan
    }
    
}
