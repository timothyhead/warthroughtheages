//
//  MechanicalArtillaryAndSeigeEngineWorkShop_player.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 24/03/2021.
//

import SceneKit
import Foundation

class MechanicalArtillaryAndSeigeEngineWorkShopPlayer: UnitCreationBuilding {
    override init(health: Double, totalHealth: Double, defence: Double, level: Int, fileNamed: String, modelNamed: String, position: SCNVector3, maxiumumUnitsStored: Double, insideBuildingName: String) {
    
        super.init(health: health, totalHealth: totalHealth, defence: defence, level: level, fileNamed: fileNamed, modelNamed: modelNamed, position: position, maxiumumUnitsStored: maxiumumUnitsStored, insideBuildingName: insideBuildingName)
        self.health = totalHealth
      
       
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    convenience init(totalHealth: Double, defence: Double, fileNamed: String, modelNamed: String, position: SCNVector3, insideBuildingName: String) {
        self.init(health: totalHealth, totalHealth: totalHealth, defence: defence, level: 1, fileNamed: fileNamed, modelNamed: modelNamed, position: position, maxiumumUnitsStored: 0, insideBuildingName: insideBuildingName)
    }
    func createGastrophetes() -> SCNNode {
        let gastrohete = GastrophetesPlayer(totalHealth: Data.instance.totalHealthPointsGastropheteLevel1, movementSpeed: Data.instance.movementSpeedGastropheteLevel1, attackSpeed: Data.instance.attackSpeedGastropheteLevel1, range: Data.instance.rangeGastrophete, fileNamed: "mechanicalArtillaryAndSeigeEngine", modelNamed: "gastrophete", position: self.position)
        return gastrohete
    }
    func createCatapult() -> SCNNode {
        let catapult = CatapultPlayer(totalHealth: Data.instance.totalHealthPointsCatapultLevel1, movementSpeed: Data.instance.movementSpeedCatapultLevel1, attackSpeed: Data.instance.attackSpeedCatapultLevel1, range: Data.instance.rangeCatapult, fileNamed: "mechanicalArtillaryAndSeigeEngine", modelNamed: "catapult", position: self.position)
        return catapult
    }
}
