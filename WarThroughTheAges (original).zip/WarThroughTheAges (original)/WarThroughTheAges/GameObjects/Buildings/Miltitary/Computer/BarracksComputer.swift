//
//  Barracks.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 22/03/2021.
//

import UIKit
import SceneKit

class BarracksComputer: UnitCreationBuilding {
    override init(health: Double, totalHealth: Double, defence: Double, level: Int, fileNamed: String, modelNamed: String, position: SCNVector3, maxiumumUnitsStored: Double, insideBuildingName: String) {
       
    
        super.init(health: health, totalHealth: totalHealth, defence: defence, level: level, fileNamed: fileNamed, modelNamed: modelNamed, position: position, maxiumumUnitsStored: maxiumumUnitsStored, insideBuildingName: "")
        self.health = totalHealth
      
       
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    convenience init(totalHealth: Double, defence: Double, fileNamed: String, modelNamed: String, position: SCNVector3) {
        self.init(health: totalHealth, totalHealth: totalHealth, defence: defence, level: 1, fileNamed: fileNamed, modelNamed: modelNamed, position: position, maxiumumUnitsStored: 0, insideBuildingName: "")
    }
    override func createStoneMaceMan() -> SCNNode {
        let stoneMaceMan = StoneMaceManComputer(totalHealth: Data.instance.totalHealthPointsStoneMaceManLevel1, movementSpeed: Data.instance.movementSpeedStoneMaceManLevel1, attackSpeed: Data.instance.attackSpeedStoneMaceManLevel1, range: 0, fileNamed: "militaryUnits", modelNamed: "stoneMaceMan_player_unit", position: self.position)
        return stoneMaceMan
    }
    override func createAxMan() -> SCNNode {
        let axMan = AxManComputer(totalHealth: Data.instance.totalHealthPointsAxManLevel1, movementSpeed: Data.instance.movementSpeedAxManLevel1, attackSpeed: Data.instance.attackSpeedAxManLevel1, range: 0, fileNamed: "militaryUnits.scn", modelNamed: "axMan_player_unit", position: self.position)
        return axMan
    }
    override func createSpearMan() -> SCNNode {
        let spearMan = SpearManComputer(totalHealth: Data.instance.totalHealthPointsSpearManLevel1, movementSpeed: Data.instance.movementSpeedSpearManLevel1, attackSpeed: Data.instance.attackSpeedSpearManLevel1, range: Data.instance.rangeSpearMan, fileNamed: "militaryUnits.scn", modelNamed: "spearMan_player_unit", position: self.position)
        return spearMan
    }
    override func createJavelinMan() -> SCNNode {
        let javelinMan = JavelinManComputer(totalHealth: Data.instance.totalHealthPointsJavelinLevel1, movementSpeed: Data.instance.movementSpeedJavelinLevel1, attackSpeed: Data.instance.attackSpeedJavelinLevel1, range: Data.instance.rangeJavelinMan, fileNamed: "militaryUnits.scn", modelNamed: "javelinMan_player_unit", position: self.position)
        return javelinMan
    }
    override func createSlingMan() -> SCNNode {
        let slingMan = SlingManComputer(totalHealth: Data.instance.totalHealthPointsSlingManLevel1, movementSpeed: Data.instance.movementSpeedSlingManLevel1, attackSpeed: Data.instance.attackSpeedSlingManLevel1, range: Data.instance.rangeSlingMan, fileNamed: "militaryUnits.scn", modelNamed: "slingMan_player_unit", position: self.position)
        return slingMan
    }
    override func createArcher() -> SCNNode {
        let archer = ArcherComputer(totalHealth: Data.instance.totalHealthPointsArcherLevel1, movementSpeed: Data.instance.movementSpeedArcherLevel1, attackSpeed: Data.instance.attackSpeedArcherLevel1, range: Data.instance.rangeArcher, fileNamed: "militaryUnits.scn", modelNamed: "archer_player_unit", position: self.position)
        return archer
    }
    
}
