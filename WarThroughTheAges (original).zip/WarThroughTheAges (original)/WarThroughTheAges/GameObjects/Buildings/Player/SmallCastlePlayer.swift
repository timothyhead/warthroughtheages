//
//  SmallCastlePlayer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 12/02/2021.
//

import Foundation

class SmallCastlePlayer: HutPlayer {
    var maxNumberOFCitizensSupported = Int()
    var maxNumberOfSupportingTroops = Int()
}
