//
//  ClayPitPlayer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 16/02/2021.
//

import QuartzCore
import SceneKit
import UIKit

class ClayPitPlayer: GameObject {
    
}
