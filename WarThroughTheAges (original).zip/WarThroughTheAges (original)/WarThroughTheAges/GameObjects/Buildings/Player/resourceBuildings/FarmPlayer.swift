//
//  Farm.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 16/02/2021.
//

import QuartzCore
import SceneKit
import UIKit
//MARK:_ THINGS TO DO
// set up max number of workers on resource building
// increase max number of workers for level increase
// work in totalhealth increase for level increase
class FarmPlayer: GameObject {
   var maximumNumberOfWorkers = 5
    
}
