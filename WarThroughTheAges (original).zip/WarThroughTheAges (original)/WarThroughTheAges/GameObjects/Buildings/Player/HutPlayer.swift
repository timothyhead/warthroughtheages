//
//  HutPlayer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 12/02/2021.
//

import UIKit
import SceneKit
import QuartzCore

struct InBuilding {
    static var instance = InBuilding()
    var isInBuilding = Bool()
}
//MARK: - THINGS TO DO
// finilise parameter values except for position
// set up queuee and timer and cost
// in nest class set scene file name
// create is hidden class to be called in goInside hut function
class HutPlayer: UnitCreationBuilding {
    
    var villager = SCNNode() as? VillagerPlayer
    var populationNumbersSupported = Int()
    var populationSupported: Int
    init(totalHealth: Double, defence: Double, fileNamed: String, modelNamed: String, position: SCNVector3, maxiumumUnitsStored: Double, populationSupported: Int, insideHutFileNamed: String) {
        self.populationSupported = populationSupported
        PopulationNumbersSupportedPlayer.instance.maximumNumbers = populationSupported
        super.init(health: totalHealth ,totalHealth: totalHealth, defence: defence,level: 1, fileNamed: fileNamed, modelNamed: modelNamed, position: position, maxiumumUnitsStored: maxiumumUnitsStored, insideBuildingName: "insideHut")
        insideBuilding = InsideBuildingPlayer(fileNamed: insideHutFileNamed, nodeName: insideHutFileNamed)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createGatherer() -> SCNNode {
        let gatherer = GathererPlayer(totalHealth: 100, movementSpeed: 1.5, attackSpeed: 5, range: 0, fileNamed: "testObject", modelNamed: "testObject", position: self.position)
        if let food = Data.instance.gathererCost.food {
            Resource.instance.food -= food
        }
        return gatherer
    }
    func createHunter() -> SCNNode {
        let hunter = HunterPlayer(totalHealth: 125, movementSpeed: 10, attackSpeed: 7, range: Data.instance.rangeHunter, fileNamed: "testObject", modelNamed: "testObject", position: self.position)
        if let food = Data.instance.hunterCost.food , let stone = Data.instance.hunterCost.stone, let wood = Data.instance.hunterCost.wood {
            Resource.instance.food -= food
            Resource.instance.stone -= stone
            Resource.instance.wood -= wood
        }
        return hunter
    }
    override func createVillager() -> SCNNode {
            self.villager = VillagerPlayer(totalHealth: 110,movementSpeed: 0.5, attackSpeed: 6, fileNamed: "testObject", modelNamed: "villager_player_unit", position: self.position)
        if let food = Data.instance.villagerCost.food , let stone = Data.instance.villagerCost.stone, let wood = Data.instance.villagerCost.wood {
            Resource.instance.food -= food
            Resource.instance.stone -= stone
            Resource.instance.wood -= wood
        }
        
        return villager!
    }
 

    
    
}

