//
//  PlasticContainersPlayer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 17/02/2021.
//

import Foundation

class PlasticContainersPlayer: GrannaryPlayer {
    
}
