//
//  LargeTownHallPlayer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 12/02/2021.
//

import Foundation

class LargeTownHallPlayer: HutPlayer {
    
}
