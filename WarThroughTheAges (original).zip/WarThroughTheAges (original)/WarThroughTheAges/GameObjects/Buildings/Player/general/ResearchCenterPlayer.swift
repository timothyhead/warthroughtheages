//
//  ResearchCenterPlayer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 01/04/2021.
//

import Foundation

class ResearchCenterPlayer: GameObject {
    
}
