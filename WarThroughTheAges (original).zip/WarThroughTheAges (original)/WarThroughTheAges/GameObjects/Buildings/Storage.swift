//
//  Grannary.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 05/03/2021.
//

import Foundation
import SceneKit
//MARK:- THINGS TO DO
// Store struct change func if foodobs statements (needs stoneobs ect)
struct ResoucesStored {
    var stone: Double = 0
    var food: Double = 0
    var wood: Double = 0
    var clay: Double = 0
    var gold: Double = 0
    var silver: Double = 0
    var copper: Double = 0
    var tin: Double = 0
    var bronze: Double = 0
    var iron: Double = 0
    var coal: Double = 0
    var power: Double = 0
    var leather: Double = 0
    var textiles: Double = 0
    var oil: Double = 0
    var plastic: Double = 0
    var steel: Double = 0
    
    
}
struct SortStorage {
    var stoneObs = ResourceObserver( name: "stone")
    var foodObs = ResourceObserver( name: "food")
    var woodObs = ResourceObserver( name: "wood")
    var clayObs = ResourceObserver( name: "clay")
    var goldObs = ResourceObserver( name: "gold")
    var silverObs = ResourceObserver( name: "silver")
    var copperObs = ResourceObserver( name: "copper")
    var tinObs = ResourceObserver( name: "tin")
    var bronzeObs = ResourceObserver( name: "bronze")
    var ironObs = ResourceObserver( name: "iron")
    var coalObs = ResourceObserver( name: "coal")
    var powerObs = ResourceObserver( name: "power")
    var leatherObs = ResourceObserver( name: "leather")
    var textilesObs = ResourceObserver( name: "textiles")
    var oilObs = ResourceObserver( name: "oil")
    var plasticObs = ResourceObserver( name: "plastic")
    var steelObs = ResourceObserver( name: "steel")
    var storageFoodDict = [Storage: Double]()
    var storageStoneDict = [Storage: Double]()
    var storageWoodict = [Storage: Double]()
    var storageClayDict = [Storage: Double]()
    var storageGoldDict = [Storage: Double]()
    var storageSilverDict = [Storage: Double]()
    var storageCopperDict = [Storage: Double]()
    var storageTinDict = [Storage: Double]()
    var storageBronzeDict = [Storage: Double]()
    var storageIronDict = [Storage: Double]()
    var storageCoalDict = [Storage: Double]()
    var storagePowerDict = [Storage: Double]()
    var storageLeatherDict = [Storage: Double]()
    var storageTextilesDict = [Storage: Double]()
    var storageOilDict = [Storage: Double]()
    var storagePlasticDict = [Storage: Double]()
    var storageSteelDict = [Storage: Double]()
    
    
    mutating func sort(storageBuilding: SCNNode) {
        change(storagedict: storageFoodDict, storageBuilding: storageBuilding, obs: foodObs)
  
        
        
    }
    mutating func change(storagedict: Dictionary<Storage, Double>, storageBuilding: SCNNode, obs: ResourceObserver) {
        if !obs.hasChanged {
            return
        }
        for obj in GameViewController.world.childNodes {
            if let objName = obj.name {
            if let node = GameViewController.world.childNode(withName: objName, recursively: true) as? Storage {
//                if obs.name == foodObs.name {
//                    self.storageFoodDict[node] = node.numberOFUnitsStored.food
//                }
                switch obs.name {
                case foodObs.name:
                    self.storageFoodDict[node] = node.numberOFUnitsStored.food
                case stoneObs.name:
                    self.storageStoneDict[node] = node.numberOFUnitsStored.stone
                case woodObs.name:
                    self.storageWoodict[node] = node.numberOFUnitsStored.wood
                case clayObs.name:
                    self.storageClayDict[node] = node.numberOFUnitsStored.clay
                case goldObs.name:
                    self.storageGoldDict[node] = node.numberOFUnitsStored.gold
                case silverObs.name:
                    self.storageSilverDict[node] = node.numberOFUnitsStored.silver
                case copperObs.name:
                    self.storageCopperDict[node] = node.numberOFUnitsStored.copper
                case tinObs.name:
                    self.storageTinDict[node] = node.numberOFUnitsStored.tin
                case bronzeObs.name:
                    self.storageBronzeDict[node] = node.numberOFUnitsStored.bronze
                case ironObs.name:
                    self.storageIronDict[node] = node.numberOFUnitsStored.iron
                case coalObs.name:
                    self.storageCoalDict[node] = node.numberOFUnitsStored.coal
                case powerObs.name:
                    self.storagePowerDict[node] = node.numberOFUnitsStored.power
                case leatherObs.name:
                    self.storageLeatherDict[node] = node.numberOFUnitsStored.leather
                case textilesObs.name:
                storageTextilesDict[node] = node.numberOFUnitsStored.textiles
                case oilObs.name:
                    storageOilDict[node] = node.numberOFUnitsStored.oil
                case plasticObs.name:
                    storagePlasticDict[node] = node.numberOFUnitsStored.plastic
                case steelObs.name:
                    storageSteelDict[node] = node.numberOFUnitsStored.steel
                    
                default:
                    break
                }
            }
        }
        }
        hasChanged(dict: storageFoodDict, storageBuilding: storageBuilding as! Storage, obs: foodObs)
        hasChanged(dict: storageStoneDict, storageBuilding: storageBuilding as! Storage, obs: stoneObs)
        hasChanged(dict: storageWoodict, storageBuilding: storageBuilding as! Storage, obs: woodObs)
        hasChanged(dict: storageClayDict, storageBuilding: storageBuilding as! Storage, obs: clayObs)
        hasChanged(dict: storageGoldDict, storageBuilding: storageBuilding as! Storage, obs: goldObs)
        hasChanged(dict: storageSilverDict, storageBuilding: storageBuilding as! Storage, obs: silverObs)
        hasChanged(dict: storageCopperDict, storageBuilding: storageBuilding as! Storage, obs: copperObs)
        hasChanged(dict: storageTinDict, storageBuilding: storageBuilding as! Storage, obs: tinObs)
        hasChanged(dict: storageBronzeDict, storageBuilding: storageBuilding as! Storage, obs: bronzeObs)
        hasChanged(dict: storageIronDict, storageBuilding: storageBuilding as! Storage, obs: ironObs)
        hasChanged(dict: storageCoalDict, storageBuilding: storageBuilding as! Storage, obs: coalObs)
        hasChanged(dict: storagePowerDict, storageBuilding: storageBuilding as! Storage, obs: powerObs)
        hasChanged(dict: storageLeatherDict, storageBuilding: storageBuilding as! Storage, obs: leatherObs)
        hasChanged(dict: storageTextilesDict, storageBuilding: storageBuilding as! Storage, obs: textilesObs)
        hasChanged(dict: storageOilDict, storageBuilding: storageBuilding as! Storage, obs: oilObs)
        hasChanged(dict: storagePlasticDict, storageBuilding: storageBuilding as! Storage, obs: plasticObs)
        hasChanged(dict: storageSteelDict, storageBuilding: storageBuilding as! Storage, obs: steelObs)
//        if foodObs.hasChanged {
//            let max = storageFoodDict.max { a, b in a.value < b.value }
//            if max?.key.name == storageBuilding.name {
//                if (max?.key.numberOFUnitsStored.food)! >= foodObs.difference {
//                    max?.key.numberOFUnitsStored.food -= foodObs.difference
//                } else {
//                    foodObs.difference -= (max?.key.numberOFUnitsStored.food)!
//                    max?.key.numberOFUnitsStored.food = 0
//
//                }
//
//            }
//        }
    }
    mutating func hasChanged(dict: Dictionary<Storage, Double>, storageBuilding: Storage, obs: ResourceObserver) {
        if obs.hasChanged {
            let max = dict.max { a, b in a.value < b.value }
            if max?.key.name == storageBuilding.name {
                switch obs.name {
                case foodObs.name:
                    if (max?.key.numberOFUnitsStored.food)! >= foodObs.difference {
                        max?.key.numberOFUnitsStored.food -= foodObs.difference
                    } else {
                        foodObs.difference -= (max?.key.numberOFUnitsStored.food)!
                        max?.key.numberOFUnitsStored.food = 0
                        
                    }
                case stoneObs.name:
                    if (max?.key.numberOFUnitsStored.stone)! >= stoneObs.difference {
                        max?.key.numberOFUnitsStored.stone -= stoneObs.difference
                    } else {
                        stoneObs.difference -= (max?.key.numberOFUnitsStored.stone)!
                        max?.key.numberOFUnitsStored.stone = 0
                        
                    }
                case woodObs.name:
                    if (max?.key.numberOFUnitsStored.wood)! >= woodObs.difference {
                        max?.key.numberOFUnitsStored.wood -= woodObs.difference
                    } else {
                        woodObs.difference -= (max?.key.numberOFUnitsStored.wood)!
                        max?.key.numberOFUnitsStored.wood = 0
                        
                    }
                case clayObs.name:
                    if (max?.key.numberOFUnitsStored.wood)! >= woodObs.difference {
                        max?.key.numberOFUnitsStored.wood -= woodObs.difference
                    } else {
                        woodObs.difference -= (max?.key.numberOFUnitsStored.wood)!
                        max?.key.numberOFUnitsStored.wood = 0
                        
                    }
                case goldObs.name:
                    if (max?.key.numberOFUnitsStored.gold)! >= goldObs.difference {
                        max?.key.numberOFUnitsStored.gold -= goldObs.difference
                    } else {
                        goldObs.difference -= (max?.key.numberOFUnitsStored.gold)!
                        max?.key.numberOFUnitsStored.wood = 0
                        
                    }
                case silverObs.name:
                    if (max?.key.numberOFUnitsStored.silver)! >= silverObs.difference {
                        max?.key.numberOFUnitsStored.silver -= silverObs.difference
                    } else {
                        silverObs.difference -= (max?.key.numberOFUnitsStored.silver)!
                        max?.key.numberOFUnitsStored.silver = 0
                        
                    }
                case copperObs.name:
                    if (max?.key.numberOFUnitsStored.wood)! >= woodObs.difference {
                        max?.key.numberOFUnitsStored.wood -= woodObs.difference
                    } else {
                        woodObs.difference -= (max?.key.numberOFUnitsStored.wood)!
                        max?.key.numberOFUnitsStored.wood = 0
                        
                    }
                case tinObs.name:
                    if (max?.key.numberOFUnitsStored.tin)! >= tinObs.difference {
                        max?.key.numberOFUnitsStored.tin -= tinObs.difference
                    } else {
                        tinObs.difference -= (max?.key.numberOFUnitsStored.tin)!
                        max?.key.numberOFUnitsStored.tin = 0
                        
                    }
                case bronzeObs.name:
                    if (max?.key.numberOFUnitsStored.bronze)! >= bronzeObs.difference {
                        max?.key.numberOFUnitsStored.bronze -= bronzeObs.difference
                    } else {
                        bronzeObs.difference -= (max?.key.numberOFUnitsStored.bronze)!
                        max?.key.numberOFUnitsStored.bronze = 0
                        
                    }
                case ironObs.name:
                    if (max?.key.numberOFUnitsStored.iron)! >= ironObs.difference {
                        max?.key.numberOFUnitsStored.iron -= ironObs.difference
                    } else {
                        ironObs.difference -= (max?.key.numberOFUnitsStored.iron)!
                        max?.key.numberOFUnitsStored.iron = 0
                        
                    }
                case coalObs.name:
                    if (max?.key.numberOFUnitsStored.coal)! >= coalObs.difference {
                        max?.key.numberOFUnitsStored.coal -= coalObs.difference
                    } else {
                        coalObs.difference -= (max?.key.numberOFUnitsStored.coal)!
                        max?.key.numberOFUnitsStored.coal = 0
                        
                    }
                case powerObs.name:
                    if (max?.key.numberOFUnitsStored.power)! >= powerObs.difference {
                        max?.key.numberOFUnitsStored.power -= powerObs.difference
                    } else {
                        powerObs.difference -= (max?.key.numberOFUnitsStored.power)!
                        max?.key.numberOFUnitsStored.power = 0
                        
                    }
                case leatherObs.name:
                    if (max?.key.numberOFUnitsStored.leather)! >= leatherObs.difference {
                        max?.key.numberOFUnitsStored.leather -= leatherObs.difference
                    } else {
                        leatherObs.difference -= (max?.key.numberOFUnitsStored.leather)!
                        max?.key.numberOFUnitsStored.leather = 0
                        
                    }
                case textilesObs.name:
                    if (max?.key.numberOFUnitsStored.textiles)! >= textilesObs.difference {
                        max?.key.numberOFUnitsStored.textiles -= textilesObs.difference
                    } else {
                        textilesObs.difference -= (max?.key.numberOFUnitsStored.textiles)!
                        max?.key.numberOFUnitsStored.textiles = 0
                        
                    }
                case oilObs.name:
                    if (max?.key.numberOFUnitsStored.oil)! >= oilObs.difference {
                        max?.key.numberOFUnitsStored.oil -= oilObs.difference
                    } else {
                        oilObs.difference -= (max?.key.numberOFUnitsStored.oil)!
                        max?.key.numberOFUnitsStored.oil = 0
                    }
                case plasticObs.name:
                    if (max?.key.numberOFUnitsStored.plastic)! >= plasticObs.difference {
                        max?.key.numberOFUnitsStored.plastic -= plasticObs.difference
                    } else {
                        plasticObs.difference -= (max?.key.numberOFUnitsStored.plastic)!
                        max?.key.numberOFUnitsStored.plastic = 0
                        
                    }
                case steelObs.name:
                    if (max?.key.numberOFUnitsStored.steel)! >= steelObs.difference {
                        max?.key.numberOFUnitsStored.steel -= steelObs.difference
                    } else {
                        steelObs.difference -= (max?.key.numberOFUnitsStored.steel)!
                        max?.key.numberOFUnitsStored.steel = 0
                        
                    }
                default:
                    break
                }
            }
        }
    }
    
}
class Storage: GameObject {
    var numberOFUnitsStored = ResoucesStored()
    var maxiumumUnitsStored: Double
    var maxStored = ResoucesStored()
    var hasDeductedStorage = Bool()
    var sortStorage = SortStorage()
    var currentStorageUnits = Double()
    
    
    init(health: Double, totalHealth: Double, defence: Double, level: Int, fileNamed: String, modelNamed: String, position: SCNVector3, maxiumumUnitsStored: Double) {
        self.maxiumumUnitsStored = maxiumumUnitsStored
    
        super.init(health: health, totalHealth: totalHealth, defence: defence, level: level, fileNamed: fileNamed, modelNamed: modelNamed, position: position)
        self.health = totalHealth
      
       
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    convenience init(totalHealth: Double, defence: Double, fileNamed: String, modelNamed: String, position: SCNVector3, maxiumumUnitsStored: Double) {
        self.init(health: totalHealth, totalHealth: totalHealth, defence: defence, level: 1, fileNamed: fileNamed, modelNamed: modelNamed, position: position, maxiumumUnitsStored: maxiumumUnitsStored)
    }
    convenience init() {
        self.init(health: 0, totalHealth: 0, defence: 0, level: 0, fileNamed: "", modelNamed: "", position: SCNVector3Zero, maxiumumUnitsStored: 0)
    }
    var maxUnits: Double {
        get {
            return  maxiumumUnitsStored
        }
        set {
            
            maxStored.food =  maxiumumUnitsStored
            maxStored.stone =  maxiumumUnitsStored
            maxStored.wood = maxiumumUnitsStored
            maxStored.clay = maxiumumUnitsStored
            maxStored.gold = maxiumumUnitsStored
            maxStored.silver = maxiumumUnitsStored
            maxStored.tin = maxiumumUnitsStored
            maxStored.copper = maxiumumUnitsStored
            maxStored.bronze = maxiumumUnitsStored
            maxStored.iron = maxiumumUnitsStored
            maxStored.coal = maxiumumUnitsStored
            maxStored.power = maxiumumUnitsStored
            maxStored.leather = maxiumumUnitsStored
            maxStored.textiles = maxiumumUnitsStored
            maxStored.oil = maxiumumUnitsStored
            maxStored.plastic = maxiumumUnitsStored
            maxStored.steel = maxiumumUnitsStored
            maxiumumUnitsStored = newValue
            
        }
    }
    
    override func updateDelta(delta: TimeInterval) {
        super.updateDelta(delta: delta)
        if !self.alive() && hasDeductedStorage == false {
            hasDeductedStorage = true
            Resource.instance.food -= numberOFUnitsStored.food
            Resource.instance.coal -= numberOFUnitsStored.coal
            Resource.instance.power -= numberOFUnitsStored.power
            Resource.instance.stone -= numberOFUnitsStored.stone
            Resource.instance.clay -= numberOFUnitsStored.clay
            Resource.instance.bronze -= numberOFUnitsStored.bronze
            Resource.instance.gold -= numberOFUnitsStored.gold
            Resource.instance.silver -= numberOFUnitsStored.silver
            Resource.instance.copper -= numberOFUnitsStored.copper
            Resource.instance.iron -= numberOFUnitsStored.iron
            Resource.instance.leather -= numberOFUnitsStored.leather
            Resource.instance.textiles -= numberOFUnitsStored.textiles
            
        }
        
        sortStorage.foodObs.resource = Resource.instance.food
        if sortStorage.foodObs.hasChanged {
        sortStorage.sort(storageBuilding: self)
            if currentStorageUnits > 0 {
            currentStorageUnits -= sortStorage.foodObs.difference
            }
            
        }
        sortStorage.stoneObs.resource = Resource.instance.stone
        if sortStorage.stoneObs.hasChanged {
        sortStorage.sort(storageBuilding: self)
            if currentStorageUnits > 0 {
            currentStorageUnits -= sortStorage.stoneObs.difference
            }
            
        }
        sortStorage.woodObs.resource = Resource.instance.wood
        if sortStorage.woodObs.hasChanged {
        sortStorage.sort(storageBuilding: self)
            if currentStorageUnits > 0 {
            currentStorageUnits -= sortStorage.woodObs.difference
            }
            
        }
        sortStorage.clayObs.resource = Resource.instance.clay
        if sortStorage.clayObs.hasChanged {
        sortStorage.sort(storageBuilding: self)
            if currentStorageUnits > 0 {
            currentStorageUnits -= sortStorage.clayObs.difference
            }
            
        }
        sortStorage.goldObs.resource = Resource.instance.gold
        if sortStorage.goldObs.hasChanged {
        sortStorage.sort(storageBuilding: self)
            if currentStorageUnits > 0 {
            currentStorageUnits -= sortStorage.goldObs.difference
            }
            
        }
        sortStorage.silverObs.resource = Resource.instance.silver
        if sortStorage.silverObs.hasChanged {
        sortStorage.sort(storageBuilding: self)
            if currentStorageUnits > 0 {
            currentStorageUnits -= sortStorage.silverObs.difference
            }
            
        }
        sortStorage.copperObs.resource = Resource.instance.copper
        if sortStorage.copperObs.hasChanged {
        sortStorage.sort(storageBuilding: self)
            if currentStorageUnits > 0 {
            currentStorageUnits -= sortStorage.copperObs.difference
            }
            
        }
        sortStorage.tinObs.resource = Resource.instance.tin
        if sortStorage.tinObs.hasChanged {
        sortStorage.sort(storageBuilding: self)
            if currentStorageUnits > 0 {
            currentStorageUnits -= sortStorage.tinObs.difference
            }
            
        }
        sortStorage.bronzeObs.resource = Resource.instance.bronze
        if sortStorage.bronzeObs.hasChanged {
        sortStorage.sort(storageBuilding: self)
            if currentStorageUnits > 0 {
            currentStorageUnits -= sortStorage.bronzeObs.difference
            }
            
        }
        
        sortStorage.ironObs.resource = Resource.instance.iron
        if sortStorage.ironObs.hasChanged {
            sortStorage.sort(storageBuilding: self)
            if currentStorageUnits > 0 {
            currentStorageUnits -= sortStorage.ironObs.difference
            }
        }
        sortStorage.coalObs.resource = Resource.instance.coal
        if sortStorage.coalObs.hasChanged {
        sortStorage.sort(storageBuilding: self)
            if currentStorageUnits > 0 {
            currentStorageUnits -= sortStorage.coalObs.difference
            }
            
        }
        sortStorage.powerObs.resource = Resource.instance.power
        if sortStorage.powerObs.hasChanged {
        sortStorage.sort(storageBuilding: self)
            if currentStorageUnits > 0 {
            currentStorageUnits -= sortStorage.powerObs.difference
            }
            
        }
        sortStorage.leatherObs.resource = Resource.instance.leather
        if sortStorage.leatherObs.hasChanged {
        sortStorage.sort(storageBuilding: self)
            if currentStorageUnits > 0 {
            currentStorageUnits -= sortStorage.leatherObs.difference
            }
            
        }
        sortStorage.textilesObs.resource = Resource.instance.textiles
        if sortStorage.textilesObs.hasChanged {
        sortStorage.sort(storageBuilding: self)
            if currentStorageUnits > 0 {
            currentStorageUnits -= sortStorage.textilesObs.difference
            }
            
        }
        sortStorage.oilObs.resource = Resource.instance.oil
        if sortStorage.oilObs.hasChanged {
        sortStorage.sort(storageBuilding: self)
            if currentStorageUnits > 0 {
            currentStorageUnits -= sortStorage.oilObs.difference
            }
            
        }
        sortStorage.plasticObs.resource = Resource.instance.plastic
        if sortStorage.plasticObs.hasChanged {
        sortStorage.sort(storageBuilding: self)
            if currentStorageUnits > 0 {
            currentStorageUnits -= sortStorage.plasticObs.difference
            }
            
        }
        sortStorage.steelObs.resource = Resource.instance.steel
        if sortStorage.steelObs.hasChanged {
        sortStorage.sort(storageBuilding: self)
            if currentStorageUnits > 0 {
            currentStorageUnits -= sortStorage.steelObs.difference
            }
            
        }
    }
    
}
