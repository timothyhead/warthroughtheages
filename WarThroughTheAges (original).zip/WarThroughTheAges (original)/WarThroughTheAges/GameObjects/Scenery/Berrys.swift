//
//  Berrys.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 18/03/2021.
//

import UIKit
import QuartzCore
import SceneKit
struct BerryGen {
    var randomRange = Data.instance.numberOfBerrysRandomlyGenerated
    
    func randomInt() -> Int {
        return Int.random(in: 0...randomRange)
    }
    
   
        
        
    
}
class Berrys: SCNNode {
    var numberOfBerrys = Int()
    var number = BerryGen()
    var id = ID()
    
    override init() {
        let scene = SCNScene(named: "art.scnassets/scenery.scn")!
        let berry = scene.rootNode.childNode(withName: "berrys", recursively: true)!
        berry.name = "berrys_\(id.id)"
       numberOfBerrys = number.randomRange
        super.init()
        self.name = berry.name
        self.addChildNode(berry)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
