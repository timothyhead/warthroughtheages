//
//  HunterPlayer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 15/02/2021.
//

import Foundation

class HunterPlayer: Hunter {
    
}
