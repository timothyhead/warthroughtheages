//
//  VillagerPlayer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 15/02/2021.
//

import Foundation
import SceneKit
// MARK:- THING TO DO
// sort selectedResourceBuilding choice
class VillagerPlayer: Villager {
var storeAlive = Bool()
    func work(selectedResourceBuilding: SCNNode) {
        resourceBuildingWorkedAt = selectedResourceBuilding
        state.currentState = .goingToResources
        var depositry = SCNNode()
        depositry = findNearestStore()
        state.work(node: self, selectedResourceBuilding: selectedResourceBuilding, depositry: depositry)
    }
    func findNearestStore() -> SCNNode {
        var  nearestStore = SCNNode()
        switch role {
        case .food:
        nearestStore = findNearestStore(name: "grannary_player")
        case .stone:
            nearestStore = findNearestStore(name: "quarry_player")
        case .clay:
            nearestStore = findNearestStore(name: "clayCellar_player")
        case .gold, .silver:
            nearestStore = findNearestStore(name: "goldAndSilverDepositry_player")
        case .copper:
            nearestStore = findNearestStore(name: "copperHut_player")
        case .tin:
            nearestStore = findNearestStore(name: "tinHut_player")
        case .bronze:
            nearestStore = findNearestStore(name: "bronzeHut_player")
        case .iron:
            nearestStore = findNearestStore(name: "ironHut_player")
        case .coal:
            nearestStore = findNearestStore(name: "coalBunker_player")
        case .leather:
            nearestStore = findNearestStore(name: "leatherShop_player")
        case .textiles:
            nearestStore = findNearestStore(name: "textileRoom_player")
        default:
            break
        }
        return nearestStore
    }
    override func updateDelta(delta: TimeInterval) {
        super.updateDelta(delta: delta)
        if let store = choosenStore.name {
            let node = GameViewController.world.childNode(withName: store, recursively: true) as? Storage
            if let node = node {
                if !node.alive() && storeAlive  == false  {
                    self.state.currentState = .goingToNearestDepositry
                    self.removeAllActions()
                    work(selectedResourceBuilding: resourceBuildingWorkedAt)
                    storeAlive = true
                }
            }
        
       
        }
    }
  
}
