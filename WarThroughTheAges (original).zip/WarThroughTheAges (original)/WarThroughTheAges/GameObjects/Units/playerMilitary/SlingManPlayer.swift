//
//  SlingMan.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 19/03/2021.
//

import Foundation

class SlingManPlayer: BasicUnit {
    
}
