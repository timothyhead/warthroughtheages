//
//  Gastrophetes.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 24/03/2021.
//

import Foundation

class GastrophetesPlayer: BasicUnit {
    
}
