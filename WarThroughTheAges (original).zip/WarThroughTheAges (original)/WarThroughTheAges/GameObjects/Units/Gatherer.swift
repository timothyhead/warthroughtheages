//
//  Gatherer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 12/02/2021.
//

import UIKit
import QuartzCore
import SceneKit

class Gatherer: BasicUnit {
    var amountOfFoodGathered = Double()
    var maximunFoodCarried: Double  = Data.instance.maxNumberOfUnitsCarriedGatherer
   
 
    var experincePoints: Double {
        get {
            return experince.points
        }
        set {
            experince.points += amountOfFoodGathered
        }
    }
    func findNearestStore(berrys: SCNNode) -> SCNNode {
        var choosenStore = SCNNode()
        for obj in GameViewController.world.childNodes {
            let obj = obj as? Storage
            if let obj = obj {
            if  obj.name?.contains("hut_player") == true || obj.name?.contains("villageHall_player") == true || obj.name?.contains("smallTownHall_player") == true || obj.name?.contains("mediumTownHall_player") == true || obj.name?.contains("largeTownHall_player") == true || obj.name?.contains("smallCastle1_player") == true || obj.name?.contains("mediumCastle_player") == true || obj.name?.contains("largeCastle_player") == true && self.name?.contains("player") == true  {
                _ = GameViewController.world.childNode(withName: obj.name!, recursively: true) as? Storage
                 choosenStore = findDistance(firstNode: berrys, secondNode: obj)
                }
                }
            
        }
           
                     
                     
                    
                for obj in GameViewController.world.childNodes {
                            if  obj.name?.contains("hut_computer") == true || obj.name?.contains("villageHall_computer") == true || obj.name?.contains("smallTownHall_computer") == true || obj.name?.contains("mediumTownHall_computer") == true || obj.name?.contains("largeTownHall_computer") == true || obj.name?.contains("smallCastle_computer") == true || obj.name?.contains("mediumCastle_computer") == true || obj.name?.contains("largeCastle_computer") == true && self.name?.contains("computer") == true  {
                               choosenStore = findDistance(firstNode: berrys, secondNode: obj)
                            }
                        }
        return choosenStore
                    }
    func findBerrys() -> SCNNode? {
       
        var chosenPatch = SCNNode()
       
        for obj in GameViewController.world.childNodes {
            if obj.name?.contains("berrys") == true {
             chosenPatch = findDistance(firstNode: self, secondNode: obj)
            }
           
        }
        return chosenPatch
    }
    func findDistance(firstNode: SCNNode, secondNode: SCNNode) -> SCNNode {
        let find = Distance()
        var minDistance: Float = 1000_000
        var choosenNode = SCNNode()
        let distance = find.distance(firstNode: firstNode, secondNode: secondNode)
        if distance < minDistance {
            minDistance = distance
            choosenNode = secondNode
        }
        return choosenNode
    }
}
