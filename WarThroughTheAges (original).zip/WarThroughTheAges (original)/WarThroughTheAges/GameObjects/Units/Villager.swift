//
//  Villager.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 15/02/2021.
//

import SceneKit

enum Collect {
    case none
    case stone
    case food
    case clay
    case gold
    case silver
    case copper
    case tin
    case bronze
    case iron
    case coal
    case power
    case leather
    case textiles
    case oil
    case wood
}

// MARK:- THINGS TO DO
// check defence in convenience init
class Villager: BasicUnit {
    
    var role: Collect
    var locationToBeWorked = SCNNode()
    var amountOfResourceGathered = Double()
    var maxiumResorceGathered = Double()
    var resourceBuildingWorkedAt = SCNNode()
 //   let state = StatesVillager(currentState: .none)
    var choosenStore = SCNNode()
    var nameOfResouce = String()
    
    init(health: Double, totalHealth: Double,defence: Double, movementSpeed: Float, attackSpeed: Double,range: Double, fileNamed: String, modelNamed: String, level: Int, position: SCNVector3, role: Collect, maxiumResorceGathered: Double) {
        self.role = role
        self.maxiumResorceGathered = maxiumResorceGathered
        super.init(health: health, totalHealth: totalHealth,defence: defence, movementSpeed: movementSpeed, attackSpeed: attackSpeed, range: range, fileNamed: fileNamed, modelNamed: modelNamed, level: level, position: position)
        self.health = totalHealth
        self.level = 1
        
    }
    override init() {
        self.role = .none
        super.init()
    }
    convenience init(totalHealth: Double, movementSpeed: Float, attackSpeed: Double, fileNamed: String, modelNamed: String, position: SCNVector3) {
        self.init(health: totalHealth, totalHealth: totalHealth ,defence: 0, movementSpeed: movementSpeed, attackSpeed: attackSpeed, range: 0, fileNamed: fileNamed, modelNamed: modelNamed,level: 1, position: position,role: .none,maxiumResorceGathered: 10)
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    //    func goAboutBusiness() {
    //        switch role {
    //        case .food:
    //
    //        case .coal:
    //
    //        default:
    //            break
    //        }
    //    }
//    func work() {
//        state.currentState = .goingToResources
//        var farm = SCNNode()
//        var depositry = SCNNode()
//        for obj in GameViewController.world.childNodes {
//            if obj.name == "farm_player" {
//                farm = obj
//
//            }
//            if obj.name == "grannary_player" {
//                depositry = obj
//            }
//        }
//
//        state.work(node: self, selectedResourceBuilding: farm, depositry: depositry)
//    }
    func findNearestStore(name: String) -> SCNNode {
       
        let find = Distance()
        var minDistance: Float = 1000_000
        for obj in GameViewController.world.childNodes {
            let obj = obj as? Storage
            if let obj = obj {
            if obj.name?.contains(name) == true ||  obj.name?.contains("hut_player") == true || obj.name?.contains("villageHall_player") == true || obj.name?.contains("smallTownHall_player") == true || obj.name?.contains("mediumTownHall_player") == true || obj.name?.contains("largeTownHall_player") == true || obj.name?.contains("smallCastle1_player") == true || obj.name?.contains("mediumCastle_player") == true || obj.name?.contains("largeCastle_player") == true && self.name?.contains("player") == true  {
                _ = GameViewController.world.childNode(withName: obj.name!, recursively: true) as? Storage
                let distance = find.distance(firstNode: resourceBuildingWorkedAt, secondNode: obj)
                if distance < minDistance {
                    minDistance = distance
                    choosenStore = obj
                }
                }
                }
        }
           
                     
                     
                    
                for obj in GameViewController.world.childNodes {
                            if obj.name?.contains(name) == true || obj.name?.contains("hut_computer") == true || obj.name?.contains("villageHall_computer") == true || obj.name?.contains("smallTownHall_computer") == true || obj.name?.contains("mediumTownHall_computer") == true || obj.name?.contains("largeTownHall_computer") == true || obj.name?.contains("smallCastle_computer") == true || obj.name?.contains("mediumCastle_computer") == true || obj.name?.contains("largeCastle_computer") == true && self.name?.contains("computer") == true  {
                                let distance = find.distance(firstNode: resourceBuildingWorkedAt, secondNode: obj)
                                if distance < minDistance {
                                    minDistance = distance
                                    choosenStore = obj
                                   
                                }
                            }
                        }
        return choosenStore
                    }
                
               
            
            var experincePoints: Void {
                get {
                    return  experince.points += amountOfResourceGathered
                }
                set {
                   
                }
            }
    override func updateDelta(delta: TimeInterval) {
        super.updateDelta(delta: delta)
        state.updateDelta(delta: delta)
    
        
    }
   
        }
