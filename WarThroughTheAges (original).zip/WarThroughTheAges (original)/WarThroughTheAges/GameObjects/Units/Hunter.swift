//
//  Hunter.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 12/02/2021.
//

import UIKit
import QuartzCore
import SceneKit

class Hunter: BasicUnit {
    
    var amountOfFoodGathered = Double()
    
    func hunt() {
        
    }
    func takeFoodToVilage() {
        
    }
    var experincePoints: Double {
        get {
            return experince.points
        }
        set {
            experince.points += amountOfFoodGathered
        }
    }
}
