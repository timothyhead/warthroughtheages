//
//  BasicUnit.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 04/02/2021.
//

import UIKit
import QuartzCore
import SceneKit

struct PopulationNumbersSupportedPlayer {
    static var instance = PopulationNumbersSupportedPlayer()
    var maxPopulation = Int()
    var currentPopulation = Int()

    
    
   
    var maxPopulationReached: Bool
    {
        get {
            return currentPopulation >= maxPopulation
        }
    }
    var currentPops: Int {
        get {
            return currentPopulation
        }
        set(newValue) {
            currentPopulation = newValue
           
        }
    }
    var maximumNumbers: Int {
        get {
            return maxPopulation
        }
        set(newvalue) {
            maxPopulation += newvalue
        }
    }
}

    struct PopulationNumbersSupportedComputer {
    static var instance = PopulationNumbersSupportedComputer()
    var maxPopulation = 10
    var currentPopulation = Int()
    var maxPopulationReached = Bool()
    
    
   
        var numbers: Bool
        {
            get {
                return currentPopulation >= maxPopulation
            }
            set {
               
            }
        }
    var currentPops: Int {
        get {
            return currentPopulation
        }
        set(newValue) {
            currentPopulation = newValue
           
        }
    }
        var maximumNumbers: Int {
            get {
                return maxPopulation
            }
            set(newvalue) {
                maxPopulation += newvalue
            }
        }
}
//MARK: - THINGS TO DO
// finish attack func switch statements
// change SCNAction times in moveOnToCenterNearestTile() and updateDelta========
// increase population count for computer in init



class BasicUnit: GameObject {
    
  
    var movementSpeed: Float
    var attackSpeed: Double
    var die = RollingDie()
    var weaponType = Weapon()
    var range: Double
    var strength = Double.random(in: 1...3)
    var ismoving = Bool()
    var ovelapingTiles = [SCNNode]()
    var previousPosition = SCNVector3Zero
    var currentPosition = SCNVector3Zero
    var velocity = SCNVector3Zero
    var currentTile: Tile?
    var nextTile = Tile()
    var previousTile = Tile()
    var hasCollided = Bool()
    var armour = Armour()
    var experince = Experince()
    var leaveBuilding = StatesUnitLeaveBuilding(currentState: .leaving)
    let state = StatesVillager(currentState: .none)
    var isDead = Bool()

    
    
    
    init(health: Double, totalHealth: Double,defence: Double, movementSpeed: Float, attackSpeed: Double,range: Double, fileNamed: String, modelNamed: String, level: Int, position: SCNVector3) {
      
        self.movementSpeed = movementSpeed
        self.attackSpeed = attackSpeed
        self.range = range

        super.init(health: health, totalHealth: totalHealth, defence: defence, level: level, fileNamed: fileNamed, modelNamed: modelNamed, position: position)
        self.physicsBody = SCNPhysicsBody.kinematic()
        self.physicsBody?.categoryBitMask = CC.basicUnit.rawValue
        self.physicsBody?.contactTestBitMask = CC.basicUnit.rawValue
        self.health = totalHealth
        if self.name?.contains("player") == true {
        PopulationNumbersSupportedPlayer.instance.currentPops += 1
        } else {
            PopulationNumbersSupportedComputer.instance.currentPops += 1
        }
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    convenience init(totalHealth: Double, movementSpeed: Float, attackSpeed: Double,range: Double, fileNamed: String, modelNamed: String, position: SCNVector3) {
        self.init(health: totalHealth, totalHealth: totalHealth, defence: 0, movementSpeed: movementSpeed, attackSpeed: attackSpeed, range: range, fileNamed: fileNamed, modelNamed: modelNamed, level: 1, position: position)
    }
     init() {
        self.movementSpeed = 0
        self.attackSpeed = 0
        self.range = 0
        super.init(health: 0, totalHealth: 0, defence: 0, level: 1, fileNamed: "", modelNamed: "", position: SCNVector3Zero)
    }
    var damage: Weapon {
        get {
            return weaponType
        }
        set {
            weaponType = newValue
        }
    }
    var defences: Double {
        get {
            var defenceModifier: Double = 0
            if weaponType.type == .spearShort {
                defenceModifier = Data.instance.defenceModifierSpearShort
            } else if weaponType.type == .spearMedium {
                defenceModifier = Data.instance.defenceModifierSpearmedium
            } else if weaponType.type == .spearLong {
                defenceModifier = Data.instance.defenceModifierSpearLong
            }
            if let bodyArmour = armour.armourType {
                defence = bodyArmour.rawValue + armour.helmetType.rawValue
                return bodyArmour.rawValue + armour.helmetType.rawValue + defenceModifier
            } else {
                return 0
            }
        } set(newValue) {
            self.defence = newValue
        }
    }
    var armours: Armour {
        get {
            return armour
        }
        set {
            armour = newValue
        }
    }
    func defend(hit: Double) {
        if !alive() {
            return
        }
        let injury = hit - defence
        if injury > 0 {
            health -= injury
        }
        
        
    }
    func attack(enemy: BasicUnit) {
        
        let unmodifiedHit = damage.type.rawValue + die.roll()
        var hit = Double()
        switch enemy.armour.armourType {
        case .leather:
            switch self.weaponType.damageType {
            case .crushing:
                switch  strength {
                case 3:
                    hit = unmodifiedHit + strength - enemy.armour.helmetType.rawValue
                default:
                    break
                }
            default:
                break
            }
        default:
            break
        }
        experince.points += hit
        enemy.defend(hit: hit)
    }
    
    
    
    
   
    func moveTo(position: SCNVector3) {
        let distanceFinder = CalculateMoveDistance(intialPos: self.position, finalPos: position)
        let distance = distanceFinder.findDistance()
        let action = SCNAction.move(to: position, duration: TimeInterval(distance / self.movementSpeed))
        self.runAction(action)
    }
    func moveOnToCenterNearestTile() {
        let foundTile = findNearestTile()
        if let t = foundTile {
            if velocity == SCNVector3Zero {
                let action = SCNAction.move(to: t.position, duration: 10)
                self.runAction(action)
            }
            
            
            
        }
    }
    private  func findOverLapingTiles() -> [SCNNode] {
        var tiles = [SCNNode]()
        var ovelapingTiles = [SCNNode]()
        tiles.append(contentsOf: GameViewController.world.tileField.childNodes)
        for tile in tiles  {
            let node = box(node: tile)
            if let n = node {
                
                ovelapingTiles.append(n)
            }
            
        }
        return ovelapingTiles
    }
    private func findNearestTile() -> SCNNode? {
        var minx = Float()
        var minz = Float()
        var tile = SCNNode()
        
        for node in  findOverLapingTiles() {
            let x = abs(self.boundingSphere.center.x - node.boundingSphere.center.x)
            let z = abs(self.boundingSphere.center.z - node.boundingSphere.center.z)
            if z < x {
                if minz <= z  {
                    minz = z
                    tile = node
                }
            }
            else if minx <= x {
                minx = x
                tile = node
                
            }
            return tile
        }
        return nil
    }
    
    override func updateDelta(delta: TimeInterval) {
        super.updateDelta(delta: delta)
        if isDead {
            return
        }
        // note previous tile
        if !alive() {
            if self.name?.contains("player") == true {
                PopulationNumbersSupportedPlayer.instance.currentPops -= 1
            } else {
                PopulationNumbersSupportedComputer.instance.currentPops -= 1
            }
         
            self.removeFromParentNode()
            print("dead \(self)")
            isDead = true
        }
      
       currentTile = findNearestTile() as? Tile
        if let current = currentTile {
            tileId = current.id
        }
        // find velocity
        currentPosition = self.position
        velocity = currentPosition - previousPosition
        previousPosition = currentPosition
//        if hasCollided {
//            self.hasCollided = false
//            let action = SCNAction.move(to: previousTile.position, duration: 1)
//            self.runAction(action)
//        }
      
        if leaveBuilding.currentState == .none {
            return
        } else {
        for objs in GameViewController.world.childNodes {
            if self.position == objs.position && leaveBuilding.currentState == .leaving {
                leaveBuilding.leave(unit: self, inBuilding: objs)
               break
            }
        
    
        }
        currentPosition = self.position
        velocity = currentPosition - previousPosition
        previousPosition = currentPosition
        
        }
    }
   
   
        var tileId: (Int, Int) = (1000_000, 0) {
            willSet {
                if nextTile != currentTile {
               previousTile = nextTile
                
                }
               
            }
            didSet(newValue) {
                if newValue != tileId {
                    if let current = currentTile {
                    nextTile = current
                    }
                    
                
            }
        }
    }
}
