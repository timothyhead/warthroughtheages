//
//  VillagerComputer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 15/02/2021.
//

import Foundation
import SceneKit
// MARK:- THING TO DO
// sort selectedResourceBuilding choice
class VillagerComputer: Villager {
   
   func work() {
        var farm = SCNNode()
        state.currentState = .goingToResources
        var depositry = SCNNode()
        depositry = findNearestStore()
        for obj in GameViewController.world.childNodes {
            if obj.name == "farm_computer" {
                farm = obj
            }
        }
    state.work(node: self, selectedResourceBuilding: farm, depositry: depositry)
    }
    func findNearestStore() -> SCNNode {
        var  nearestStore = SCNNode()
        switch role {
        case .food:
        nearestStore = findNearestStore(name: "grannary_computer")
        case .stone:
            nearestStore = findNearestStore(name: "quarry_computer")
        case .clay:
            nearestStore = findNearestStore(name: "clayCellar_computer")
        case .gold, .silver:
            nearestStore = findNearestStore(name: "goldAndSilverDepositry_computer")
        case .copper:
            nearestStore = findNearestStore(name: "copperHut_computer")
        case .tin:
            nearestStore = findNearestStore(name: "tinHut_computer")
        case .bronze:
            nearestStore = findNearestStore(name: "bronzeHut_computer")
        case .iron:
            nearestStore = findNearestStore(name: "ironHut_computer")
        case .coal:
            nearestStore = findNearestStore(name: "coalBunker_computer")
        case .leather:
            nearestStore = findNearestStore(name: "leatherShop_computer")
        case .textiles:
            nearestStore = findNearestStore(name: "textileRoom_computer")
        default:
            break
        }
        return nearestStore
    }
}
