//
//  GameObject.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 11/02/2021.
//

import UIKit
import QuartzCore
import SceneKit
struct ID {
    var id = idgen
    static var idgen: Int = 0
    init() {
        ID.idgen += 1
        id = ID.idgen
    }
}
class GameObject: SCNNode {
    
    var health: Double
    var totalHealth: Double
    var defence: Double
    var level: Int
    var node = SCNNode()
    var fileNamed: String
    var modelNamed: String
    var id = ID()
 
    
    init(health: Double, totalHealth: Double, defence: Double, level: Int, fileNamed: String, modelNamed: String, position: SCNVector3) {
        self.health = totalHealth
        self.totalHealth = totalHealth
        self.defence = defence
        self.level = level       
        self.fileNamed = fileNamed
        self.modelNamed = modelNamed
        if let scene = SCNScene(named: "art.scnassets/\(fileNamed).scn") {
        node = scene.rootNode.childNode(withName: modelNamed, recursively: true)!
        node.position = SCNVector3Zero
            node.name = "\(String(describing: modelNamed)) \(id.id)"
        }
        super.init()
        self.name = node.name
        self.addChildNode(node)
        self.position = position
    }
    convenience  init(totalHealth: Double, defence: Double, fileNamed: String, modelNamed: String, position: SCNVector3) {

        self.init(health: totalHealth, totalHealth: totalHealth, defence: defence, level: 1, fileNamed: fileNamed, modelNamed: modelNamed, position: position)

    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func alive() -> Bool {
        return health > 0
       
    }
    override func updateDelta(delta: TimeInterval) {
        super.updateDelta(delta: delta)
        alive()
        
    }
}
