//
//  SquareTileGrid.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 13/04/2021.
//

import Foundation
import SceneKit

class SquareTileGrid: SCNNode {
  
    override init() {
        super.init()
        GameViewController.world.addChildNode(self)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func tileField(squareNumber: Int, boundingSphereRadius: CGFloat) {
        for i in 0..<squareNumber {
            for j in 0..<squareNumber {
                let squareTile = Tile()
            squareTile.width = boundingSphereRadius + boundingSphereRadius / 2
                squareTile.position = SCNVector3(Float(squareTile.width) * Float(i), 0,Float(squareTile.width) * Float(j))
                squareTile.id = (i, j)
                squareTile.name = "tile \(squareTile.id)"
                squareTile.geometry?.firstMaterial?.diffuse.contents = UIColor.blue
                
                self.addChildNode(squareTile)
            }
                
            }
        }
       
}
