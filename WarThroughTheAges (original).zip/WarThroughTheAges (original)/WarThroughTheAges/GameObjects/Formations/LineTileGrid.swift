//
//  LineTileGrid.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 14/04/2021.
//

import Foundation
import  SceneKit
class LineTileGrid: SCNNode {
    
    override init() {
        super.init()
        GameViewController.world.addChildNode(self)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func tileField(lineLength: Int, boundingSphereRadius: CGFloat) {
        for i in 0..<lineLength {
            for j in 0..<2 {
                let lineTile = Tile()
                lineTile.width = boundingSphereRadius + boundingSphereRadius / 2
                    lineTile.position = SCNVector3(Float(lineTile.width) * Float(i), 0,Float(lineTile.width) * Float(j))
                    lineTile.id = (i, j)
                    lineTile.name = "tile \(lineTile.id)"
                    lineTile.geometry?.firstMaterial?.diffuse.contents = UIColor.blue
                    
                    self.addChildNode(lineTile)
            }
        }
    }
}
