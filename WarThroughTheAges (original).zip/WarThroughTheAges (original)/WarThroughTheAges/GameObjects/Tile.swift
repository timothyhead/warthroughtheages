//
//  CreateFloort.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 05/02/2021.
//

import UIKit
import QuartzCore
import SceneKit

class Tile: SCNNode {
    var id: (Int, Int) = (0, 0)
    var width: CGFloat = 1
    var height: CGFloat = 1
    
    override init() {
        let tile = SCNPlane(width: self.width, height: self.height)
        tile.firstMaterial?.diffuse.contents = UIColor(red: 0.5, green: 0.5, blue: 0, alpha: 1)
        let tileNode = SCNNode(geometry: tile)
        tileNode.rotation = SCNVector4(1, 0, 0, -Float.pi / 2)
        super.init()
        self.addChildNode(tileNode)
        self.name = "tile"
        tile.name = "tile"
        tileNode.name = "tile"
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func getPosition() -> SCNVector3 {
        return  self.position
      
    }
    
}
