//
//  UnitCreationBuilding.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 22/03/2021.
//

import Foundation
import SceneKit



class UnitCreationBuilding: Storage {
    var insideBuilding: InsideBuildingPlayer?
    var productionQueue = ProductionQueue()
    var aNode = SCNNode()
    var insideBuildingName: String
   
    
  init(health: Double, totalHealth: Double, defence:  Double, level: Int, fileNamed: String, modelNamed: String, position: SCNVector3, maxiumumUnitsStored: Double, insideBuildingName : String) {
    self.insideBuildingName = insideBuildingName
    super.init(health: health, totalHealth: totalHealth, defence: defence, level: level, fileNamed: fileNamed, modelNamed: modelNamed, position: position, maxiumumUnitsStored: maxiumumUnitsStored)
        insideBuilding = InsideBuildingPlayer(fileNamed: insideBuildingName, nodeName: insideBuildingName)
    }
   
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createVillager() -> SCNNode {
        return aNode
    }
    
    func createStoneMaceMan() -> SCNNode {
        return aNode
    }
    
    func createAxMan() -> SCNNode {
        return aNode
    }
    
    func createSpearMan() -> SCNNode {
        return aNode
    }
    
    func createJavelinMan() -> SCNNode {
        return aNode
    }
    
    func createSlingMan() -> SCNNode {
        return aNode
    }
    
    func createArcher() -> SCNNode {
        return aNode
    }
    func createSwordMan() -> SCNNode {
        return aNode
    }
    
    
    
    func goInsideBuilding(insideBuildingName: String) {
       
        InBuilding.instance.isInBuilding = true
        GameViewController.world.addChildNode(insideBuilding!)
        insideBuilding?.name = insideBuildingName
        
        for obj in GameViewController.world.childNodes {
            obj.isHidden = true
        }
//        if insideBuilding?.name == "insideBarracks" {
//            if let inside = insideBuilding {
//                inside.enumerateChildNodes { (obj: SCNNode, stop) in
////                    if obj.name == "createSpearManButton" {
////                        if  StatesResearchUnitsPlayer.IsResearchedPlayer.instance.spearShort == true {
////                            obj.isHidden = false
////                        }
////                    }
//                }
//        }
//        }
        GameViewController.world.lightAndCamera.isHidden = false
        insideBuilding?.isHidden = false
        
        
    }
    func leaveBuilding() {
        InBuilding.instance.isInBuilding = false
        self.insideBuilding?.isHidden = true
        for obj in GameViewController.world.childNodes {
            if obj.name == "populationFull" || obj.name == "queueBusy"   {
                continue
            }  else if obj.name == "insideHut" || obj.name == "insideBarracks" {
                obj.isHidden = true
                continue
            }
            obj.isHidden = false
        }
        self.insideBuilding?.isHidden = true
        
    }
    func populationFullOrQueueBusy(fullOrBusy: String) {
        
        InBuilding.instance.isInBuilding = false
        self.insideBuilding?.isHidden = true
        for obj in GameViewController.world.childNodes {
            if obj.name == "populationFull" || obj.name == "queueBusy" || obj.name == "insideHut" || obj.name == "insideBarracks"{
                if fullOrBusy == "full" {
                    aNode = GameViewController.world.populationFullNode
                } else if fullOrBusy == "busy"
                {
                    aNode = GameViewController.world.queueBusyNode
                }
                
                continue
            }
            obj.isHidden = false
        }
        self.insideBuilding?.isHidden = true
        
    
        var t = 0
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { (timer) in
            if t == 3 {

                self.aNode.isHidden = true

                timer.invalidate()
            } else {
                for obj in  GameViewController.world.lightAndCamera.childNodes {
                    if obj.name == "camera" {
                        var pos = Float()
                        if obj.position.z > 0 {
                            pos = -5
                        } else {
                            pos = 5
                        }
                        self.aNode.position = SCNVector3(obj.position.x - 1.5, obj.position.y, obj.position.z + pos)
                        self.aNode.isHidden = false
                        break
                    }
                }
            t += 1
            }
        }
    }
    class InsideBuildingPlayer: SCNNode {
        var node = SCNNode()
        var creaTedSpearManButton = Bool()
        var createdSwordManButton = Bool()
        var createdJavelinButton = Bool()
        var createdSlingerButton = Bool()
        var createdArcherButton = Bool()
        var createdAxeManButton = Bool()
       
        init(fileNamed: String, nodeName: String) {
         
            if let scene = SCNScene(named: "art.scnassets/insideBuilding.scn") {
                node = scene.rootNode.childNode(withName: fileNamed, recursively: true)!
                
            }
            super.init()
           
            self.addChildNode(node)
            self.name = nodeName
            
        }
       
        
        required init?(coder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
        override func updateDelta(delta: TimeInterval) {
            super.updateDelta(delta: delta)
            if self.name != "insideBarracks" {
                return
            }

            if self.name == "insideBarracks" {
             
                   self.enumerateChildNodes { (obj: SCNNode, stop) in
                   
                        if obj.name == "createSpearManButton" && creaTedSpearManButton == false {
                            if  StatesResearchUnitsPlayer.IsResearchedPlayer.instance.spearShort == true  {
                                creaTedSpearManButton = true
                                obj.isHidden = false
                            }
                            } else if obj.name == "createSwordManButton" && createdSwordManButton == false{
                                if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.swordSmall == true {
                                    createdSwordManButton = true
                                    obj.isHidden = false
                                }
                            } else if obj.name == "createJavelinThrowerButton" && createdJavelinButton == false {
                                if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.javelin == true {
                                    createdJavelinButton = true
                                    obj.isHidden = false
                                }
                            } else if obj.name  == "createSlingerButton" && createdSlingerButton == false {
                                if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.sling == true {
                                    createdSlingerButton = true
                                    obj.isHidden = false
                                }
                            } else if obj.name == "createArcherButton" && createdArcherButton == false {
                                if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.bow == true {
                                    createdArcherButton = true
                                    obj.isHidden = false
                                }
                            } else if obj.name == "createAxManButton" && createdAxeManButton  == false {
                             
                                if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.ax == true {
                                    createdAxeManButton = true
                                    obj.isHidden = false
                                }

                           }
                               
                            
                    
            }
                if      StatesResearchUnitsPlayer.IsResearchedPlayer.instance.helmetBronze == true  {
                    revealButtons(buttonName: "chooseAHelmetButton")
                }
                if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.shieldSmall == true {
                    revealButtons(buttonName: "chooseAShieldButton")
                }
                if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.leather == true {
                    revealButtons(buttonName: "chooseLeatherArmour")
                }
                if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.chainMail == true {
                    revealButtons(buttonName: "chooseChainmailButton")
                }
                if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.platemail == true {
                    revealButtons(buttonName: "choosePlateMailButton")
                }
                
              
            }
        }
        func revealButtons(buttonName: String) {
            for obj in GameViewController.world.childNodes {
                if obj.name == "insideBarracks"
                {
                    obj.enumerateChildNodes { (node: SCNNode, stop) in
                        if node.name == buttonName {
                            node.isHidden = false
                        }
                    }
                }
            }
        }
    }
}
