//
//  TitleScreen.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 11/02/2021.
//

import SpriteKit
//MARK:- Things to do
// need image for sprite
class TitleScreen: SKNode {
    
    var sprite = SKSpriteNode(imageNamed: "")
    
    override init() {
        super.init()
        self.addChild(sprite)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
