//
//  LightAndCamera.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 04/02/2021.
//

import UIKit
import QuartzCore
import SceneKit

class LightAndCamera: SCNNode {
    override init() {
        super.init()
    let cameraNode = SCNNode()
    cameraNode.camera = SCNCamera()
        cameraNode.name = "camera"
        self.addChildNode(cameraNode)
    
    // place the camera
    cameraNode.position = SCNVector3(x: 0, y: 3, z: 10)
    
    // create and add a light to the scene
    let lightNode = SCNNode()
    lightNode.light = SCNLight()
    lightNode.light!.type = .omni
    lightNode.position = SCNVector3(x: 0, y: 10, z: 10)
        lightNode.name = "lightAndCamera"
  self.addChildNode(lightNode)
    
    // create and add an ambient light to the scene
    let ambientLightNode = SCNNode()
    ambientLightNode.light = SCNLight()
    ambientLightNode.light!.type = .ambient
    ambientLightNode.light!.color = UIColor.darkGray
        ambientLightNode.name = "lightAndCamera"
        self.addChildNode(ambientLightNode)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
