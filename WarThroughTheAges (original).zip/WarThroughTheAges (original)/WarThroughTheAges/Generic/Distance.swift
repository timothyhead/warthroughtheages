//
//  Distance.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 18/02/2021.
//

import Foundation
import SceneKit

class Distance {
    
    func distance(firstNode: SCNNode, secondNode: SCNNode) -> Float {
        let distancex = abs(firstNode.position.x - secondNode.position.x)
        let distancey = abs(firstNode.position.y - secondNode.position.y)
        let distancez = abs(firstNode.position.z - secondNode.position.z)
        let distance = sqrt(pow(distancex, 2) + pow(distancey, 2) + pow(distancez, 2))
        return distance
    }
}
