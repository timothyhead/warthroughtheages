//
//  Progressbar.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 12/04/2021.
//

import Foundation
import SceneKit

class ProgressBar {
    var isanimatingProgressBar = Bool()
   func progressBar(node: SCNNode, animtionTime: TimeInterval, node1: String, node2: String) {
    if isanimatingProgressBar {
        return
    }
    isanimatingProgressBar = true
    node.enumerateChildNodes({ (ob: SCNNode, stop) in

            
        
  
            if ob.name == node1 {
            for nodes in ob.childNodes {
                    if nodes.name == node2 {
                    for objNodes in nodes.childNodes {
                        var background = SCNNode()
                    if objNodes.name == "backGround" {
                background = objNodes
            }
            if objNodes.name == "progressBar" {
                let beginingPosProgressbarX = Float(-1)
               
                SCNTransaction.begin()
                SCNTransaction.animationDuration = 0

              
                objNodes.scale.x = 0.1
                SCNTransaction.completionBlock={
                    
                                       SCNTransaction.begin()
                    SCNTransaction.animationDuration = animtionTime
                    objNodes.scale.x = background.scale.x
                    objNodes.position.x = background.boundingBox.min.x
                   
                   
                    SCNTransaction.completionBlock={
                        SCNTransaction.begin()
                        SCNTransaction.animationDuration = 0
                        self.isanimatingProgressBar = false
                      
                        SCNTransaction.completionBlock={
                            SCNTransaction.begin()
                            SCNTransaction.animationDuration = 0
                            objNodes.position.x = beginingPosProgressbarX
                            objNodes.scale.x = 0.1
                            SCNTransaction.commit()
                        }
                        SCNTransaction.commit()
                    }
                    SCNTransaction.commit()
                }
                SCNTransaction.commit()
             
              
                
            }
            }
            }
            }
            
    
            }
        }
   ) }
}
