//
//  Resource.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 11/02/2021.
//

import Foundation
//MARK: THING TO DO
// finish resources

class Resource {
    
   static var instance = Resource()
    var stone: Double = 1000
    var food: Double = 1000
    var wood: Double = 1000
    var clay: Double = 1000
    var gold: Double = 1000
    var silver: Double = 1000
    var copper: Double = 1000
    var tin: Double = 1000
    var bronze: Double = 1000
    var iron: Double = 1000
    var coal: Double = 1000
    var power: Double = 1000
    var leather: Double = 1000
    var textiles: Double = 1000
    var oil: Double = 1000
    var plastic: Double = 1000
    var steel: Double = 1000
}
