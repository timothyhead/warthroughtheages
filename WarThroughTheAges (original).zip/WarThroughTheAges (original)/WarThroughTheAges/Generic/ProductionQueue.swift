//
//  Timer.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 16/03/2021.
//


import UIKit
import SceneKit

class ProductionQueue {
    var t: TimeInterval = 0
    var node = BasicUnit()
    var timeInterval = TimeInterval()
    var numberToCreate = 1
    var isCreating = Bool()
    var formationArray = [SCNNode]()

 
    func timer(createUnit: @escaping () -> SCNNode, numberToCreate: Int, timeInterval: TimeInterval, building: UnitCreationBuilding, armour: Armour, weaponType: Weapon, isFormation: Formation) {
      
        t = 0
        isCreating = true
        self.timeInterval = timeInterval
        if isFormation.squareFormation.isSquareFormation  {
            let num = isFormation.squareFormation.squareNumber
            self.numberToCreate = num * num
        } else if isFormation.lineFormation.isLineFormation {
            let num = isFormation.lineFormation.numberInLine
            self.numberToCreate = num * num
        } else {
            self.numberToCreate = numberToCreate
        }
        
        Timer.scheduledTimer(withTimeInterval: timeInterval, repeats: true) {[weak self] (timer)  in
            if PopulationNumbersSupportedPlayer.instance.currentPops >= PopulationNumbersSupportedPlayer.instance.maxPopulation {
                building.populationFullOrQueueBusy(fullOrBusy: "full")
                self?.isCreating = false
                timer.invalidate()
               
                return
            }
         
            DispatchQueue.main.async {
               
                self?.node = createUnit() as! BasicUnit
                self?.node.armours = armour
                self?.node.weaponType.type = weaponType.type
               
            
          
            if let self = self {
                GameViewController.world.addChildNode(self.node)
                self.formationArray.append(self.node)
                self.t += timeInterval
                if Int(self.t) >= self.numberToCreate * Int(timeInterval){
                    self.isCreating = false
                    if isFormation.squareFormation.isSquareFormation {
                        self.squareFormation(squareNumber: isFormation.squareFormation.squareNumber, node: self.node)   
                    } else if isFormation.lineFormation.isLineFormation {
                        self.lineFormtion()
                    } 
                timer.invalidate()
                   
            }
            }
        }
        }
      
        
      
        
    }
    func squareFormation(squareNumber: Int, node: SCNNode) {
        let formation = CreateSquareFormation()
        formation.createFormation(squareNumber: squareNumber, boundingSphereRadius: CGFloat(node.boundingSphere.radius))
        formation.addUnit(unitArray: formationArray)
       
    }
    func lineFormtion() {
        let formation = CreateLineFormation()
       // formation.addUnit(unitArray: formationArray)
    }
    
}
