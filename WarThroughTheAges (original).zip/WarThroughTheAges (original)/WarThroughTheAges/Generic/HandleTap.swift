//
//  HandleTap.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 15/03/2021.
//

import UIKit
import SceneKit
// MARK:- THINGS TO DO
// finish if selected node ect contains ie put in coalMine_Player ect
//finish button names in if statement after if button name  == "createVillagerButton


class HandleTap: SCNNode {
    
    var selectedNode = SelectedNode()
    var number = 1
    var armour = Armour(helmetType: .none, armourType: nil, shieldType: nil)
    var weapon = Weapon(type: .none)
    var insideToSecondLayerBarracks1 = Bool()
    var insideToSecondLayerBarracks2 = Bool()
    var insideToSecondLayerBarracks3 = Bool()
    var insideToSecondLayerBarracks4 = Bool()
    var insideToSecondLayerBarracks5 = Bool()
    var insideToThirdLayerBarracks1 = Bool()
    var backButtonPressed = Bool()
    var progressbar = ProgressBar()
    var vc = PlayerResearchViewController()
    var createMaceManButtonRevealed = Bool()
    var formation = Formation()
    func handleTap(result: SCNHitTestResult, vc: PlayerResearchViewController) {
       number = 1
        self.vc = vc
        // selected node and ring visibility
        selectedNode.node = result.node
        selectedNode.previouslySelectedNode.enumerateChildNodes { (node: SCNNode, stop) in
            if node.name == "ring" {
                node.isHidden = true
            }
        }
        result.node.enumerateChildNodes { (node: SCNNode!, stop) in
            if node.name == "ring" {
                node.isHidden = false
            }
            
        }
        // select villager and then resource building
        
        if selectedNode.previouslySelectedNode.name?.contains("villager_player") == true && ((selectedNode.selectedNode.name?.contains("farm_player") == true || selectedNode.selectedNode.name?.contains("clayPit_player") == true || selectedNode.selectedNode.name?.contains("stoneQuarry_player") == true || selectedNode.selectedNode.name?.contains("copperMine_player") == true || selectedNode.selectedNode.name?.contains("tinMine_player") == true || selectedNode.selectedNode.name?.contains("goldMine_player") == true || selectedNode.selectedNode.name?.contains("ironMine_player") == true || selectedNode.selectedNode.name?.contains("silverMine_player") == true || selectedNode.selectedNode.name?.contains("coalMine_player") == true || selectedNode.selectedNode.name?.contains("ironMine_player") == true || selectedNode.selectedNode.name?.contains("oilWell_player") == true || selectedNode.selectedNode.name?.contains("woods") == true)) {
            
            
            chooseVillagerRole(resourceName: "farm_player", role: .food)
            chooseVillagerRole(resourceName: "clayPit_player", role: .clay)
            chooseVillagerRole(resourceName: "stoneQuarry_player", role: .stone)
            chooseVillagerRole(resourceName: "copperMine_player", role: .copper)
            chooseVillagerRole(resourceName: "tinMine_player", role: .tin)
            chooseVillagerRole(resourceName: "goldMine_player", role: .gold)
            chooseVillagerRole(resourceName: "silverMine_player", role: .silver)
            chooseVillagerRole(resourceName: "coalMine_player", role: .coal)
            chooseVillagerRole(resourceName: "ironMine_player", role: .iron)
            chooseVillagerRole(resourceName: "oilWell_player", role: .oil)
            chooseVillagerRole(resourceName: "woods", role: .wood)
            
        } else if selectedNode.previouslySelectedNode.name?.contains("gatherer_player") == true && selectedNode.selectedNode.name?.contains("berrys") == true {
            let states = StatesGatherer()
            if let gatherer = GameViewController.world.childNode(withName: selectedNode.previouslySelectedNode.name!, recursively: true), let berrys = GameViewController.world.childNode(withName: selectedNode.selectedNode.name!, recursively: true) {
                states.gather(gatherer: gatherer, berrys: berrys)
            }
            
        }
       
        if result.node.name?.contains("hut_player") == true || result.node.name?.contains("villageHall_player") == true || result.node.name?.contains("smallTownHall_player") == true || result.node.name?.contains("mediumTownHall_player") == true  || result.node.name?.contains("largeTownHall_player") == true || result.node.name?.contains("smallCastle1_player") == true || result.node.name?.contains("mediumCastle_player") == true || result.node.name?.contains("largeCastle_player") == true   {
            
            for objs in GameViewController.world.childNodes {
                for obj in objs.childNodes {
                    if obj == result.node {
                        let node = GameViewController.world.childNode(withName: objs.name!, recursively: true) as? HutPlayer
                        if let node = node {
                            node.goInsideBuilding(insideBuildingName: "insideHut")
                          
                        }
                        
                    }
                }
                
            }
            
        }
        if result.node.name == "createVillagerButton" {
        createUnits(result: result, buildingName1: "hut_player", buildingName2: "villageHall_player", buildingName3: "smallTownHall_player", buildingName4: "mediumTownHall_player", buildingName5: "largeTownHall_player", buildingName6: "smallCastle1_player", buildingName7: "mediumCastle_player", buildingName8: "largeCastle_player", buttonName: "createVillagerButton", leaveBuildingButtonName: "leaveHutButton", numberToCreate: number, creationSpeed: Data.instance.creationSpeedVillager)
        }
        
        if result.node.name?.contains("barracks_player") == true  {
      
            for objs in GameViewController.world.childNodes {
                for obj in objs.childNodes {
                    if obj == result.node {
                        let node = GameViewController.world.childNode(withName: objs.name!, recursively: true) as? BarracksPlayer
                        if let node = node {
                            node.goInsideBuilding(insideBuildingName: "insideBarracks")
                          
                        }
                        
                    }
                }
                
            }
          
           
            
        }
      
        createBarrackUnits(result: result, buttonName: "createStoneMaceManButton", creationSpeed: Data.instance.creationSpeedStoneMaceMan)
        createBarrackUnits(result: result, buttonName: "createAxManButton", creationSpeed: Data.instance.creationSpeedAxMan)
        createBarrackUnits(result: result, buttonName: "createSpearManButton", creationSpeed: Data.instance.creationSpeedSpearMan)
        createBarrackUnits(result: result, buttonName: "createSwordManButton", creationSpeed: Data.instance.creationSpeedSwordman)
        createBarrackUnits(result: result, buttonName: "createJavelinThrowerButton", creationSpeed: Data.instance.creationSpeedJavelin)
        createBarrackUnits(result: result, buttonName: "createSlingerButton", creationSpeed: Data.instance.creationSpeedSlingMan)
        createBarrackUnits(result: result, buttonName: "createArcherButton", creationSpeed: Data.instance.creationSpeedArcher)
        
        if result.node.name == "sliderBackground_insideHut" {
            sliders(result: result, insideBuildingName: "insideHut")
        } else if result.node.name == "sliderBackground_insideBarracks" {
            sliders(result: result, insideBuildingName: "insideBarracks")
        }
       // choose helmet
        
        if result.node.name == "chooseAHelmetButton" {
            insideToSecondLayerBarracks1 = true
       
            
        } else if result.node.name == "chooseAShieldButton"  {
         insideToSecondLayerBarracks2 = true
        }
       
        if result.node.name == "chooseBronzeHelmetButton" {
            self.armour.helmetType = .bronze
            returnToInsideBarracks()
          helmetDescriptionTextNodeBarracks(text: "Bronze helmet")
        } else if result.node.name == "chooseIronHelmetButton" {
            self.armour.helmetType = .iron
            returnToInsideBarracks()
           helmetDescriptionTextNodeBarracks(text: "Iron helmet")
        } else if  result.node.name == "chooseSteelHelmetButton" {
            self.armour.helmetType = .steel
            returnToInsideBarracks()
            helmetDescriptionTextNodeBarracks(text: "Steel helmet")
        } else if result.node.name == "BackButton" {
            backButtonPressed = true
            returnToInsideBarracks()
        }
        if result.node.name == "createLargeShield" {
            self.armour.shieldType =  .large
            returnToInsideBarracks()
            shieldDescriptionTextNodeBarracks(text: "Large shield")
            
        } else if result.node.name == "createMediumShield" {
            self.armour.shieldType = .medium
            returnToInsideBarracks()
            shieldDescriptionTextNodeBarracks(text: "Medium shield")
        } else if result.node.name == "createSmallShield" {
            self.armour.shieldType = .small
            returnToInsideBarracks()
            shieldDescriptionTextNodeBarracks(text: "Small shield")
        } else if result.node.name == "chooseLeatherArmour" {
            self.armour.armourType = .leather
            armourDescriptionTextNodeBarracks(text: "Leather armour")
        } else if result.node.name == "chooseChainmailButton" {
            self.armour.armourType = .chainmail
            armourDescriptionTextNodeBarracks(text: "Chainmail")
        } else if result.node.name == "choosePlateMailButton" {
            self.armour.armourType = .plateMail
            armourDescriptionTextNodeBarracks(text: "Platemail")
        }
        if result.node.name == "chooseSwordLengthButton" {
            insideToSecondLayerBarracks3 = true
        }
        else if result.node.name == "chooseSpearLengthButton" {
            insideToSecondLayerBarracks4 = true
        }
        if result.node.name == "shortSwordButton" {
            self.weapon.type = .swordShort
            returnToInsideBarracks()
            lengthSwordDescriptionTextNodeBarracks(text: "short sword")
        } else if result.node.name == "mediumSwordButton" {
            self.weapon.type = .swordMedium
            lengthSwordDescriptionTextNodeBarracks(text: "medium sword")
            returnToInsideBarracks()
        } else if result.node.name == "longSwordButton" {
            self.weapon.type = .swordLong
            lengthSwordDescriptionTextNodeBarracks(text: "long Sword")
            returnToInsideBarracks()
        } else if result.node.name == "shortSpearButton" {
            self.weapon.type = .spearShort
            returnToInsideBarracks()
            lengthSpearDescriptionTextNodeBarracks(text: "short spear")
        } else if result.node.name == "mediumSpearButton" {
            self.weapon.type = .spearMedium
            returnToInsideBarracks()
            lengthSpearDescriptionTextNodeBarracks(text: "medium spear")
        } else if result.node.name == "longspearButton" {
            self.weapon.type = .spearLong
            returnToInsideBarracks()
            lengthSpearDescriptionTextNodeBarracks(text: "long spear")
        }
        if result.node.name == "formationButton" {
            insideToSecondLayerBarracks5 = true
        } else if result.node.name == "squareFormation" {
           insideToThirdLayerBarracks1 = true
            
         
        } else if result.node.name == "lineFormation" {
            formation.lineFormation.isLineFormation = true
        } else  if result.node.name == "number4Button" {
            formation.squareFormation.squareNumber = 2
            formation.squareFormation.isSquareFormation = true
        } else if result.node.name == "number16Button" {
            formation.squareFormation.squareNumber = 4
            formation.squareFormation.isSquareFormation = true
        } else if result.node.name == "number32Button" {
            formation.squareFormation.squareNumber = 8
            formation.squareFormation.isSquareFormation = true
        }
       
     
    }
    func helmetDescriptionTextNodeBarracks(text: String) {
        descriptionTextNodeINBarracks(text: text, obName: "description text node_helmet")
    }
    func shieldDescriptionTextNodeBarracks(text: String) {
        descriptionTextNodeINBarracks(text: text, obName: "description text node_shield")
    }
    func armourDescriptionTextNodeBarracks(text: String) {
        descriptionTextNodeINBarracks(text: text, obName: "description text node_armour")
    }
    func lengthSwordDescriptionTextNodeBarracks(text: String) {
        descriptionTextNodeINBarracks(text: text, obName: "description text node_sword")
    }
    func lengthSpearDescriptionTextNodeBarracks(text: String) {
        descriptionTextNodeINBarracks(text: text, obName: "description text node_spear")
    }
    func descriptionTextNodeINBarracks(text: String, obName: String) {
        var texts = String()
        for node in GameViewController.world.childNodes {
            if node.name == "insideBarracks" {
        node.enumerateChildNodes { (ob, stop) in
            if ob.name == obName {
                texts += text
                if let textGeo = ob.geometry as?
                    SCNText {
                    textGeo.string = String(texts)
                }
                }
                    
                }
            }
        }
       
    }
    func createBarrackUnits(result: SCNHitTestResult, buttonName: String, creationSpeed: TimeInterval) {
        createUnits(result: result, buildingName1: "barracks_player", buildingName2: "", buildingName3: "", buildingName4: "", buildingName5: "", buildingName6: "", buildingName7: "", buildingName8: "", buttonName: buttonName, leaveBuildingButtonName: "leaveBarracksButton", numberToCreate: number, creationSpeed: creationSpeed)
    }
    func createUnits(result: SCNHitTestResult, buildingName1: String, buildingName2: String, buildingName3: String, buildingName4: String, buildingName5: String, buildingName6: String, buildingName7: String, buildingName8: String, buttonName: String, leaveBuildingButtonName: String, numberToCreate: Int, creationSpeed: TimeInterval)  {
            
        
        if result.node.name == buttonName || result.node.name == leaveBuildingButtonName {
         
            for objs in GameViewController.world.childNodes {
                if objs.name?.contains(buildingName1) == true || objs.name?.contains(buildingName2) == true || objs.name?.contains(buildingName3) == true || objs.name?.contains(buildingName4) == true || objs.name?.contains(buildingName5) == true || objs.name?.contains(buildingName6) == true || objs.name?.contains(buildingName7) == true || objs.name?.contains(buildingName8) == true {
                   
                   let node = GameViewController.world.childNode(withName: objs.name!, recursively: true)! as! UnitCreationBuilding
                    if  buttonName == "createVillagerButton" {
                        let createMyUnit = node.createVillager
                        leaveTheBuildingOfChoice(result: result, node: node, buttonName: buttonName, leaveBuildingButtonName: leaveBuildingButtonName, createMyUnit: createMyUnit, creationSpeed: creationSpeed, numberToCreate: numberToCreate)
                    } else if buttonName == "createStoneMaceManButton" {
                        
                        let createMyUnit = node.createStoneMaceMan
                        leaveTheBuildingOfChoice(result: result, node: node, buttonName: buttonName, leaveBuildingButtonName: leaveBuildingButtonName, createMyUnit: createMyUnit, creationSpeed: creationSpeed, numberToCreate: numberToCreate)
                    } else if buttonName == "createSpearManButton" {
                        let createMyUnit = node.createSpearMan
                        leaveTheBuildingOfChoice(result: result, node: node, buttonName: buttonName, leaveBuildingButtonName: leaveBuildingButtonName, createMyUnit: createMyUnit, creationSpeed: creationSpeed, numberToCreate: numberToCreate)
                    } else if buttonName == "createSwordManButton" {
                        let createMyUnit = node.createSwordMan
                        leaveTheBuildingOfChoice(result: result, node: node, buttonName: buttonName, leaveBuildingButtonName: leaveBuildingButtonName, createMyUnit: createMyUnit, creationSpeed: creationSpeed, numberToCreate: numberToCreate)
                    } else if buttonName == "createJavelinThrowerButton" {
                        let createMyUnit = node.createJavelinMan
                        leaveTheBuildingOfChoice(result: result, node: node, buttonName: buttonName, leaveBuildingButtonName: leaveBuildingButtonName, createMyUnit: createMyUnit, creationSpeed: creationSpeed, numberToCreate: numberToCreate)
                    } else if buttonName == "createSlingerButton" {
                        let createMyUnit = node.createSlingMan
                        leaveTheBuildingOfChoice(result: result, node: node, buttonName: buttonName, leaveBuildingButtonName: leaveBuildingButtonName, createMyUnit: createMyUnit, creationSpeed: creationSpeed, numberToCreate: numberToCreate)
                    } else if buttonName == "createArcherButton" {
                        let createMyUnit = node.createArcher
                        leaveTheBuildingOfChoice(result: result, node: node, buttonName: buttonName, leaveBuildingButtonName: leaveBuildingButtonName, createMyUnit: createMyUnit, creationSpeed: creationSpeed, numberToCreate: numberToCreate)
                    } else if buttonName == "createAxManButton" {
                        let createMyUnit = node.createAxMan
                        leaveTheBuildingOfChoice(result: result, node: node, buttonName: buttonName, leaveBuildingButtonName: leaveBuildingButtonName, createMyUnit: createMyUnit, creationSpeed: creationSpeed, numberToCreate: numberToCreate)
                    }
            }
        }
        }
    }
    func sliders(result: SCNHitTestResult, insideBuildingName: String) {
     
        if let node = GameViewController.world.childNode(withName: insideBuildingName, recursively: true) {
            node.enumerateChildNodes({ ( obj: SCNNode, stop) in
                
                if obj.name == "slider" {
                    let action = SCNAction.move(to: SCNVector3(result.localCoordinates.x, obj.position.y, obj.position.z), duration: 0.5)
                    DispatchQueue.main.async {
                        obj.runAction(action) 
                    }
                    let backgroundLength = result.node.boundingBox.min.x -
                        result.node.boundingBox.max
                        .x
                    let sliderMinX = result.node.boundingBox.min.x
                    
                    number  =
                        Int(((sliderMinX  - result.localCoordinates.x) / backgroundLength) * 10)
                    if number < 1 {
                        number = 1
                    }
                    node.enumerateChildNodes { (ob, stop) in
                        if ob.name == "sliderTextNode" {
                            if let textGeo = ob.geometry as?
                                SCNText {
                                textGeo.string = String(number)
                                
                            }
                        }
                        
                        
                    }
                    
                }
            })
            
            
            
        }
    }
    func leaveTheBuildingOfChoice(result: SCNHitTestResult, node: UnitCreationBuilding, buttonName: String,leaveBuildingButtonName: String, createMyUnit: @escaping () -> SCNNode, creationSpeed: TimeInterval, numberToCreate: Int) {
       
        if let insideBuilding = node.insideBuilding {
        for obj in insideBuilding.childNodes {
            for ob in obj.childNodes {
                if ob == result.node && ob.name == buttonName {
                   
                        if PopulationNumbersSupportedPlayer.instance.maxPopulationReached == false && node.productionQueue.isCreating == false {
                            let unit = node.productionQueue.timer(createUnit: createMyUnit, numberToCreate: numberToCreate, timeInterval: creationSpeed, building: node, armour: armour, weaponType: weapon, isFormation: formation)
                            let animationTime = (node.productionQueue.timeInterval * TimeInterval(node.productionQueue.numberToCreate)) + node.productionQueue.timeInterval
                            progressbar.progressBar(node: insideBuilding, animtionTime: animationTime, node1: "numberControl", node2: "progressBarNode")
                          
                            node.leaveBuilding()
                            
                            return
                        
                        } else if PopulationNumbersSupportedPlayer.instance.maxPopulationReached == true {
                            node.populationFullOrQueueBusy(fullOrBusy: "full")
                            return
                        } else {
                        node.leaveBuilding()
                            node.populationFullOrQueueBusy(fullOrBusy: "busy")
                        }
                    
                    
                    
                    
                } else if ob == result.node && ob.name == leaveBuildingButtonName {
                    node.leaveBuilding()
                    
                }
            }
            }
        }
    }
    func chooseVillagerRole(resourceName: String, role: Collect) {
        if selectedNode.selectedNode.name?.contains(resourceName) == false {
            return
        }
        if selectedNode.selectedNode.name?.contains(resourceName) == true {
            
            let node = GameViewController.world.childNode(withName: selectedNode.previouslySelectedNode.name!, recursively: true) as? VillagerPlayer
            let node2 = GameViewController.world.childNode(withName: selectedNode.selectedNode.name!, recursively: true)
            if let node = node {
                if let node2 = node2 {
                    node.role = role
                    
                    node.work(selectedResourceBuilding: node2)
                }
                
            }
        }
    }
  
    func returnToInsideBarracks() {
        loop:  for obj in GameViewController.world.childNodes {
            if obj.name == "lightAndCamera" {
                continue
            }
            if obj.name == "insideBarracks" {
                obj.isHidden = false
                for o in obj.childNodes {
                    for ob in o.childNodes {
                        if ob.name == "chooseBronzeHelmetButton" || ob.name == "chooseIronHelmetButton" || ob.name ==  "chooseSteelHelmetButton"  || ob.name == "BackButton" || ob.name == "createMediumShield"  || ob.name == "createLargeShield" || ob.name == "createSmallShield" || ob.name == "shortSwordButton" || ob.name == "mediumSwordButton" || ob.name == "longSwordButton" || ob.name == "shortSpearButton" || ob.name == "mediumSpearButton" || ob.name == "longspearButton" || ob.name == "squareFormation" || ob.name == "lineFormation" || ob.name == "ringFormation" || ob.name == "number16Button" || ob.name == "number32Button" || ob.name == "number4Button" 
    {
                        ob.isHidden
                         = true
                        continue
                        } else if ob.name == "OkTextNode" && backButtonPressed == false {
                            ob.isHidden = false
                            let action = SCNAction.fadeIn(duration: 1)
                            let action2 = SCNAction.fadeOut(duration: 3)
                            let sequence = SCNAction.sequence([action, action2])
                            DispatchQueue.main.async {
                                ob.runAction(sequence) 
                            }
                           
                      
                    } else {
                        ob.isHidden = false
                    }
                    
                }
                }
          
             
            }
           
            
        }
        backButtonPressed = false
        
    }
    func revealButtons(buttonName1: String, buttonName2: String, buttonName3: String) {
    for obj in GameViewController.world.childNodes {
        if obj.name == "lightAndCamera" {
            continue
        }
    if obj.name == "insideBarracks"
    {
        for ob in obj.childNodes {
            if ob.name == "insideBarracks" {
            
                for o in ob.childNodes {
                    if o.name == buttonName1 || o.name == buttonName2 || o.name == buttonName3 || o.name == "BackButton" {

               o.isHidden = false
            } else {
               o.isHidden = true
            }
        }
            }
        }
    }
    }
    



}
    override func updateDelta(delta: TimeInterval) {
        super.updateDelta(delta: delta)
        if InBuilding.instance.isInBuilding {
            for obj in GameViewController.world.childNodes {
                if obj.name?.contains("unit") == true {
                    obj.isHidden = true
                }
            }
        }
        if insideToSecondLayerBarracks1 == true {
           insideToSecondLayerBarracks1 = false
            if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.helmetBronze == true && StatesResearchUnitsPlayer.IsResearchedPlayer.instance.helmetIron == false {
                revealButtons(buttonName1: "chooseBronzeHelmetButton", buttonName2: "", buttonName3: "")
            }
            if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.helmetIron == true && StatesResearchUnitsPlayer.IsResearchedPlayer.instance.helmetSteel == false {
               revealButtons(buttonName1: "chooseBronzeHelmetButton", buttonName2: "chooseIronHelmetButton", buttonName3: "")
            }
            if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.helmetSteel == true {
               revealButtons(buttonName1: "chooseBronzeHelmetButton", buttonName2: "chooseIronHelmetButton", buttonName3: "chooseSteelHelmetButton")
            }
        }
        if insideToSecondLayerBarracks2 == true {
           insideToSecondLayerBarracks2 = false
            if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.shieldSmall == true && StatesResearchUnitsPlayer.IsResearchedPlayer.instance.shieldMedium == false {
                revealButtons(buttonName1: "createSmallShield", buttonName2: "", buttonName3: "")
            }
            if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.shieldMedium == true && StatesResearchUnitsPlayer.IsResearchedPlayer.instance.shieldLarge == false {
               revealButtons(buttonName1: "createSmallShield", buttonName2: "createMediumShield", buttonName3: "")
            }
            if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.shieldLarge == true {
               revealButtons(buttonName1: "createSmallShield", buttonName2: "createMediumShield", buttonName3: "createLargeShield")
            }
        }
        if insideToSecondLayerBarracks3 == true {
           insideToSecondLayerBarracks3 = false
            if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.swordSmall == true && StatesResearchUnitsPlayer.IsResearchedPlayer.instance.swordMedium == false {
                revealButtons(buttonName1: "shortSwordButton", buttonName2: "", buttonName3: "")
            }
            if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.swordMedium == true && StatesResearchUnitsPlayer.IsResearchedPlayer.instance.swordLong == false {
                revealButtons(buttonName1: "shortSwordButton", buttonName2: "mediumSwordButton", buttonName3: "")
            }
            if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.swordLong == true {
            revealButtons(buttonName1: "shortSwordButton", buttonName2: "mediumSwordButton", buttonName3: "longSwordButton")
            }
        }
        if insideToSecondLayerBarracks4 == true {
           insideToSecondLayerBarracks4 = false
            if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.spearShort == true && StatesResearchUnitsPlayer.IsResearchedPlayer.instance.spearMedium == false {
                revealButtons(buttonName1: "shortSpearButton", buttonName2: "", buttonName3: "")
            }
            if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.spearMedium == true && StatesResearchUnitsPlayer.IsResearchedPlayer.instance.spearLong == false {
                revealButtons(buttonName1: "shortSpearButton", buttonName2: "mediumSpearButton", buttonName3: "")
            }
            if StatesResearchUnitsPlayer.IsResearchedPlayer.instance.spearLong == true {
                revealButtons(buttonName1: "shortSpearButton", buttonName2: "mediumSpearButton", buttonName3: "longspearButton")
            }
           
        }
        if insideToSecondLayerBarracks5 == true {
           insideToSecondLayerBarracks5 = false
            if vc.researchStates.bronzeWorking == .none{
            revealButtons(buttonName1: "squareFormation", buttonName2: "lineFormation", buttonName3: "ringFormation")
            }
        }
        if insideToThirdLayerBarracks1 == true {
            insideToThirdLayerBarracks1 = false
            revealButtons(buttonName1: "number16Button", buttonName2: "number32Button", buttonName3: "number4Button")
        }
        if vc.researchStates.bronzeWorking == .bronzeworking && createMaceManButtonRevealed == false {
            createMaceManButtonRevealed = true
            for obj in GameViewController.world.childNodes {
                if obj.name == "insideBarracks" {
                    for ob in obj.childNodes {
                        if ob.name == "insideBarracks" {
                            for node in ob.childNodes {
                                if node.name == "createStoneMaceManButton" {
                                    node.isHidden = false
                                }
                                
                                }
                        }
                    }
                }
            }
        }
    }
   
}

