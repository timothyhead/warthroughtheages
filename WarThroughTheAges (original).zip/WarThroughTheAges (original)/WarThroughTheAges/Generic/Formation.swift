//
//  Formation.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 14/04/2021.
//

import Foundation
import SceneKit

struct Formation {
    var squareFormation = SquareFormation()
    var lineFormation = LineFormation()

    
    
}
struct SquareFormation {
    var isSquareFormation = Bool()
    var squareNumber = Int()
}
struct LineFormation {
    var isLineFormation = Bool()
var numberInLine = Int()
}
