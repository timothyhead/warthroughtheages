//
//  Experince.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 12/02/2021.
//

import Foundation


class Experince {
    
    var points = Double()
    var level = Int()
    
    func increaseLevel() {
        switch points {
        case 100...200:
            level = 2
        case 201...1000:
            level = 3
        default:
            break
        }
    }
}
