//
//  GameViewControllerExtension.swift
//  tobedeleted
//
//  Created by Timothy Head on 04/02/2021.
//

import UIKit
import QuartzCore
import SceneKit

extension UIViewController: SCNPhysicsContactDelegate {
  
    func isCollisionBetween(nodeTypeOne: CC,nodeTypeTwo: CC, contact: SCNPhysicsContact) -> Bool {
        var isANodeTypeOne = Bool()
        var isANodeTypeTwo = Bool()
        var isBNodeTypeOne = Bool()
        var isBNodeTypeTwo = Bool()
        
        if let node1A = contact.nodeA.physicsBody {
            isANodeTypeOne = node1A.categoryBitMask == nodeTypeOne.rawValue
            isANodeTypeTwo = node1A.categoryBitMask == nodeTypeTwo.rawValue
        }
        if let node1B = contact.nodeB.physicsBody {
            isBNodeTypeOne = node1B.categoryBitMask == nodeTypeOne.rawValue
            isBNodeTypeTwo = node1B.categoryBitMask == nodeTypeTwo.rawValue
        }

        if (isANodeTypeOne && isBNodeTypeTwo) || (isANodeTypeTwo && isBNodeTypeOne) {
            return true
        } else {
            return false
        }
    }
    public func physicsWorld(_ world: SCNPhysicsWorld, didBegin contact: SCNPhysicsContact) {
     
        if isCollisionBetween(nodeTypeOne: CC.basicUnit, nodeTypeTwo: CC.basicUnit, contact: contact) {
            if contact.nodeA.name?.contains("villager_player") == true || contact.nodeA.name?.contains("stoneMaceMan_player") == true {
                let node = contact.nodeA as? BasicUnit
                if let n = node {
                    if n.velocity == SCNVector3Zero && n.state.currentState == .inactive && n.leaveBuilding.currentState == .none {
                        n.removeAllActions()
                        var action = SCNAction()
                       var x = Int.random(in: -1...1), z = Int.random(in: -1...1)
                        while x == 0 && z == 0 {
                            x =  Int.random(in: -1...1)
                            z =  Int.random(in: -1...1)
                        }
                        DispatchQueue.main.async {
                            action = SCNAction.move(to: SCNVector3(n.position.x + Float(x), 0, n.position.z + Float(z)), duration: 3)
                           n.runAction(action)
                        }
                        
                    }
                }
            }
            if contact.nodeB.name?.contains("villager_player") == true || contact.nodeB.name?.contains("stoneMaceMan_player") == true {
                let node = contact.nodeB as? BasicUnit
                if let n = node {
                    if n.velocity == SCNVector3Zero && n.state.currentState == .none && n.leaveBuilding.currentState == .none {
                        n.removeAllActions()
                        var action = SCNAction()
                       var x = Int.random(in: -1...1), z = Int.random(in: -1...1)
                        while x == 0 && z == 0 {
                            x =  Int.random(in: -1...1)
                            z =  Int.random(in: -1...1)
                        }
                        DispatchQueue.main.async {
                            action = SCNAction.move(to: SCNVector3(n.position.x + Float(x), 0, n.position.z + Float(z)), duration: 3)
                           n.runAction(action)
                        }
                       
                    }
                }
            }
            
        }
        

    }
}
