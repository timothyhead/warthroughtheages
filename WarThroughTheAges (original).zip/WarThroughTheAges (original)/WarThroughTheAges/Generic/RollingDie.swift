//
//  RollingDie().swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 04/02/2021.
//

import Foundation

class RollingDie {
    
    private var nSidesCount: Double
    
    init(nSidesCount: Double) {
        self.nSidesCount = nSidesCount
    }
    convenience init() {
        
        self.init(nSidesCount: 20)
    }
    func roll() -> Double{
        return Double.random(in: 1...nSidesCount)
    }
    
}
