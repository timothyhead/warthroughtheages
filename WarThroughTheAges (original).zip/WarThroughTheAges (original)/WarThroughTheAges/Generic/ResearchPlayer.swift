//
//  Research.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 18/02/2021.
//

import Foundation

class ResearchPlayer: Research {
    
    
}
