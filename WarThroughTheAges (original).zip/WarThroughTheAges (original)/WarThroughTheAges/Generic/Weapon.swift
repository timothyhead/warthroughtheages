//
//  Weapon.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 05/02/2021.
//

import Foundation

// MARK: - THINGS TO DO
// complete enums in class
class Weapon {
    enum Types: Double {
        case none = 0
        case stoneMace = 3
        case axe = 5
        case spearShort = 4
        case spearMedium = 7
        case spearLong = 6
        case swordShort = 8
        case swordMedium = 9
        case swordLong = 10
        case javelin = 11
        case bow = 12
        case sling = 13
    }
    enum DamageType {
        case none
        case crushing
        case cutting
        case piercing
        case slashing
    }
    var type: Types
    var damageType: DamageType
    
    init(type: Types) {
        self.type = type
        switch type {
        case .none:
            damageType = .none
        case .stoneMace:
            damageType = .crushing
        case .axe:
            damageType = .cutting
        case .spearShort, .spearMedium, .spearLong:
            damageType = .piercing
        case .swordShort, .swordMedium, .swordLong:
            damageType = .slashing
        case .javelin:
            damageType = .piercing
        case .bow:
            damageType = .piercing
        case .sling:
            damageType = .crushing
     
        }

       
    }
    convenience init() {
        self.init(type: Types.none)
       
    }
}

