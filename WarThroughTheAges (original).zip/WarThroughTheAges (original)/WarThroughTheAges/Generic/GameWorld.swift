//
//  GameWorld.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 08/02/2021.
//

import QuartzCore
import SceneKit
import UIKit
//MARK:- THINHGS TO DO
// finish create building func in ext  ie values when creating hut and list other buildings
class GameWorld: SCNNode {
    let storyboard = UIStoryboard(name: "Main", bundle: nil)
    var vc = CreateBuildingTableViewController()
    var researchStates = StatesResearchPlayer()
    let tileField = TileField()
    var populationFullNode = SCNNode()
    var queueBusyNode = SCNNode()
    var  insideBuildingCamera: UnitCreationBuilding.InsideBuildingPlayer?
    var hutplayer: HutPlayer? = HutPlayer(totalHealth: 100, defence: 10, fileNamed: "testObject", modelNamed: "hut_player", position: SCNVector3(-3, 0, 0), maxiumumUnitsStored: 20, populationSupported: 40, insideHutFileNamed: "insideHut")
    var hutplayer2: HutPlayer? = HutPlayer(totalHealth: 100, defence: 10, fileNamed: "testObject", modelNamed: "hut_player", position: SCNVector3(5, 0, -3), maxiumumUnitsStored: 20, populationSupported: 40, insideHutFileNamed: "insideHut")
   // let hall = MediumTownHallComputer(totalHealth: 500, defence: 50, fileNamed: "testObject", modelNamed: "testObject", position: SCNVector3(-3, 0, 0))
    let farm = FarmPlayer(totalHealth: 100, defence: 5, fileNamed: "testObject", modelNamed: "farm_player", position: SCNVector3(2, 0, 0))
    let farm2 = FarmPlayer(totalHealth: 100, defence: 5, fileNamed: "testObject", modelNamed: "farm_player", position: SCNVector3(4, 0, 0))
    let lightAndCamera = LightAndCamera()
   // var villager = VillagerPlayer()
    var grannary: GrannaryPlayer? = GrannaryPlayer(health: 100, totalHealth: 100, defence: 5, level: 1, fileNamed: "testObject", modelNamed: "grannary_player", position: SCNVector3(0, 0, 0), maxiumumUnitsStored: 100)
    var grannary2: GrannaryPlayer? = GrannaryPlayer(health: 100, totalHealth: 100, defence: 5, level: 1, fileNamed: "testObject", modelNamed: "grannary_player", position: SCNVector3(-2, 0, 3), maxiumumUnitsStored: 100)
    var ironMine = IronMinePlayer(totalHealth: 100, defence: 100, fileNamed: "testObject", modelNamed: "ironMine_player", position: SCNVector3(5, 0, 3))
   // var smallCastle = SmallCastlePlayer(totalHealth: 100, defence: 100, fileNamed: "testObject", modelNamed: "smallCastle1_player", position: SCNVector3(4, 0, 1), maxiumumUnitsStored: 20, populationSupported: 3)
   // var largeCastle = LargeCastlePlayer(totalHealth: 100, defence: 100, fileNamed: "testObject", modelNamed: "largeCastle_player", position: SCNVector3(4, 0, -1), maxiumumUnitsStored: 20, populationSupported: 3)
    var berry = Berrys()
    var berry2 = Berrys()
    var gatherer = GathererPlayer(totalHealth: 100, movementSpeed: 10, attackSpeed: 1, range: 0, fileNamed: "testObject", modelNamed: "gatherer_player_unit", position: SCNVector3(-2, 0, 0))
    var barracks = BarracksPlayer(totalHealth: 100, defence: 5, fileNamed: "militaryBuildings", modelNamed: "barracks_player", position: SCNVector3(3, 0, 3))
    var states = StatesResearchComputer()
    var researchCenter = ResearchCenterPlayer(totalHealth: 100, defence: 100, fileNamed: "generalBuildings", modelNamed: "researchCenter_player", position: SCNVector3(1, 0, -3))
    
 
    override init() {
        let populationFullGeo = SCNText(string: "POPULATION FULL", extrusionDepth: 2)
        populationFullNode = SCNNode(geometry: populationFullGeo)
        populationFullGeo.firstMaterial?.diffuse.contents = UIColor.systemIndigo
        populationFullNode.scale = SCNVector3(0.025, 0.025, 0.025)
        populationFullNode.name = "populationFull"
        populationFullNode.isHidden = true
        let queueBusyGeo = SCNText(string: "QUEUE BUSY", extrusionDepth: 2)
         queueBusyNode = SCNNode(geometry: queueBusyGeo)
        queueBusyNode.scale  = SCNVector3(0.025, 0.025, 0.025)
        queueBusyNode.name = "queueBusy"
        queueBusyNode.isHidden = true
        berry.position.y = 2
        berry2.position.y = 4
        hutplayer?.maxUnits = 20
        hutplayer2?.maxUnits = 20
        states.researchStone()
        super.init()
        self.name = "gameWorld"
        self.addChildNode(populationFullNode)
        self.addChildNode(queueBusyNode)
        self.addChildNode(farm)
        self.addChildNode(farm2)
        self.addChildNode(tileField)
        self.addChildNode(hutplayer!)        
        self.addChildNode(hutplayer2!)
        self.addChildNode(lightAndCamera)
        self.addChildNode(berry)
        self.addChildNode(berry2)
        self.addChildNode(gatherer)
        self.addChildNode(barracks)
        self.addChildNode(researchCenter)
        lightAndCamera.name = "lightAndCamera"
       // self.addChildNode(grannary)
       // self.addChildNode(grannary2)
        self.addChildNode(ironMine)
      //  self.addChildNode(smallCastle)
      //  self.addChildNode(largeCastle)
        ResourcePlayer.instance.food = 100
        ResourcePlayer.instance.wood = 100
        ResourcePlayer.instance.bronze = 100
        createBuildings()
     
       
       
   
      
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createBuildings() {
      vc = (storyboard.instantiateViewController(identifier: "buildingTableVC") as? CreateBuildingTableViewController)!
        vc.delegate = self
    
    }
    
    
}
extension GameWorld: CreateBuilding {
    func createBuilding(buildingType: BuildingType) {
        if buildingType == .hut {
            let hut = HutPlayer(totalHealth: 100, defence: 100, fileNamed: "testObject", modelNamed: "hut_player", position: SCNVector3(-2, 3, -2), maxiumumUnitsStored: 100, populationSupported: 3, insideHutFileNamed: "insideHut")
            self.addChildNode(hut)
        }
    }

}

