//
//  resourceObserver.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 09/03/2021.
//

import Foundation

struct ResourceObserver {
    var hasChanged = Bool()
    var difference = Double()
    var name: String
    var resource: Double  = 0 {
        didSet(oldValue) {
            if resource < oldValue {
                hasChanged = true
                difference =  oldValue - resource
            } else {
                hasChanged = false
            }
        }
    }
}
