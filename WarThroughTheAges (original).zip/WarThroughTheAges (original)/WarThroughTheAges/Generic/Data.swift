//
//  Data.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 12/02/2021.
//

import Foundation
// MARK:- THINGS TO dO
// Townhall onwards for  civiliain creation Buildings: allow only if Research.researchedBuilding = true
struct ResourceCosts {
    var stone: Double? = nil
    var food: Double? = nil
    var wood: Double? = nil
    var clay: Double? = nil
    var gold: Double? = nil
    var silver: Double? = nil
    var copper: Double? = nil
    var tin: Double? = nil
    var bronze: Double? = nil
    var iron: Double?  = nil
    var coal: Double?  = nil
    var power: Double? = nil
    var leather: Double? = nil
    var textiles: Double? = nil
    var oil: Double? = nil
    var plastic: Double? = nil
    var steel: Double? = nil
    
    func unwrapp() -> [String: Double]{
        var resourceDictionary = [String: Double]()
        if let food = food {
            resourceDictionary["food"] = food
        }
        if let stone = stone {
            resourceDictionary["stone"] = stone
        }
        if let wood = wood {
            resourceDictionary["wood"] = wood
        }
        if let clay = clay {
            resourceDictionary["clay"] = clay
        }
        if let gold = gold {
            resourceDictionary["gold"] = gold
        }
        if let silver = silver {
            resourceDictionary["silver"] = silver
        }
        if let copper = copper {
            resourceDictionary["copper"] = copper
        }
        if let tin = tin {
            resourceDictionary["tin"] = tin
        }
        if let bronze = bronze {
            resourceDictionary["bronze"] = bronze
        }
        if let iron = iron {
            resourceDictionary["iron"] = iron
        }
        if let coal = coal {
            resourceDictionary["coal"] = coal
        }
        if let power = power {
            resourceDictionary["power"] = power
        }
        if let leather = leather {
            resourceDictionary["leather"] = leather
        }
        if let textiles = textiles {
            resourceDictionary["textiles"] = textiles
        }
        if let oil = oil {
            resourceDictionary["oil"] = oil
        }
        if let plastic = plastic {
            resourceDictionary["plastic"] = plastic
        }
        if let steel = steel {
            resourceDictionary["steel"] = steel
        }
        
        return resourceDictionary
    }

}

class Data {
    
    static let instance = Data()
    var intialFood = Int()
    var initialCoal = Int()
    var initialPower = Int()
    // MARK:- civiliain creation Buildings
    var numberInHutlevel1 = Int()
    var numberInHutlevel2 = Int()
    var numberInHutlevel3 = Int()
    var numberInHutlevel4 = Int()
    
    var costOfHut = Resource.instance.wood
    var creationSpeedHut: TimeInterval = 10
    var IncreaseHutTolevel2 = Resource.instance.wood
    var IncreaseHutTolevel3 = Resource.instance.wood
    var IncreaseHutTolevel4 = Resource.instance.wood
    var totalHealthHut = Int()
    
    var numberInVillageHalllevel1 = Int()
    var numberInVillageHalllevel2 = Int()
    var numberInVillageHalllevel3 = Int()
    var numberInVillageHalllevel4 = Int()
    
    var costOfVillageHall = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedVillageHall: TimeInterval = 50
    var IncreaseVillageHallTolevel2 = (Resource.instance.wood, Resource.instance.stone)
    var IncreaseVillageHallTolevel3 = (Resource.instance.wood, Resource.instance.stone)
    var IncreaseVillageHallTolevel4 = (Resource.instance.wood, Resource.instance.stone)
    var totalHealthVillageHall = Int()
    
    var numberInTownHalllevel1 = Int()
    var numberInTownHalllevel2 = Int()
    var numberInTownHalllevel3 = Int()
    var numberInTownHalllevel4 = Int()
    
    var costOfTownHall = (Resource.instance.wood, Resource.instance.clay)
    var creationSpeedHTownHall: TimeInterval = 100
    var IncreaseTownHallTolevel2 = (Resource.instance.wood, Resource.instance.stone)
    var IncreaseTownHallTolevel3 = (Resource.instance.wood, Resource.instance.stone)
    var IncreaseTownHallTolevel4 = (Resource.instance.wood, Resource.instance.stone)
    var totalHealthTownHall = Int()
    
    var numberInMediumTownHalllevel1 = Int()
    var numberInMediumTownHalllevel2 = Int()
    var numberInMediumTownHalllevel3 = Int()
    var numberInMediumTownHalllevel4 = Int()
    
    var costOfMediumTownHall = (Resource.instance.wood, Resource.instance.clay)
    var creationSpeedHMediumTownHall: TimeInterval = 150
    var IncreaseMediumTownHallTolevel2 = (Resource.instance.wood, Resource.instance.stone)
    var IncreaseMediumTownHallTolevel3 = (Resource.instance.wood, Resource.instance.stone)
    var IncreaseMediumTownHallTolevel4 = (Resource.instance.wood, Resource.instance.stone)
    var totalHealthHMediumTownHall = Int()
    
    var numberInLargeTownHalllevel1 = Int()
    var numberInLargeTownHalllevel2 = Int()
    var numberInLargeTownHalllevel3 = Int()
    var numberInLargeTownHalllevel4 = Int()
    
    var costOfLargeTownHall = (Resource.instance.wood, Resource.instance.clay)
    var creationSpeedLargeTownHall: TimeInterval = 200
    var IncreaseLargeTownHallTolevel2 = (Resource.instance.wood, Resource.instance.stone)
    var IncreaseLargeTownHallTolevel3 = (Resource.instance.wood, Resource.instance.stone)
    var IncreaseLargeTownHallTolevel4 = (Resource.instance.wood, Resource.instance.stone)
    var totalHealthLargeTownHall = Int()
    
    var numberOfCitizensInSmallCastleLevel1 = Int()
    var numberOfCitizensInSmallCastleLevel2 = Int()
    var numberOfCitizensInSmallCastleLevel3 = Int()
    var numberOfCitizensInSmallCastleLevel4 = Int()
    
    var costOfSmallCastle = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedHSmallCastle: TimeInterval = 300
    var IncreaseSmallCastleTolevel2 = (Resource.instance.wood, Resource.instance.stone)
    var IncreaseSmallCastleTolevel3 = (Resource.instance.wood, Resource.instance.stone)
    var IncreaseSmallCastleTolevel4 = (Resource.instance.wood, Resource.instance.stone)
    var totalHealthSmallCastle = Int()
    
    var numberOfCitizensInMediumCastleLevel1 = Int()
    var numberOfCitizensInMediumCastleLevel2 = Int()
    var numberOfCitizensInMediumCastleLevel3 = Int()
    var numberOfCitizensInMediumCastleLevel4 = Int()
    
    var costOfMediumCastle = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedMediumCastle: TimeInterval = 350
    var IncreaseMediumCastleTolevel2 = (Resource.instance.wood, Resource.instance.stone)
    var IncreaseMediumCastleTolevel3 = (Resource.instance.wood, Resource.instance.stone)
    var IncreaseMediumCastleTolevel4 = (Resource.instance.wood, Resource.instance.stone)
    var totalHealthMediumCastle = Int()
    
    var numberOfCitizensInLargeCastleLevel1 = Int()
    var numberOfCitizensInLargeCastleLevel2 = Int()
    var numberOfCitizensInLargeCastleLevel3 = Int()
    var numberOfCitizensInLargeCastleLevel4 = Int()
    
    var costOfLargeCastle = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedLargeCastle: TimeInterval = 400
    var IncreaseLargeCastleTolevel2 = (Resource.instance.wood, Resource.instance.stone)
    var IncreaseLargeCastleTolevel3 = (Resource.instance.wood, Resource.instance.stone)
    var IncreaseLargeCastleTolevel4 = (Resource.instance.wood, Resource.instance.stone)
    var totalHealthLargeCastle = Int()
    
    var numberOfTroopsInSmallCastleLevel1 = Int()
    var numberOfTroopsInSmallCastleLevel2 = Int()
    var numberOfTroopsInSmallCastleLevel3 = Int()
    var numberOfTroopsInSmallCastleLevel4 = Int()
    
    var numberOfTroopsInMediumCastleLevel1 = Int()
    var numberOfTroopsInMediumCastleLevel2 = Int()
    var numberOfTroopsInMediumCastleLevel3 = Int()
    var numberOfTroopsInMediumCastleLevel4 = Int()
    
    var numberOfTroopsInLargeCastleLevel1 = Int()
    var numberOfTroopsInLargeCastleLevel2 = Int()
    var numberOfTroopsInLargeCastleLevel3 = Int()
    var numberOfTroopsInLargeCastleLevel4 = Int()
    
    // MARK:-gather
    var totalHealthPointsGathererLevel1 = Int()
    var totalHealthPointsGathererLevel2 = Int()
    var totalHealthPointsGathererLevel3 = Int()
    var totalHealthPointsGathererLevel4 = Int()
  
    var attackSpeedGathererLevel1 = Int()
    var attackSpeedGathererLevel2 = Int()
    var attackSpeedGathererLevel3 = Int()
    var attackSpeedGathererLevel4 = Int()
    
    var movementSpeedGathererLevel1 = Int()
    var movementSpeedGathererLevel2 = Int()
    var movementSpeedGathererLevel3 = Int()
    var movementSpeedGathererLevel4 = Int()
    
    var creationSpeedGatherer: TimeInterval = 10
    
    var gathererCost = ResourceCosts(food: 10)
    var maxNumberOfUnitsCarriedGatherer: Double = 10
    // MARK:-hunter
    var totalHealthPointsHunterLevel1 = Int()
    var totalHealthPointsHunterLevel2 = Int()
    var totalHealthPointsHunterLevel3 = Int()
    var totalHealthPointsHunterLevel4 = Int()
    
    var attackSpeedHunterLevel1 = Int()
    var attackSpeedHunterLevel2 = Int()
    var attackSpeedHunterLevel3 = Int()
    var attackSpeedHunterLevel4 = Int()
    
    var rangeHunter: Double = 2
    
    var movementSpeedHunterLevel1 = Int()
    var movementSpeedHunterLevel2 = Int()
    var movementSpeedHunterLevel3 = Int()
    var movementSpeedHunterLevel4 = Int()
    
    var creationSpeedHunter : TimeInterval = 15
    
    var hunterCost = ResourceCosts(stone: 10, food: 10, wood: 10)
    
   
    // MARK:- villager
    var totalHealthPointsVillagerLevel1 = 100
    var totalHealthPointsVillagerLevel2 = Int()
    var totalHealthPointsVillagerLevel3 = Int()
    var totalHealthPointsVillagerLevel4 = Int()
    
    var attackSpeedVillagerLevel1 = 5
    var attackSpeedVillagerLevel2 = Int()
    var attackSpeedVillagerLevel3 = Int()
    var attackSpeedVillagerLevel4 = Int()
    
    var movementSpeedVillagerLevel1 = 5
    var movementSpeedVillagerLevel2 = Int()
    var movementSpeedVillagerLevel3 = Int()
    var movementSpeedVillagerLevel4 = Int()
    
    var creationSpeedVillager : TimeInterval = 5
    
    var villagerCost = ResourceCosts(stone: 10, food: 10, wood: 10)
    
    // MARK:- resource buildings
    var numberOfWorkersFarmLevel1 = Int()
    var numberOfWorkersFarmLevel2 = Int()
    var numberOfWorkersFarmLevel3 = Int()
    var numberOfWorkersFarmLevel4 = Int()
    
    var costOfFarm = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedFarm: TimeInterval = 40
    var IncreaseFarmTolevel2 = (Resource.instance.clay)
    var IncreaseFarmTolevel3 = (Resource.instance.clay)
    var IncreaseFarmTolevel4 = (Resource.instance.clay)
    var totalHealthFarm = Int()
    
    var numberOfWorkersClayPitLevel1 = Int()
    var numberOfWorkersClayPitLevel2 = Int()
    var numberOfWorkersClayPitLevel3 = Int()
    var numberOfWorkersClayPitLevel4 = Int()
    
    var costOfClayPit = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedClayPit: TimeInterval = 40
    var IncreaseClayPitTolevel2 = (Resource.instance.clay)
    var IncreaseClayPitTolevel3 = (Resource.instance.clay)
    var IncreaseClayPitTolevel4 = (Resource.instance.clay)
    var totalHealthClayPit = Int()
    
    var numberOfWorkersStoneQuarryLevel1 = Int()
    var numberOfWorkersStoneQuarryLevel2 = Int()
    var numberOfWorkersStoneQuarryLevel3 = Int()
    var numberOfWorkersStoneQuarryLevel4 = Int()
    
    var costOfStoneQuarry = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedStoneQuarry: TimeInterval = 40
    var IncreaseStoneQuarryTolevel2 = (Resource.instance.clay)
    var IncreaseStoneQuarryTolevel3 = (Resource.instance.clay)
    var IncreaseStoneQuarryTolevel4 = (Resource.instance.clay)
    var totalHealthStoneQuarry = Int()
    
    var numberOfWorkersCopperMineLevel1 = Int()
    var numberOfWorkersCopperMineLevel2 = Int()
    var numberOfWorkersCopperMineLevel3 = Int()
    var numberOfWorkersCopperMineLevel4 = Int()
    
    var costOfCopperMine = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedCopperMine: TimeInterval = 40
    var IncreaseCopperMineTolevel2 = (Resource.instance.clay)
    var IncreaseCopperMineTolevel3 = (Resource.instance.clay)
    var IncreaseCopperMineTolevel4 = (Resource.instance.clay)
    var totalHealthCopperMine = Int()
    
    var numberOfWorkersTinMineLevel1 = Int()
    var numberOfWorkersTinMineLevel2 = Int()
    var numberOfWorkersTinMineLevel3 = Int()
    var numberOfWorkersTinMineLevel4 = Int()
    
    var costOfTinMine = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedTinMine: TimeInterval = 40
    var IncreaseTinMineTolevel2 = (Resource.instance.clay)
    var IncreaseTinMineTolevel3 = (Resource.instance.clay)
    var IncreaseTinMineTolevel4 = (Resource.instance.clay)
    var totalHealthTinMine = Int()
    
    var numberOfWorkersGoldMineLevel1 = Int()
    var numberOfWorkersGoldMineLevel2 = Int()
    var numberOfWorkersGoldMineLevel3 = Int()
    var numberOfWorkersGoldMineLevel4 = Int()
    
    var costOfGoldMine = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedGoldMine: TimeInterval = 40
    var IncreaseGoldMineTolevel2 = (Resource.instance.clay)
    var IncreaseGoldMineTolevel3 = (Resource.instance.clay)
    var IncreaseGoldMineTolevel4 = (Resource.instance.clay)
    var totalHealthGoldMine = Int()
    
    var numberOfWorkersSilverMineLevel1 = Int()
    var numberOfWorkersSilverMineLevel2 = Int()
    var numberOfWorkersSilverMineLevel3 = Int()
    var numberOfWorkersSilverMineLevel4 = Int()
    
    var costOfSilverMine = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedSilverMine: TimeInterval = 40
    var IncreaseSilverMineTolevel2 = (Resource.instance.clay)
    var IncreaseSilverMineTolevel3 = (Resource.instance.clay)
    var IncreaseSilverMineTolevel4 = (Resource.instance.clay)
    var totalHealthSilverMine = Int()
    
    var numberOfWorkersIronMineLevel1 = Int()
    var numberOfWorkersIronMineLevel2 = Int()
    var numberOfWorkersIronMineLevel3 = Int()
    var numberOfWorkersIronMineLevel4 = Int()
    
    var costOfIronMine = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedIronMine: TimeInterval = 40
    var IncreaseIronMineTolevel2 = (Resource.instance.clay)
    var IncreaseIronMineTolevel3 = (Resource.instance.clay)
    var IncreaseIronMineTolevel4 = (Resource.instance.clay)
    var totalHealthIronMine = Int()
    
    var numberOfWorkersOilWellLevel1 = Int()
    var numberOfWorkersOilWellLevel2 = Int()
    var numberOfWorkersOilWellLevel3 = Int()
    var numberOfWorkersOilWellLevel4 = Int()
    
    var costOfOilWell = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedOilWell: TimeInterval = 40
    var IncreaseOilWellTolevel2 = (Resource.instance.clay)
    var IncreaseOilWellTolevel3 = (Resource.instance.clay)
    var IncreaseOilWellTolevel4 = (Resource.instance.clay)
    var totalHealthOilWell = Int()
    
    // MARK:- storage
    var numberOfUnitsGrannaryLevel1 = Int()
    var numberOfUnitsGrannaryLevel2 = Int()
    var numberOfUnitsGrannaryLevel3 = Int()
    var numberOfUnitsGrannaryLevel4 = Int()
    
    var costOfGrannary = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedGrannary: TimeInterval = 40
    var IncreaseGrannaryTolevel2 = (Resource.instance.clay)
    var IncreaseGrannaryTolevel3 = (Resource.instance.clay)
    var IncreaseGrannaryTolevel4 = (Resource.instance.clay)
    var totalHealthGrannary = Int()
    
    var numberOfUnitsWoodHutLevel1 = Int()
    var numberOfUnitsWoodHutLevel2 = Int()
    var numberOfUnitsWoodHutLevel3 = Int()
    var numberOfUnitsWoodHutLevel4 = Int()
    
    var costOfWoodHut = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedWoodHut: TimeInterval = 40
    var IncreaseWoodHutTolevel2 = (Resource.instance.wood)
    var IncreaseWoodHutTolevel3 = (Resource.instance.wood)
    var IncreaseWoodHutTolevel4 = (Resource.instance.wood)
    var totalHealthWoodHut = Int()
    
    var numberOfUnitsLeatherShopLevel1 = Int()
    var numberOfUnitsLeatherShopLevel2 = Int()
    var numberOfUnitsLeatherShopLevel3 = Int()
    var numberOfUnitsLeatherShopLevel4 = Int()
    
    var costOfLeatherShop = (Resource.instance.wood)
    var creationSpeedLeatherShop: TimeInterval = 40
    var IncreaseLeatherShopTolevel2 = (Resource.instance.wood)
    var IncreaseLeatherShopTolevel3 = (Resource.instance.wood)
    var IncreaseLeatherShopTolevel4 = (Resource.instance.wood)
    var totalHealthLeatherShop = Int()
    
    var numberOfUnitsClayCellarLevel1 = Int()
    var numberOfUnitsClayCellarLevel2 = Int()
    var numberOfUnitsClayCellarLevel3 = Int()
    var numberOfUnitsClayCellarLevel4 = Int()
    
    var costOfClayCellar = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedClayCellar: TimeInterval = 40
    var IncreaseClayCellarTolevel2 = (Resource.instance.wood, Resource.instance.stone)
    var IncreaseClayCellarTolevel3 = (Resource.instance.wood, Resource.instance.stone)
    var IncreaseClayCellarTolevel4 = (Resource.instance.wood, Resource.instance.stone)
    var totalHealthClayCellar = Int()
    
    var numberOfUnitsCoalBunkerLevel1 = Int()
    var numberOfUnitsCoalBunkerLevel2 = Int()
    var numberOfUnitsCoalBunkerLevel3 = Int()
    var numberOfUnitsCoalBunkerLevel4 = Int()
    
    var costOfCoalBunker = (Resource.instance.wood, Resource.instance.clay)
    var creationSpeedCoalBunker: TimeInterval = 40
    var IncreaseCoalBunkerTolevel2 = (Resource.instance.wood, Resource.instance.clay)
    var IncreaseCoalBunkerTolevel3 = (Resource.instance.wood, Resource.instance.clay)
    var IncreaseCoalBunkerTolevel4 = (Resource.instance.wood, Resource.instance.clay)
    var totalHealthCoalBunker = Int()
    
    var numberOfUnitsCopperHutLevel1 = Int()
    var numberOfUnitsCopperHutLevel2 = Int()
    var numberOfUnitsCopperHutLevel3 = Int()
    var numberOfUnitsCopperHutLevel4 = Int()
    
    var costOfCopperHut = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedCopperHut: TimeInterval = 40
    var IncreaseCopperHutTolevel2 = (Resource.instance.clay)
    var IncreaseCopperHutTolevel3 = (Resource.instance.clay)
    var IncreaseCopperHutTolevel4 = (Resource.instance.clay)
    var totalHealthCopperHut = Int()
    
    var numberOfUnitsTinHutLevel1 = Int()
    var numberOfUnitsTinHutLevel2 = Int()
    var numberOfUnitsTinHutLevel3 = Int()
    var numberOfUnitsTinHutLevel4 = Int()
    
    var costOfTinHut = (Resource.instance.wood)
    var creationSpeedTinHut: TimeInterval = 40
    var IncreaseTinHutTolevel2 = (Resource.instance.wood)
    var IncreaseTinHutTolevel3 = (Resource.instance.wood)
    var IncreaseTinHutTolevel4 = (Resource.instance.wood)
    var totalHealthTinHut = Int()
    
    var numberOfUnitsBronzeHutLevel1 = Int()
    var numberOfUnitsBronzeHutLevel2 = Int()
    var numberOfUnitsBronzeHutLevel3 = Int()
    var numberOfUnitsBronzeHutLevel4 = Int()
    
    var costOfBronzeHut = (Resource.instance.wood)
    var creationSpeedBronzeHut: TimeInterval = 40
    var IncreaseBronzeHutTolevel2 = (Resource.instance.wood)
    var IncreaseBronzeHutTolevel3 = (Resource.instance.wood)
    var IncreaseBronzeHutTolevel4 = (Resource.instance.wood)
    var totalHealthBronzeHut = Int()
    
    var numberOfUnitsIronHutLevel1 = Int()
    var numberOfUnitsIronHutLevel2 = Int()
    var numberOfUnitsIronHutLevel3 = Int()
    var numberOfUnitsIronHutLevel4 = Int()
    
    var costOfIronHut = (Resource.instance.wood)
    var creationSpeedIronHut: TimeInterval = 40
    var IncreaseIronHutTolevel2 = (Resource.instance.wood)
    var totalHealthIronHut = Int()
    
    var numberOfUnitsGoldAndSilverDepositryLevel1 = Int()
    var numberOfUnitsGoldAndSilverDepositryLevel2 = Int()
    var numberOfUnitsGoldAndSilverDepositryLevel3 = Int()
    var numberOfUnitsGoldAndSilverDepositryLevel4 = Int()
    
    var costOfGoldAndSilverDepositry = (Resource.instance.stone)
    var creationSpeedGoldAndSilverDepositry: TimeInterval = 40
    var IncreaseGoldAndSilverDepositryTolevel2 = (Resource.instance.stone)
    var IncreaseGoldAndSilverDepositryTolevel3 = (Resource.instance.stone)
    var IncreaseGoldAndSilverDepositryTolevel4 = (Resource.instance.stone)
    var totalHealthGoldAndSilverDepositry = Int()
    
    var numberOfUnitsPlasticContainersLevel1 = Int()
    var numberOfUnitsPlasticContainersLevel2 = Int()
    var numberOfUnitsPlasticContainersLevel3 = Int()
    var numberOfUnitsPlasticContainersLevel4 = Int()
    
    var costOfPlasticContainers = (Resource.instance.wood, Resource.instance.stone)
    var creationSpeedPlasticContainers: TimeInterval = 40
    var IncreasePlasticContainersTolevel2 = (Resource.instance.steel)
    var IncreasePlasticContainersTolevel3 = (Resource.instance.steel)
    var IncreasePlasticContainersTolevel4 = (Resource.instance.steel)
    var totalHealthPlasticContainers = Int()
    
    var numberOfUnitsTextileRoomLevel1 = Int()
    var numberOfUnitsTextileRoomLevel2 = Int()
    var numberOfUnitsTextileRoomLevel3 = Int()
    var numberOfUnitsTextileRoomLevel4 = Int()
    
    var costOfTextileRoom = (Resource.instance.clay)
    var creationSpeedTextileRoom: TimeInterval = 40
    var IncreaseTextileRoomTolevel2 = (Resource.instance.clay)
    var IncreaseTextileRoomTolevel3 = (Resource.instance.clay)
    var IncreaseTextileRoomTolevel4 = (Resource.instance.clay)
    var totalHealthTextileRoom = Int()
    
    
    // MARK:- timing of research
 
    var oldStoneAgeResearchTime: TimeInterval = 1
    
    var newStoneAgeResearchTime: TimeInterval = 1
    var quarryResearchTime: TimeInterval = 1
    var beginningOfAgricultureResearchTime: TimeInterval = 1
    var beginningOfAnimalHusbandryResearchTime: TimeInterval = 1
    var beginningOfIrrigationResearchTime: TimeInterval = 1
    var enginneredIrragationReasearchTime: TimeInterval = 1
    var beginningOfPotteryResearchTime: TimeInterval = 1
    var  pottersWheelResearchTime: TimeInterval = 1
    var  brickResearchTime: TimeInterval = 1
    var  beginningOfBuildingResearchTime: TimeInterval = 1
    var  beginningOfReligionResearchTime: TimeInterval = 1
    var  beginningOfTradeResearchTime: TimeInterval = 1
    var  beginningOfManufactoringResearchTime: TimeInterval = 1
    var  packAnimalsResearchTime: TimeInterval = 1
    var  dugoutCanoeResearchTime: TimeInterval = 1
    var  sailResearchTime: TimeInterval = 1
    var beginningOfMetallurgyResearchTime: TimeInterval = 1
    var  metallurgyResearchTime: TimeInterval = 1
    var bronzeworkingResearchTime: TimeInterval = 10
    var  literacyResearchTime: TimeInterval = 1
    var  numeracyResearchTime: TimeInterval = 1
    var  scienceResearchTime: TimeInterval = 1
    var  physicsResearchTime: TimeInterval = 1
    var  engineeringResearchTime: TimeInterval = 1
    var  legalCodeResearchTime: TimeInterval = 1
    var  seaGoingVesselResearchTime: TimeInterval = 1
    var  chemistryResearchTime: TimeInterval = 1
    var  ironWorkingResearchTime: TimeInterval = 1
    var  oilProductionResearchTime: TimeInterval = 1
    var  plasticProductionResearchTime: TimeInterval = 1
    var  steelProductionResearchTime: TimeInterval = 1
    
    
    // MARK:- cost of resesearch
    
    var oldStoneAgeResearchCost = ResourceCosts(stone: 10, food: 10)// food stone

    var newStoneAgeResearchCost = ResourceCosts(stone: 10, food: 10, wood: 10)  // food,stone, wood
    var quarryResearchCost = ResourceCosts(food: 10, wood: 10, bronze: 10) // food wood bronze
    var beginningOfAgricultureResearchCost = ResourceCosts(stone: 10, food: 10, wood: 10) // food, wood, stone
    var beginningOfAnimalHusbandryResearchCost = ResourceCosts(stone: 10, food: 10, wood: 10) // food, wood, stone
    var beginningOfIrrigationResearchCost = ResourceCosts(stone: 10, food: 10, wood: 10)// food, wood, stone
    var enginneredIrragationReasearchCost = ResourceCosts(stone: 10,food: 10, wood: 10, bronze: 10) // food, wood, stone bronze
    var beginningOfPotteryResearchCost = ResourceCosts(stone: 10, food: 10, wood: 10, clay: 10)// food, wood, bronze, clay
    var pottersWheelResearchCost = ResourceCosts(stone: 10, food: 10, wood: 10, clay: 10, bronze: 10) //food, wood, stone bronze, clay
    var  brickResearchCost = ResourceCosts(stone: 10, food: 10, clay: 10)  // food clay stone
    var  beginningOfBuildingResearchCost = ResourceCosts(stone: 10, food: 10, wood: 10, clay: 10)  // food wood clay stone
    var  beginningOfReligionResearchCost = ResourceCosts(stone: 10, food: 10) // food stone
    var  beginningOfTradeResearchCost = ResourceCosts(food: 10,clay: 10, gold: 10, silver: 10,copper: 10, tin: 10,textiles: 10)// food clay textiles gold silver copper tin
    var  beginningOfManufactoringResearchCost = ResourceCosts(food: 10, clay: 10, textiles: 10) // food clay textiles
    var  packAnimalsResearchCost = ResourceCosts(food: 10) // food
    var  dugoutCanoeResearchCost = ResourceCosts(wood: 10) // wood
    var  sailResearchCost = ResourceCosts(wood: 10, textiles: 10)
    var beginningOfMetallurgyResearchCost = ResourceCosts(gold: 10, silver: 10)  // copper tin silver gold
    var  metallurgyResearchCost = ResourceCosts(copper: 10, tin: 10) // bronze
    var bronzeworkingResearchCost = ResourceCosts(bronze: 10) // bronze
    var  literacyResearchCost = ResourceCosts(wood: 10, clay:10) // wood clay
    var  numeracyResearchCost = ResourceCosts(wood: 10, clay:10) // wood clay
    var  scienceResearchCost = ResourceCosts(gold: 10) // gold
    var  physicsResearchCost = ResourceCosts(gold: 10)// gold
    var  engineeringResearchCost = ResourceCosts(iron: 10, coal:10, power: 10) // iron coal power
    var  legalCodeResearchCost = ResourceCosts(wood: 10, clay:10) // wood clay
    var  seaGoingVesselResearchCost = ResourceCosts(wood: 10, textiles: 10)
    var  chemistryResearchCost  = ResourceCosts(food: 10,wood: 10)  // food wood
    var  ironWorkingResearchCost = ResourceCosts(wood: 10, iron: 10, coal: 10) //wood iron coal
    var  oilProductionResearchCost = ResourceCosts(coal: 10, oil: 10) // oil coal
    var  plasticProductionResearchCost = ResourceCosts(oil: 10)// oil
    var  steelProductionResearchCost = ResourceCosts(iron: 10, coal: 10) // iron coal
    
    // MARK:-scenery
    var numberOfBerrysRandomlyGenerated = 10
    
   
    // MARK:- military units
    
    
    //stoneMaceMan
    var totalHealthPointsStoneMaceManLevel1: Double = 100
    var totalHealthPointsStoneMaceManLevel2: Double = 125
    var totalHealthPointsStoneMaceManLevel3: Double = 150
    var totalHealthPointsStoneMaceManLevel4: Double = 200
    
    var attackSpeedStoneMaceManLevel1: Double = 5
    var attackSpeedStoneMaceManLevel2: Double = 5.5
    var attackSpeedStoneMaceManLevel3: Double = 6
    var attackSpeedStoneMaceManLevel4: Double = 6.5
    
    var rangeStoneMaceMan: Double = 0
    
    var movementSpeedStoneMaceManLevel1: Float = 2.0
    var movementSpeedStoneMaceManLevel2 : Float = 2.5
    var movementSpeedStoneMaceManLevel3 : Float = 3
    var movementSpeedStoneMaceManLevel4 : Float = 3.5
    
    var creationSpeedStoneMaceMan : TimeInterval = 5
    
    var StoneMaceManCost = ResourceCosts(stone: 10, food: 10, wood: 10)
    
    //axman
    var totalHealthPointsAxManLevel1: Double = 100
    var totalHealthPointsAxManLevel2: Double = 125
    var totalHealthPointsAxManLevel3: Double = 150
    var totalHealthPointsAxManLevel4: Double = 200
    
    var attackSpeedAxManLevel1: Double = 5
    var attackSpeedAxManLevel2: Double = 5.5
    var attackSpeedAxManLevel3: Double = 6
    var attackSpeedAxManLevel4: Double = 6.5
    
    var rangeAxMan: Double = 0
    
    var movementSpeedAxManLevel1: Float = 2.0
    var movementSpeedAxManLevel2 : Float = 2.5
    var movementSpeedAxManLevel3 : Float = 3
    var movementSpeedAxManLevel4 : Float = 3.5
    
    var creationSpeedAxMan : TimeInterval = 5
    
    var AxManCost = ResourceCosts(stone: 10, food: 10, wood: 10)
    
    // spearman
    
    var totalHealthPointsSpearManLevel1: Double = 100
    var totalHealthPointsSpearManLevel2: Double = 125
    var totalHealthPointsSpearManLevel3: Double = 150
    var totalHealthPointsSpearManLevel4: Double = 200
    
    var attackSpeedSpearManLevel1: Double = 5
    var attackSpeedSpearManLevel2: Double = 5.5
    var attackSpeedSpearManLevel3: Double = 6
    var attackSpeedSpearManLevel4: Double = 6.5
    
    var rangeSpearMan: Double = 0
    
    var movementSpeedSpearManLevel1: Float = 2.0
    var movementSpeedSpearManLevel2 : Float = 2.5
    var movementSpeedSpearManLevel3 : Float = 3
    var movementSpeedSpearManLevel4 : Float = 3.5
    
    var creationSpeedSpearMan : TimeInterval = 5
    
    var SpearManCost = ResourceCosts(stone: 10, food: 10, wood: 10)
    
    // swordMan
    
    var totalHealthPointsSwordmanLevel1: Double = 100
    var totalHealthPointsSwordmanLevel2: Double = 125
    var totalHealthPointsSwordmanLevel3: Double = 150
    var totalHealthPointsSwordmanLevel4: Double = 200
    
    var attackSpeedSwordmanLevel1: Double = 5
    var attackSpeedSwordmanLevel2: Double = 5.5
    var attackSpeedSwordmanLevel3: Double = 6
    var attackSpeedSwordmanLevel4: Double = 6.5
    
    var rangeSwordMan: Double = 0
    
    var movementSpeedSwordmanLevel1: Float = 2.0
    var movementSpeedSwordmanLevel2 : Float = 2.5
    var movementSpeedSwordmanLevel3 : Float = 3
    var movementSpeedSwordmanLevel4 : Float = 3.5
    
    var creationSpeedSwordman : TimeInterval = 5
    
    var SwordmanCost = ResourceCosts(stone: 10, food: 10, wood: 10)
    
   // javelin
    
    var totalHealthPointsJavelinLevel1: Double = 100
    var totalHealthPointsJavelinLevel2: Double = 125
    var totalHealthPointsJavelinLevel3: Double = 150
    var totalHealthPointsJavelinLevel4: Double = 200
    
    var attackSpeedJavelinLevel1: Double = 5
    var attackSpeedJavelinLevel2: Double = 5.5
    var attackSpeedJavelinLevel3: Double = 6
    var attackSpeedJavelinLevel4: Double = 6.5
    
    var rangeJavelinMan: Double = 0
    
    var movementSpeedJavelinLevel1: Float = 2.0
    var movementSpeedJavelinLevel2 : Float = 2.5
    var movementSpeedJavelinLevel3 : Float = 3
    var movementSpeedJavelinLevel4 : Float = 3.5
    
    var creationSpeedJavelin : TimeInterval = 5
    
    var JavelinCost = ResourceCosts(stone: 10, food: 10, wood: 10)
    
    // slingMan
    
    var totalHealthPointsSlingManLevel1: Double = 100
    var totalHealthPointsSlingManLevel2: Double = 125
    var totalHealthPointsSlingManLevel3: Double = 150
    var totalHealthPointsSlingManLevel4: Double = 200
    
    var attackSpeedSlingManLevel1: Double = 5
    var attackSpeedSlingManLevel2: Double = 5.5
    var attackSpeedSlingManLevel3: Double = 6
    var attackSpeedSlingManLevel4: Double = 6.5
    
    var rangeSlingMan: Double = 0
    
    var movementSpeedSlingManLevel1: Float = 2.0
    var movementSpeedSlingManLevel2 : Float = 2.5
    var movementSpeedSlingManLevel3 : Float = 3
    var movementSpeedSlingManLevel4 : Float = 3.5
    
    var creationSpeedSlingMan : TimeInterval = 5
    
    var SlingManCost = ResourceCosts(stone: 10, food: 10, wood: 10)
    
    // archer
    
    var totalHealthPointsArcherLevel1: Double = 100
    var totalHealthPointsArcherLevel2: Double = 125
    var totalHealthPointsArcherLevel3: Double = 150
    var totalHealthPointsArcherLevel4: Double = 200
    
    var attackSpeedArcherLevel1: Double = 5
    var attackSpeedArcherLevel2: Double = 5.5
    var attackSpeedArcherLevel3: Double = 6
    var attackSpeedArcherLevel4: Double = 6.5
    
    var rangeArcher: Double = 0
    
    var movementSpeedArcherLevel1: Float = 2.0
    var movementSpeedArcherLevel2 : Float = 2.5
    var movementSpeedArcherLevel3 : Float = 3
    var movementSpeedArcherLevel4 : Float = 3.5
    
    var creationSpeedArcher : TimeInterval = 5
    
    var ArcherCost = ResourceCosts(stone: 10, food: 10, wood: 10)
    
    // gastrophete
    
    var totalHealthPointsGastropheteLevel1: Double = 100
    var totalHealthPointsGastropheteLevel2: Double = 125
    var totalHealthPointsGastropheteLevel3: Double = 150
    var totalHealthPointsGastropheteLevel4: Double = 200
    
    var attackSpeedGastropheteLevel1: Double = 5
    var attackSpeedGastropheteLevel2: Double = 5.5
    var attackSpeedGastropheteLevel3: Double = 6
    var attackSpeedGastropheteLevel4: Double = 6.5
    
    var rangeGastrophete: Double = 0
    
    var movementSpeedGastropheteLevel1: Float = 2.0
    var movementSpeedGastropheteLevel2 : Float = 2.5
    var movementSpeedGastropheteLevel3 : Float = 3
    var movementSpeedGastropheteLevel4 : Float = 3.5
    
    var creationSpeedGastrophete : TimeInterval = 5
    
    var GastropheteCost = ResourceCosts(stone: 10, food: 10, wood: 10)
    
    // catapult
    
    var totalHealthPointsCatapultLevel1: Double = 100
    var totalHealthPointsCatapultLevel2: Double = 125
    var totalHealthPointsCatapultLevel3: Double = 150
    var totalHealthPointsCatapultLevel4: Double = 200
    
    var attackSpeedCatapultLevel1: Double = 5
    var attackSpeedCatapultLevel2: Double = 5.5
    var attackSpeedCatapultLevel3: Double = 6
    var attackSpeedCatapultLevel4: Double = 6.5
    
    var rangeCatapult: Double = 0
    
    var movementSpeedCatapultLevel1: Float = 2.0
    var movementSpeedCatapultLevel2 : Float = 2.5
    var movementSpeedCatapultLevel3 : Float = 3
    var movementSpeedCatapultLevel4 : Float = 3.5
    
    var creationSpeedCatapult : TimeInterval = 5
    
    var CatapultCost = ResourceCosts(stone: 10, food: 10, wood: 10)
    
    // MARK:- unit Equipment
    
        // time of research
    
    var timeForHelmetResearchBronze: TimeInterval = 5
    var timeForHelmetResearchIron: TimeInterval = 5
    var timeForHelmetResearchSteel: TimeInterval = 5
    var timeForSpearResearchSmall: TimeInterval = 5
    var timeForSpearResearchMedium: TimeInterval = 5
    var timeForSpearResearchLong: TimeInterval = 5
    var timeForAxResearch: TimeInterval = 5
    var timeForShieldResearchSmall: TimeInterval = 5
    var timeForShieldResearchMedium: TimeInterval = 5
    var timeForShieldResearchLarge: TimeInterval = 5
    var timeForSwordResearchSmall: TimeInterval = 5
    var timeForSwordResearchMedium: TimeInterval = 5
    var timeForSwordResearchLarge: TimeInterval = 5
    var timeForJavelinResearch: TimeInterval = 5
    var timeForSlingResearch: TimeInterval = 5
    var timeForBowResearch: TimeInterval = 5
    var timeForLeatherResearch: TimeInterval = 5
    var timeForChainMailResearch: TimeInterval = 5
    var timeForPlateMailResearch: TimeInterval = 5
    
        // cost for research
    
    var costForHelmetBronzeResearch: ResourceCosts = ResourceCosts(bronze: 10)
    var costForHelmetIronResearch: ResourceCosts = ResourceCosts(iron: 10)
    var costForHelmetSteelResearch: ResourceCosts = ResourceCosts(steel: 10)
    var costForSpearResearchSmall: ResourceCosts = ResourceCosts(stone: 10, wood: 10)
    var costForSpearResearchMedium: ResourceCosts = ResourceCosts(wood: 10, bronze: 10)
    var costForSpearResearchLarge: ResourceCosts = ResourceCosts(wood: 10, iron: 10)
    var costForAxResearch: ResourceCosts = ResourceCosts(wood: 10, bronze: 10)
    var costForShieldResearchSmall: ResourceCosts = ResourceCosts(wood: 10, bronze: 10)
    var costForShieldResearchMedium: ResourceCosts = ResourceCosts(wood: 10)
    var costForShieldResearchLarge: ResourceCosts = ResourceCosts(wood: 10, leather: 10)
    var costForSwordResearchShort: ResourceCosts = ResourceCosts(bronze: 10)
    var costForSwordResearchMedium: ResourceCosts = ResourceCosts(iron: 10)
    var costForSwordResearchLong: ResourceCosts = ResourceCosts(iron: 10)
    var costForJavelinResearch: ResourceCosts = ResourceCosts(stone: 10, wood: 10)
    var costForSlingResearch: ResourceCosts = ResourceCosts(stone: 10, textiles: 10)
    var costForBowtResearch: ResourceCosts = ResourceCosts(wood: 10)
    var costForLeatherResearch: ResourceCosts = ResourceCosts(leather: 10)
    var costForChainMailResearch: ResourceCosts = ResourceCosts(iron: 10)
    var costForPlateMailResearch: ResourceCosts = ResourceCosts(iron: 10)
    
    // MARK: - ATTACK AND DEFENCE MODIFEIRS
    var defenceModifierSpearShort: Double = 1
    var defenceModifierSpearmedium: Double = 2
    var defenceModifierSpearLong: Double = 3
}
 
