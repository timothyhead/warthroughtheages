//
//  Research.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 12/02/2021.
//

import Foundation

//MARK: - THINGS TO DO
// complete research options
// reseearch city
class Research{
    
   var researchedWoodProduction = Bool()
    var researchedClayProduction = Bool()
    var researchedCoalProduction = Bool()
    var researchedIronProduction = Bool()
    var researchedTextiles = Bool()
    var researchedGoldProduction = Bool()
    var researchedSilverProduction = Bool()
    var researchedCopperProduction = Bool()
    var researchedTinProduction = Bool()
    var researchedBronzeProduction = Bool()
    var researchedLeatherWorking = Bool()
    
    var researchedStoneTools = Bool()
    var researchedAnimalHusbandry = Bool()
    var researchedAgriculture = Bool()
    var researchedIrrigation = Bool()
    var researchedPottery = Bool()
    var researchedBrick = Bool()
    var researchedBuilding = Bool()
    var researchedReligion = Bool()
    var researchedTrade = Bool()
    var researchedManufactoring = Bool()
    var researchedPackAnimals = Bool()
    var researchedDugoutCannoes = Bool()
    var researchedSail = Bool()
    var researchedMetallurgy = Bool()
    var researchedLiteracy = Bool()
    var researchedNumeracy = Bool()
    var researchedScience = Bool()
    var researchedPhysics = Bool()
    var researchedEngineering = Bool()
    var researchedLegalCode = Bool()
    var researchedSeaGoingVessel = Bool()
    var researchedChemistry = Bool()
    var researchedIronWorking = Bool()
    var researchedOilProduction = Bool()
    var researchedPlasticProduction = Bool()
    var researchedSteelProduction = Bool()
    
    // resources
    
   
    func researchWoodProduction() {
        if researchedStoneTools {
            researchedWoodProduction = true
        }
    }
    func researchClayProduction() {
        if researchedStoneTools && researchedAnimalHusbandry && researchedAgriculture {
            researchedClayProduction = true
        }
    }
    func researchCoalProduction() {
        if researchedWoodProduction && researchedAnimalHusbandry && researchedAgriculture {
            researchedCoalProduction = true
        }
    }
    func researchIronProduction() {
        if researchedGoldProduction && researchedSilverProduction && researchedCopperProduction && researchedTinProduction && researchedBronzeProduction {
            researchedIronProduction = true
        }
    }
    func researchTextiles() {
        if researchedAgriculture && researchedWoodProduction && researchedAnimalHusbandry {
            researchedTextiles = true
        }
        
    }
    func researchGoldProduction() {
        if researchedAgriculture && researchedWoodProduction && researchedAnimalHusbandry {
            researchedGoldProduction = true
        }
    }
    func researchSilverProduction() {
        if researchedAgriculture && researchedWoodProduction && researchedAnimalHusbandry {
            researchedSilverProduction = true
        }
    }
    func researchCopperProduction() {
        if researchedAgriculture && researchedWoodProduction && researchedAnimalHusbandry {
            researchedCopperProduction = true
        }
    }
    func researchTinProduction() {
        if researchedAgriculture && researchedWoodProduction && researchedAnimalHusbandry {
            researchedTinProduction = true
        }
    }
  func researchBronzeProduction() {
    if researchedAgriculture && researchedWoodProduction && researchedGoldProduction && researchedSilverProduction && researchedTinProduction && researchedCopperProduction && researchedManufactoring {
        researchedBronzeProduction = true
    }
    }
    func researchIronPrduction() {
        if researchedBronzeProduction {
            researchedIronProduction = true
        }
    }
 
    func researchOilProduction() {
        if researchedChemistry {
            researchedOilProduction = true
        }
    }
    func researchPlasticProduction() {
        if researchedOilProduction {
            researchedPlasticProduction = true
        }
    }
    func researchSteelProduction() {
        if researchedIronProduction && researchedCoalProduction {
            researchedSteelProduction = true
        }
    }
    
    // technologies
    
    func researchStoneTools() {
        researchedStoneTools = true
    }
    func researchAnimalHusbandry() {
        if researchedStoneTools {
            researchedAnimalHusbandry = true
        }
    }
    func researchAgriculture() {
        if researchedStoneTools {
            researchedAgriculture = true
        }
    }
    func researchLeatherWorking() {
        if researchedAnimalHusbandry {
            researchedLeatherWorking = true
        }
    }
    func researchIrrigation() {
        if researchedStoneTools && researchedAnimalHusbandry && researchedAgriculture {
            researchedIrrigation = true
        }
    }
    func researchPottery() {
        if researchedClayProduction {
            researchedPottery = true
        }
    }
    func researchBrick() {
        if researchedPottery {
            researchedBrick = true
        }
    }
    func researchBuilding() {
        if researchedBrick {
            researchedBuilding = true
        }
    }
    func researchReligion() {
        if researchedBuilding {
            researchedReligion = true
        }
    }
    func researchTrade() {
        if researchedManufactoring {
            researchedTrade = true
        }
    }
    func researchManufactoring() {
        if researchedStoneTools && researchedAnimalHusbandry && researchedAgriculture {
            researchedManufactoring = true
        }
    }
  
    func researchPackAnimals() {
       if researchedManufactoring {
        researchedPackAnimals = true
        }
    }
    func researchDugoutCannoe() {
        if researchedStoneTools && researchedAnimalHusbandry && researchedAgriculture {
            
        }
    }
    func researchSail() {
        if researchedDugoutCannoes {
            
        }
    }
    
    func researchMetallurgy() {
        if researchedBronzeProduction {
            
        }
    }
    func researchLiteracy() {
        if researchedManufactoring {
            
        }
    }
    func researchNumeracy() {
        if researchedManufactoring {
            
        }
    }
    func researchScience() {
        if researchedLiteracy && researchedNumeracy {
            
        }
    }
    func researchPhysics() {
        if researchedScience {
            
        }
    }
    func researchEnginneering() {
        if researchedPhysics {
            
        }
    }
    func researchLegalCode() {
        if researchedIrrigation {
            
        }
    }
    func researchSeaGoingVessel() {
        if researchedSail {
            
        }
    }
    func researchChemistry() {
        if researchedScience {
            
        }
    }
    func researchIronWorking() {
        if researchedMetallurgy && researchedIronProduction {
            
        }
    }
    
}
