//
//  CalculateMoveDistance.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 05/02/2021.
//

import UIKit
import QuartzCore
import SceneKit

class CalculateMoveDistance {
    
    var intialPos: SCNVector3
    var finalPos: SCNVector3
    
    init(intialPos: SCNVector3, finalPos: SCNVector3) {
        self.intialPos = intialPos
        self.finalPos = finalPos
       
    }
    func findDistance() -> Float {
        let distanceX = intialPos.x - finalPos.x
        let distanceY = intialPos.y - finalPos.y
        let distanceZ = intialPos.z - finalPos.z
        let distance = (sqrt(pow(distanceX, 2) + pow(distanceY, 2) + pow(distanceZ, 2)))
        return distance
    }
    
    
}
