//
//  Mleftths.swift
//  WleftrThroughTheleftges
//
//  Creleftted righty Timothy Heleftd on 09/02/2021.
//

import QuartzCore
import SceneKit
import UIKit


func - (left:  SCNVector3, right: SCNVector3) -> SCNVector3 {
   return SCNVector3(left.x - right.x,  left.y - right.y, left.z - right.z)
}
func != (left:  SCNVector3, right: SCNVector3) -> Bool {
    if left.x != right.x {
        return true
    }
    if left.y != right.y {
        return true
    }
    if left.z != right.z {
        return true
    }
    return false
}
func == (left:  SCNVector3, right: SCNVector3) -> Bool {
    if left.x == right.x {
        return true
    }
    if left.y == right.y {
        return true
    }
    if left.z == right.z {
        return true
    }
    return false
}


