//
//  createFormatioon.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 13/04/2021.
//

import Foundation
import SceneKit

class CreateSquareFormation: SCNNode {
    
    var squareTileGrid = SquareTileGrid()
  
    func createFormation(squareNumber: Int, boundingSphereRadius: CGFloat) {
        squareTileGrid.tileField(squareNumber: squareNumber, boundingSphereRadius: boundingSphereRadius)
     
    }
    func addUnit(unitArray: [SCNNode]) {
        squareTileGrid.position = SCNVector3(3, 4, 1)
       
        var tileArray = [SCNNode]()
        for tile in squareTileGrid.childNodes {
            tileArray.append(tile)
            print("AAAAA \(tile.position)")
        }
        var i = 0
        for unit in unitArray {
        
            DispatchQueue.main.async {
                let pos = tileArray[i].convertPosition(tileArray[i].position, to: nil)
                let action = SCNAction.move(to: pos, duration: 3)
                print("BBBBBB \(tileArray[i].position)")
          
                unit.runAction(action)
                i += 1
            }
           
            
        }
    }
    
}
