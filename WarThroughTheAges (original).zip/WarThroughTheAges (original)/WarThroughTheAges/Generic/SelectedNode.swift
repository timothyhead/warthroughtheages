//
//  SelectedNode.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 02/03/2021.
//

import UIKit
import QuartzCore
import SceneKit

class SelectedNode: SCNNode {
    var selectedNode = SCNNode()
    var previouslySelectedNode = SCNNode()
    
    var node: SCNNode {
get {
   return selectedNode
    }
        set(newValue) {
            previouslySelectedNode = selectedNode
            selectedNode = newValue
           
        }
    }
}

