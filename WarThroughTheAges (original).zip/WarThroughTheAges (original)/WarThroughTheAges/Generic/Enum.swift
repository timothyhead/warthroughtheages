//
//  Enum.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 09/02/2021.
//

import Foundation
//MARK:- THINGS TO DO
// complete CC enum
enum CC: Int {
   case basicUnit = 1
}
