//
//  SCNNodeExtension.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 05/02/2021.
//


import QuartzCore
import SceneKit


extension SCNNode {
    
   @objc func updateDelta(delta:TimeInterval) {
        for obj in childNodes {
            obj.updateDelta(delta: delta)
        }
    }
    
    func reset() {
        for obj in childNodes {
            obj.reset()
        }
    }
    func handleInput() {
        for obj in childNodes {
            obj.handleInput()
        }
    }

    func box(node: SCNNode) -> SCNNode? {
        
    
        let xMin = self.boundingBox.min.x
        let xMax = self.boundingBox.max.x
        let yMin = self.boundingBox.min.y
        let yMax = self.boundingBox.max.y
        let zMin = self.boundingBox.min.z
        let zMax = self.boundingBox.max.z
        let worldMin = convertPosition(SCNVector3(xMin, yMin, zMin), to: node)
        let worldMax = convertPosition(SCNVector3(xMax, yMax, zMax), to: node)
        
        let rangeX = worldMin.x...worldMax.x
    //    let rangeY = worldMin.y...worldMax.y
        let rangeZ = worldMin.z...worldMax.z
        
        let rangeNodeX = node.boundingBox.min.x...node.boundingBox.max.x
        let rangeNodeY = node.boundingBox.min.y...node.boundingBox.max.y
        let rangeNodeZ = node.boundingBox.min.z...node.boundingBox.max.z
        
        if rangeX.overlaps(rangeNodeX) && rangeZ.overlaps(rangeNodeZ)  {
            return node
        }
        return nil
    }
    func box2(node: SCNNode) -> Bool {
        
    
        let xMin = self.boundingBox.min.x
        let xMax = self.boundingBox.max.x
        let yMin = self.boundingBox.min.y
        let yMax = self.boundingBox.max.y
        let zMin = self.boundingBox.min.z
        let zMax = self.boundingBox.max.z
        let worldMin = convertPosition(SCNVector3(xMin, yMin, zMin), to: node)
        let worldMax = convertPosition(SCNVector3(xMax, yMax, zMax), to: node)
        var rangeX: ClosedRange = Float(0.0)...Float(0.0)
        var rangeZ: ClosedRange = Float(0.0)...Float(0.0)
        if worldMin.x < worldMax.x {
        rangeX = worldMin.x...worldMax.x
        } else {
             rangeX = worldMax.x...worldMin.x
        }
        if worldMin.z < worldMax.z {
             rangeZ = worldMin.z...worldMax.z
        } else {
             rangeZ = worldMax.z...worldMin.z
        }
      //  let rangeY = worldMin.y...worldMax.y
       
        
        let rangeNodeX = node.boundingBox.min.x...node.boundingBox.max.x
        let rangeNodeY = node.boundingBox.min.y...node.boundingBox.max.y
        let rangeNodeZ = node.boundingBox.min.z...node.boundingBox.max.z
        
        if rangeX.overlaps(rangeNodeX) && rangeZ.overlaps(rangeNodeZ)  {
            return true
        }
        return false
    }
}
