//
//  Armour.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 05/02/2021.
//

// MARK :- THINGs TO DO
// change enum values
import Foundation

struct Armour {
    enum HelmetType : Double{
        case none = 0
        case bronze = 1
        case iron = 3
        case steel = 5
    }
    enum ArmourType: Double {
        case leather = 1
        case chainmail = 2
        case plateMail = 3
    }
    enum ShieldType: Double {
        case small = 1
        case medium = 2
        case large = 3
    }
    var helmetType: HelmetType
    var armourType: ArmourType?
    var shieldType: ShieldType?
    
    init(helmetType: HelmetType, armourType: ArmourType?, shieldType: ShieldType?) {
        self.helmetType = helmetType
        self.armourType = armourType
        self.shieldType = shieldType
    }
    init() {
        self.init(helmetType: HelmetType.none, armourType: nil, shieldType: nil)
    }
}
