//
//  Arena.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 05/02/2021.
//
//
//import UIKit
//import QuartzCore
//import SceneKit
//
//class Arena: SCNNode {
//    
//    var warrior1 = BasicUnit(health: 100, totalHealth: 100, defence: 50, movementSpeed: 5, attackSpeed: 5, fileNamed: "art.scnassets/ship.scn", modelNamed: "ship", strength: 3, experince: 0, level: 1)
//    var warrior2 = BasicUnit(health: 80, totalHealth: 80, defence: 30, movementSpeed: 4, attackSpeed: 4, fileNamed: "art.scnassets/ship.scn", modelNamed: "ship", strength: 3, experince: 0, level: 1)
//    var lightAndCamera = LightAndCamera()
//    let tileField = TileField()
//   
//    
//    override init() {
//        warrior1.armour.armourType = .leather
//        warrior1.armour.helmetType = .none
//        warrior1.weaponType.type = .stoneMace
//        warrior1.weaponType.damageType = .crushing
//        warrior1.position.y = 2
//        warrior2.armour.armourType = .leather
//        warrior2.armour.helmetType = .none
//        warrior2.weaponType.type = .stoneMace
//        warrior2.weaponType.damageType = .crushing
//        
//        super.init()
//        self.addChildNode(warrior1)
//        self.addChildNode(warrior2)
//        self.addChildNode(lightAndCamera)
//        self.addChildNode(tileField)
//    }
//    
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//    
//    override func updateDelta(delta: TimeInterval) {
//        super.updateDelta(delta: delta)
//        if warrior1.alive() && warrior2.alive() {
//        warrior1.attack(enemy: warrior2)
//        print("w1 \(warrior1.health)")
//        warrior2.attack(enemy: warrior1)
//        print("w2 \(warrior2.health)")
//        if !warrior1.alive() {
//            print("warrior2 won")
//         
//            
//        }
//        if !warrior2.alive() {
//            print("warrior1 won")
//         
//        }
//    }
//    }
//}
