//
//  Cube.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 08/02/2021.
//

import UIKit
import QuartzCore
import SceneKit
// MARK: - THINGS TO DO
// change SCNAction times in moveOnToCenterNearestTile() and updateDelta========
class Cube: SCNNode {
    
    let cube = SCNBox(width: 0.5, height:0.5, length: 0.5, chamferRadius: 0)
    let cubeNode = SCNNode()
    var previousPosition = SCNVector3Zero
    var currentPosition = SCNVector3Zero
    var velocity = SCNVector3Zero
    var currentTile: Tile?
  var previousTile = Tile()
    var nextTile = Tile()
    var newTile = false
    var hasCollided = Bool()
//    var tileIdChange = TileIdChange()
    override init() {
        cube.firstMaterial?.diffuse.contents = UIColor.red
        let cubeNode = SCNNode(geometry: cube)
        super.init()
        self.position = SCNVector3(0, 0, 0.5)
        self.name = "cube"
        self.addChildNode(cubeNode)
        self.physicsBody = SCNPhysicsBody.kinematic()
        self.physicsBody?.categoryBitMask = CC.basicUnit.rawValue
        self.physicsBody?.contactTestBitMask = CC.basicUnit.rawValue
    
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func moveOnToCenterNearestTile() {
        previousTile = findNearestTile()! as! Tile
     let foundTile = findNearestTile()
        if let t = foundTile {
            if velocity == SCNVector3Zero {
            let action = SCNAction.move(to: t.position, duration: 10)
            self.runAction(action)
            }
           
        
        
        }
    }
  private  func findOverLapingTiles() -> [SCNNode] {
        var tiles = [SCNNode]()
        var ovelapingTiles = [SCNNode]()
        tiles.append(contentsOf: GameViewController.world.tileField.childNodes)
        for tile in tiles  {
     let node = box(node: tile)
            if let n = node {
               
                ovelapingTiles.append(n)
            }
          
        }
        return ovelapingTiles
    }
   private func findNearestTile() -> SCNNode? {
        var minx = Float()
        var minz = Float()
        var tile = SCNNode()
      
        for node in  findOverLapingTiles() {
           let x = abs(self.boundingSphere.center.x - node.boundingSphere.center.x)
           let z = abs(self.boundingSphere.center.z - node.boundingSphere.center.z)
            if z < x {
                if minz <= z  {
                    minz = z
                    tile = node
                }
            }
           else if minx <= x {
                minx = x
                tile = node
              
            }
return tile
        }
        return nil
    }
 
 
      
        
    
    override func updateDelta(delta: TimeInterval) {
        super.updateDelta(delta: delta)
        // note previous tile
        
      
       currentTile = findNearestTile() as? Tile
        if let current = currentTile {
            tileId = current.id
        }
        
        // find velocity
        currentPosition = self.position
        velocity = currentPosition - previousPosition
        previousPosition = currentPosition
        if hasCollided {
            let action = SCNAction.move(to: previousTile.position, duration: 5)
            self.runAction(action) {
                self.hasCollided = false
            self.newTile = false
    
            
               
            }
        }
    }
   
   
        var tileId: (Int, Int) = (1000_000, 0) {
            willSet {
                if nextTile != currentTile {
               previousTile = self.nextTile
                
                }
               
            }
            didSet(newValue) {
                if newValue != tileId {
               newTile = true
                    if let current = currentTile {
                    nextTile = current
                    }
                    
                
            }
        }
    }
}
//struct TileIdChange {
//    var tileId: (Int, Int) = (1000_000, 0) {
//        willSet {
//            if GameViewController.world.cube2.nextTile != GameViewController.world.cube2.currentTile {
//            GameViewController.world.cube2.previousTile = GameViewController.world.cube2.nextTile
//            print("B \(GameViewController.world.cube2.currentTile?.id) \(GameViewController.world.cube2.previousTile.id)")
//            }
//
//        }
//        didSet(newValue) {
//            if newValue != tileId {
//                GameViewController.world.cube2.newTile = true
//                if let current = GameViewController.world.cube2.currentTile {
//                GameViewController.world.cube2.nextTile = current
//                }
//
//            }
//        }
//    }
//}

