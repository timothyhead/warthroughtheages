//
//  ResearchUnitUITableViewCell.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 25/03/2021.
//

import UIKit

class ResearchUnitUITableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
