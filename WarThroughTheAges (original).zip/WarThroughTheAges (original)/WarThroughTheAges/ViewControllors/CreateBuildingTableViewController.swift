//
//  CreateBuildingTableViewController.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 11/03/2021.
//

import UIKit
// MARK:- THING TO DO
// in infoButtonTapped set up return functionality for all headers
// finish enum
// finish in info string pop number supported

protocol CreateBuilding: class
{
    func createBuilding(buildingType: BuildingType)
}
enum BuildingType {
    case hut
    case villageHall
}
class CreateBuildingTableViewController: UITableViewController {
    
    
    
    var array = [["Huts halls and castles", "hut", "villageHall"],["Farms and mines ect", "farm", "iron mine"]]
    var cell = CreateBuildingTableViewCell()
    weak var delegate: CreateBuilding?
    var buildingType = BuildingType.hut
    @IBOutlet var createBuildingTableVC: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        createBuildingTableVC.delegate = self
        createBuildingTableVC.dataSource = self
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    @IBAction func infoButtonTapped(_ sender: UIButton) {
        if sender.tag == 0 {
            performSegue(withIdentifier: "unwindToVC", sender: self)
        }
        if sender.tag == 1 {
            if sender.title(for: []) == "info" {
                array[0][1] = "inside hut you can create gatherers, hunters and villagers and supports a population of "
                sender.setTitle("back", for: [])
                tableView.reloadData()
            } else {
                array[0][1] = "hut"
                sender.setTitle("info", for: [])
                buildingType = .hut
                tableView.reloadData()
            }
            
            
        }
        
    }
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return array.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return array[section].count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: "createBuildingCell", for: indexPath) as! CreateBuildingTableViewCell
        cell.infoButton.tag = indexPath.row
        
        cell.textLabel?.text = array[ indexPath.section][indexPath.row]
        if indexPath.row == 0 {
            cell.textLabel?.backgroundColor = UIColor(displayP3Red: 0, green: 1, blue: 0, alpha: 0.2)
            cell.infoButton.setTitle("return", for: [])
        }
        
        
        
        return cell
        
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        delegate?.createBuilding(buildingType: buildingType)
        performSegue(withIdentifier: "unwindToVC", sender: self)
        
        
    }
    
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return  10
        
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 50
        }
        return 30
    }
    
    
}
