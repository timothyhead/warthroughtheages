//
//  researchUnitTableViewController.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 25/03/2021.
//

import UIKit
protocol ResearchUnitDelegete {
    func unitResearch(type: UnitEquipment)
    
}
enum UnitEquipment {
    case none
    case helmetBronze
    case helmetIron
    case helmetSteel
    case spearShort
    case spearMedium
    case spearLong
    case ax
    case shieldSmall
    case shieldMedium
    case shieldLarge
    case swordSmall
    case swordMedium
    case swordLong
    case javelin
    case sling
    case bow
    case leather
    case chainMail
    case platemail
}
class ResearchUnitTableViewController: UITableViewController {
    
    var array = ["Research bronze helmet - protectects against blows from a mace for instance. Needs bronze tech.","Research iron helmet - better protection than a bronze helmet. Needs bronze helmet and iron tech.", "Research steel helmet. Needs iron helmet and steel tech.", "Research small Spear - extend your reach. Needs new stone age tech.", "Research medium spear. Needs small spear and bronze tech.", "Research long spear. Needs medium spear and iron tech.", "Research the ax - chop chop! Needs bronze tech.","Research small shield. Needs new stone age tech and bronze tech.","Research medium shield. Needs small shield."," Research large shield.", "Research short sword - cutting and slashing action. Needs bronze tech.","Research medium sword. Needs short sword.","Research long sword. Needs medium sword.", "Research javelin - throw your spear. Needs spear", "Research the sling - available only to tribal cultures", "Research the bow - a hail of arrows never hurt anyone", "Research leather armour", "Research chainMail", "Research plate Armour"]
    var delegete: ResearchUnitDelegete?
    @IBOutlet var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return array.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "researchUnitIndentifier", for: indexPath)
        
        // Configure the cell...
        cell.textLabel?.text = array[indexPath.row]
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case 0:
            delegete?.unitResearch(type: .helmetBronze)
        case 1:
            delegete?.unitResearch(type: .helmetIron)
        case 2:
            delegete?.unitResearch(type: .helmetSteel)
        case 3:
            delegete?.unitResearch(type: .spearShort)
        case 4:
            delegete?.unitResearch(type: .spearMedium)
        case 5:
            delegete?.unitResearch(type: .spearLong)
        case 6:
            delegete?.unitResearch(type: .ax)
        case 7:
            delegete?.unitResearch(type: .shieldSmall)
        case 8:
            delegete?.unitResearch(type: .shieldMedium)
        case 9:
            delegete?.unitResearch(type: .shieldLarge)
        case 10:
            delegete?.unitResearch(type: .swordSmall)
        case 11:
            delegete?.unitResearch(type: .swordMedium)
        case 12:
            delegete?.unitResearch(type: .swordLong)
        case 13:
            delegete?.unitResearch(type: .javelin)
        case 14:
            delegete?.unitResearch(type: .sling)
        case 15:
            delegete?.unitResearch(type: .bow)
        case 16:
            delegete?.unitResearch(type: .leather)
        case 17:
            delegete?.unitResearch(type: .chainMail)
        case 18:
            delegete?.unitResearch(type: .platemail)
            
            
            
        default:
            break
        }
        performSegue(withIdentifier: "unwindToMyVc", sender: self)
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
