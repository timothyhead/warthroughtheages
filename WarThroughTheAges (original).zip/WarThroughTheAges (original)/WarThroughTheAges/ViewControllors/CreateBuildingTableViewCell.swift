//
//  CreateBuildingTableViewCell.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 12/03/2021.
//

import UIKit

class CreateBuildingTableViewCell: UITableViewCell {

    @IBOutlet weak var infoButton: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        infoButton.center = CGPoint(x: 650, y: 15)
        // Configure the view for the selected state
    }

}
