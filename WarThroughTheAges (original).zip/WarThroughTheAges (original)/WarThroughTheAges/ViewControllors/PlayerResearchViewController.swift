//
//  ViewController.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 22/02/2021.
//

import UIKit
import QuartzCore
import SceneKit
// MARK: - THNGS TO DO
// some of the effects of research are described in the researchLabel funcs
// add text to researchLabelsReligion func - researchLabelText parameter
// add text to researchLabelsPackAnimals func - researchLabelText parameter
// add text to researchLabelsDugoutCanoe func - researchLabelText parameter
// add text to researchLabelsSail func - researchLabelText parameter
// add text to researchLabelsLiteracy func - researchLabelText parameter
// add text to researchLabelsNumeracy func - researchLabelText parameter
enum CurrentlyResearching {
    case none
    case stone
    case agriculture
    case animalHusbandry
    case irrigation
    case pottery
    case brick
    case building
    case religion
    case trade
    case manufactoring
    case packAnimals
    case dugoutCanoe
    case sail
    case metallurgy
    case literacy
    case numeracy
    case science
    case physics
    case engineering
    case legalCode
    case seaGoingVessel
    case chemistry
    case bronzeWorking
    case ironWorking
    case oilProduction
    case plasticProduction
    case steel
}

class PlayerResearchViewController: UIViewController {
    

    var researchStates = GameViewController.world.researchStates
    var currentlyResearching = CurrentlyResearching.none
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    
    @IBOutlet var techLabel: [UILabel]!
    @IBOutlet var researchLabel: [UILabel]!
    @IBOutlet var costLabel: [UILabel]!
    @IBOutlet var timeLabel: [UILabel]!
    @IBOutlet var researchButton: [UIButton]!
    @IBOutlet var researchButtons: [UIButton]!

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        scrollView.center.y = view.center.y
        scrollView.center.x = view.center.x
        scrollView.isScrollEnabled = true
        scrollView.isUserInteractionEnabled = true
        scrollView.isDirectionalLockEnabled = true
        
        contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
        contentView.topAnchor.constraint(equalTo: scrollView.topAnchor).isActive = true
        contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor).isActive = true
        contentView.leftAnchor.constraint(equalTo: scrollView.leftAnchor).isActive = true
        contentView.rightAnchor.constraint(equalTo: scrollView.rightAnchor).isActive = true
        
        if self.researchStates.stone == .none || self.researchStates.stone == .oldStoneAge {
            for  button in self.researchButton {
                if button.tag == 1 {
                    continue
                } else {
                    button.isHidden = true
                }
                
            }
            
        }
        if researchStates.stone == .none {
            for label in techLabel {
                label.isHidden = true
            }
            for label in researchLabel {
                label.isHidden = true
            }
            for label in costLabel {
                label.isHidden = true
            }
            for label in timeLabel {
                label.isHidden = true
            }
            for label in researchButtons {
                label.isHidden = true
            }
        }
        
        
        
        
        
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    @IBAction func backButtonPressed(_ sender: Any) {
        performSegue(withIdentifier: "unwindToTheVcSegue", sender: self)
    }
    @IBAction func researchbuttonsPressed(_ sender: Any) {
        for b in researchButton {
            b.isHidden = false
        }
    
        let button = sender as! UIButton
        if button.tag == 1 {
            for label in techLabel {
                label.isHidden = false
            }
            for label in researchLabel {
                label.isHidden = false
            }
            for label in costLabel {
                label.isHidden = false
            }
            for label in timeLabel {
                label.isHidden = false
            }
            for label in researchButtons {
                label.isHidden = false
            }
            currentlyResearching = .stone
            if researchStates.stone == .none {
                labels(techLabelText: "Research old stone age", researchLabelText: "Allows a hunter", costLabels: &Data.instance.oldStoneAgeResearchCost, time: Data.instance.oldStoneAgeResearchTime)
            } else if researchStates.stone == .oldStoneAge {
                researchLabelsNewStoneAge()
                
            } else if researchStates.stone == .newStoneAge {
                researchLabelsQuarry()
            }
        } else if button.tag == 2 {
            currentlyResearching = .agriculture
            if researchStates.farming == .none {
            researchLabelsAgriculture()
            }
        } else if button.tag == 3 {
            currentlyResearching = .animalHusbandry
            if researchStates.animals == .none {
            researchLabelsAnimalHusbandry()
            }
        } else if button.tag == 4 {
            currentlyResearching = .irrigation
            if researchStates.irrigation == .none {
                researchLabelsBeginningOfIrrigation()
            } else if researchStates.irrigation == .beginningOfIrrigation {
                researchLabelsEngineeredIrrigation()
            }
            
        } else if button.tag == 5 {
            currentlyResearching = .pottery
            if researchStates.pottery
                == .none {
                researchLabelsPottery()
            } else if researchStates.pottery == .beginningOfPottery {
                researchLabelsPottersWheel()
            }
        } else if button.tag == 6 {
            currentlyResearching = .brick
            if researchStates.brick == .none {
            researchLabelsBrick()
            }
        } else if button.tag == 7 {
            currentlyResearching = .building
            if researchStates.building == .none {
            researchLabelsBeginnigOfBuildingResearch()
            }
        } else if button.tag == 8 {
            currentlyResearching = .religion
            if researchStates.religion == .none {
            researchLabelsReligion()
            }
        } else if button.tag == 9 {
            currentlyResearching = .trade
            if researchStates.trade == .none {
            researchLabelsBeginningOfTrade()
            }
        } else if button.tag == 10 {
            currentlyResearching = .manufactoring
            if researchStates.manufactoring == .none {
            researchLabelsBeginningOfManufactoring()
            }
        } else if button.tag == 11 {
            currentlyResearching = .packAnimals
            if researchStates.packAnimals == .none {
            researchLabelsPackAnimals()
            }
        } else if button.tag == 12 {
            currentlyResearching = .dugoutCanoe
            if researchStates.dugoutCanoe == .none {
            researchLabelsDugoutCanoe()
            }
        } else if button.tag == 13 {
            currentlyResearching = .sail
            if researchStates.sail == .none {
            researchLabelsSail()
            }
        } else if button.tag == 14 {
            currentlyResearching = .metallurgy
            if researchStates.metallurgy == .none {
                researchLabelsBeginningsOfMetallurgy()
            } else if researchStates.metallurgy == .beginningOfMetallurgy {
                researchLabelsMetallurgy()
            }
            
        } else if button.tag == 15 {
            currentlyResearching = .bronzeWorking
            if researchStates.bronzeWorking == .none {
                researchLabelsBronze()
            }
        } else if button.tag == 16 {
            currentlyResearching = .ironWorking
            if researchStates.ironWorking == .none {
            researchLabelsIron()
            }
        } else if button.tag == 17 {
            currentlyResearching = .literacy
            if researchStates.literacy == .none {
            researchLabelsLiteracy()
            }
        } else if button.tag == 18 {
            currentlyResearching = .numeracy
            if researchStates.numeracy == .none {
           reseachLabelsNumeracy()
            }
        } else if button.tag == 19 {
            currentlyResearching = .science
            if researchStates.science == .none {
           researchLabelsScience()
            }
        } else if button.tag == 20 {
            currentlyResearching = .physics
            if researchStates.physics == .none {
           researchLabelsPhysics()
            }
        } else if button.tag == 21 {
            currentlyResearching = .engineering
            if researchStates.engineering == .none {
           researchLabelsEnineering()
            }
        } else if button.tag == 22 {
            currentlyResearching = .oilProduction
            if researchStates.oilProduction == .none {
            researchLabelsOilProduction()
            }
        } else if button.tag == 23 {
            currentlyResearching = .plasticProduction
            if researchStates.plasticProduction == .none {
            researchLabelsPlasticProduction()
            }
        } else if button.tag == 24 {
            currentlyResearching = .steel
            if researchStates.steelProduction == .none {
            researchLabelsSteelProduction()
            }
        } else if button.tag == 25 {
            currentlyResearching = .legalCode
            if researchStates.legalCode == .none {
            researchLabelsLegalCode()
            }
        }  else if button.tag == 26 {
            currentlyResearching = .seaGoingVessel
            if researchStates.seaGoingVessel == .none {
            researchLabelsSeaGoingVessel()
            }
        }else if button.tag == 27 {
            currentlyResearching = . chemistry
            if researchStates.chemistry == .none {
            researchLabelsChemistry()
            }
        }
    }
    
    @IBAction func ResearchingButtonPressed(_ sender: UIButton) {
    
        switch currentlyResearching {
        case .none:
            return
        case .stone:
            researchStates.researchStone()
        case .agriculture:
            researchStates.researchAgricultue()
        case .animalHusbandry:
            researchStates.researchAnimalHusbandry()
        case .irrigation:
            researchStates.researchIrrigation()
        case .pottery:
            researchStates.researchPottery()
        case .brick:
            researchStates.researchBrick()
        case .building:
            researchStates.researchBuilding()
        case .religion:
            researchStates.researchReligion()
        case .trade:
            researchStates.researchTrade()
        case .manufactoring:
            researchStates.researchManufactoring()
        case .packAnimals:
            researchStates.researchPackAnimals()
        case .dugoutCanoe:
            researchStates.researchDugoutCanoe()
        case .sail:
            researchStates.researchSail()
        case .metallurgy:
            researchStates.researchMetallurgy()
        case .literacy:
            researchStates.researchLiteracy()
        case .numeracy:
            researchStates.researchNumeracy()
        case .science:
            researchStates.researchScience()
        case .physics:
            researchStates.researchPhysics()
        case .engineering:
            researchStates.researchEngineering()
        case .legalCode:
            researchStates.researchLegalCode()
        case .seaGoingVessel:
            researchStates.researchSeaGoingVessel()
        case .chemistry:
            researchStates.researchChemistry()
        case .bronzeWorking:
            researchStates.researchBronzeWorking()
        case .ironWorking:
            researchStates.researchIronWorking()
        case .oilProduction:
            researchStates.researchOilProduction()
        case . plasticProduction:
            researchStates.researchPlasticProduction()
        case .steel:
            researchStates.researchSteelProduction()
     
        }
        
    }
    func updateDelta(delta: TimeInterval) {
        if self.researchStates.researching || self.researchStates.hasCompletedReseach == false {
                return
            }
            if self.researchStates.hasCompletedReseach == true {
                
            switch self.currentlyResearching {
            case .none:
                return
            case .stone:
                switch  self.researchStates.stone {
                case .oldStoneAge:
                    self.researchLabelsNewStoneAge()
                case .newStoneAge:
                    self.researchLabelsQuarry()
                case .quarry:
                    self.researchLabelsResearched(tech: "STONE")
                default:
                    break
                }
          
            case .agriculture:
                switch self.researchStates.farming {
                case .beginningOfAgriculture:
                    self.researchLabelsResearched(tech: "AGRICULTURE")
                default:
                    break
                }
            case .animalHusbandry:
                switch self.researchStates.animals {
                case .beginningOfAnimalHusbandry:
                    self.researchLabelsResearched(tech: "ANIMAL HUSBANDRY")
                default:
                    break
                }
            case .irrigation:
                switch self.researchStates.irrigation {
                case .beginningOfIrrigation:
                    self.researchLabelsEngineeredIrrigation()
                case .enginneredIrragation:
                    self.researchLabelsResearched(tech: "IRRAGATION")
                default:
                    break
                }
            case .pottery:
                switch self.researchStates.pottery {
                case .beginningOfPottery:
                    self.researchLabelsPottersWheel()
                case .pottersWheel:
                    self.researchLabelsResearched(tech: "POTTERY")
                default:
                    break
                }
            case .brick:
                switch self.researchStates.brick {
                case .brick:
                    self.researchLabelsResearched(tech: "BRICK")
                default:
                    break
                }
            case .building:
                switch self.researchStates.building {
                case .beginningOfBuilding:
                    self.researchLabelsResearched(tech: "BUILDING")
                default:
                    break
                }
            case .religion:
                switch self.researchStates.religion {
                case .beginningOfReligion:
                    self.researchLabelsResearched(tech: "RELIGION")
                default:
                    break
                }
            case .trade:
                switch self.researchStates.trade {
                case .beginningOfTrade:
                    self.researchLabelsResearched(tech: "TRADE")
                default:
                    break
                }
            case .manufactoring:
                switch self.researchStates.manufactoring {
                case .beginningOfManufactoring:
                    self.researchLabelsResearched(tech: "MANUFACTORING")
                default:
                    break
                }
            case .packAnimals:
                switch self.researchStates.packAnimals {
                case .packAnimals:
                    self.researchLabelsResearched(tech: "PACK ANIMALS")
                default:
                    break
                }
            case .dugoutCanoe:
                switch self.researchStates.dugoutCanoe {
                case .dugoutCanoe:
                    self.researchLabelsResearched(tech: "DUGOUT CANOE")
                default:
                    break
                }
            case .sail:
                switch self.researchStates.sail {
                case .sail:
                    self.researchLabelsResearched(tech: "SAIL")
                default:
                    break
                }
            case .metallurgy:
                switch self.researchStates.metallurgy {
                case .beginningOfMetallurgy:
                    self.researchLabelsMetallurgy()
                case .metallurgy:
                    self.researchLabelsResearched(tech: "METALLURGY")
                default:
                    break
                }
            case .literacy:
                switch self.researchStates.literacy {
                case .literacy:
                    self.researchLabelsResearched(tech: "LITERACY")
                default:
                    break
                }
            
            case .numeracy:
                switch self.researchStates.numeracy {
                case .numeracy:
                    self.researchLabelsResearched(tech: "NUMERACY")
                default:
                    break
                }
            case .science:
                switch self.researchStates.science {
                case .science:
                    self.researchLabelsResearched(tech: "SCIENCE")
                default:
                    break
                }
            case .physics:
                switch self.researchStates.physics {
                case .physics:
                    self.researchLabelsResearched(tech: "PHYSICS")
                default:
                    break
                }
            case .engineering:
                switch self.researchStates.engineering {
                case .engineering:
                    self.researchLabelsResearched(tech: "ENGINEERING")
                default:
                    break
                }
            case .legalCode:
                switch self.researchStates.legalCode {
                case .legalCode:
                    self.researchLabelsResearched(tech: "LEGAL CODE")
                default:
                    break
                }
            case .seaGoingVessel:
                switch self.researchStates.seaGoingVessel {
                case .seaGoingVessel:
                    self.researchLabelsResearched(tech: "SEAGOING VESSELS")
                default:
                    break
                }
            case .chemistry:
                switch self.researchStates.chemistry {
                case .chemistry:
                    self.researchLabelsResearched(tech: "CHEMISTRY")
                default:
                    break
                }
            case .bronzeWorking:
                switch self.researchStates.bronzeWorking {
                case .bronzeworking:
                    self.researchLabelsResearched(tech: "BRONZEWORKING")
                default:
                    break
                }
            case .ironWorking:
                switch self.researchStates.ironWorking {
                case .ironWorking:
                    self.researchLabelsResearched(tech: "IRONWORKING")
                default:
                    break
                }
            case .oilProduction:
                switch self.researchStates.oilProduction {
                case .oilProduction:
                    self.researchLabelsResearched(tech: "OIL PRODUCTION")
                default:
                    break
                }
            case .plasticProduction:
                switch self.researchStates.plasticProduction {
                case .plasticProduction:
                    self.researchLabelsResearched(tech: "PLASTIC PRODUCTION")
                default:
                    break
                }
            case .steel:
                switch self.researchStates.steelProduction {
                case .steelProduction:
                    self.researchLabelsResearched(tech: "STEEL PRODUCTION")
                default:
                    break
                }
            
            }
                self.researchStates.hasCompletedReseach = false
            }
           
            }
        
               
    func labels(techLabelText: String, researchLabelText: String,
                costLabels: inout ResourceCosts,
                time: TimeInterval) {
      
            for label in self.techLabel {
                DispatchQueue.main.async {
                    label.text = techLabelText
                label.isHidden = false
                }
           
        }
            for label in self.researchLabel {
                DispatchQueue.main.async {
            label.numberOfLines = 0
            label.text = researchLabelText
            label.isHidden = false
        }
            }
        
            for label in self.costLabel {
            
                DispatchQueue.main.async {
            label.isHidden = false
            label.text = ""
            label.numberOfLines = 0
                }
            for (key, values) in costLabels.unwrapp() {
                DispatchQueue.main.async {
                label.text! += "Cost \(key) \(values) "
            }
            }
        }
        
            for label in self.timeLabel {
                DispatchQueue.main.async {
            label.text = "Time \(time) seconds"
            label.isHidden = false
                }
        }
        for buuton in researchButtons {
            DispatchQueue.main.async {
            buuton.isHidden = false
            }
        }
    }
    
    
    func labelsResearched(techLabelText: String, researchLabelText: String) {
        for button in researchButton {
        switch currentlyResearching {
        case .stone:
           setTitleToResearched(button: button, number: 1)
        case .agriculture:
        setTitleToResearched(button: button, number: 2)
        case .animalHusbandry:
            setTitleToResearched(button: button, number: 3)
        case .irrigation:
            setTitleToResearched(button: button, number: 4)
        case .pottery:
            setTitleToResearched(button: button, number: 5)
        case .brick:
            setTitleToResearched(button: button, number: 6)
        case .building:
            setTitleToResearched(button: button, number: 7)
        case .religion:
            setTitleToResearched(button: button, number: 8)
        case .trade:
            setTitleToResearched(button: button, number: 9)
        case .manufactoring:
           setTitleToResearched(button: button, number: 10)
        case .packAnimals:
            setTitleToResearched(button: button, number: 11)
        case .dugoutCanoe:
            setTitleToResearched(button: button, number: 12)
        case .sail:
            setTitleToResearched(button: button, number: 13)
        case .metallurgy:
            setTitleToResearched(button: button, number: 14)
        case .literacy:
            setTitleToResearched(button: button, number: 17)
        case .numeracy:
            setTitleToResearched(button: button, number: 18)
        case .science:
            setTitleToResearched(button: button, number: 19)
        case .physics:
            setTitleToResearched(button: button, number: 20)
        case .engineering:
            setTitleToResearched(button: button, number: 21)
        case .legalCode:
            setTitleToResearched(button: button, number: 25)
        case .seaGoingVessel:
            setTitleToResearched(button: button, number: 26)
        case .chemistry:
            setTitleToResearched(button: button, number: 27)
        case .bronzeWorking:
            setTitleToResearched(button: button, number: 15)
        case .ironWorking:
            setTitleToResearched(button: button, number: 16)
        case .oilProduction:
            setTitleToResearched(button: button, number: 22)
        case .plasticProduction:
            setTitleToResearched(button: button, number: 23)
        case .steel:
            setTitleToResearched(button: button, number: 24)
        default:
            break
        }
        }
        for label in techLabel {
            DispatchQueue.main.async {
                label.text = techLabelText
                label.isHidden = false
            }
           
        }
        for label in researchLabel {
            DispatchQueue.main.async {
            label.numberOfLines = 0
            label.text = researchLabelText
            label.isHidden = false
            }
        }
        for label in costLabel {
            DispatchQueue.main.async {
            label.isHidden = true
            }
            }
        for label in timeLabel {
            DispatchQueue.main.async {
            label.isHidden = true
            }
        }
        for button in researchButtons {
            DispatchQueue.main.async {
            button.isHidden = true
            }
        }
   
    }
    
    func setTitleToResearched(button: UIButton, number: Int) {
        DispatchQueue.main.async {
            if button.tag == number {
                button.setTitle("RESEARCHED!", for: [])
        }
      
            
        }
    }
    func researchLabelsNewStoneAge() {
        labels(techLabelText: "Research New Stone Age", researchLabelText: "Develop agriculture and animal husbandry", costLabels: &Data.instance.newStoneAgeResearchCost, time: Data.instance.newStoneAgeResearchTime)
    }
    func researchLabelsQuarry() {
        labels(techLabelText: "Research Quarrring", researchLabelText: "Build with stone", costLabels: &Data.instance.quarryResearchCost,time: Data.instance.quarryResearchTime)
    }
    func researchLabelsAgriculture() {
        labels(techLabelText: "Research Agriculture", researchLabelText: "Build a farm", costLabels: &Data.instance.beginningOfAgricultureResearchCost, time: Data.instance.beginningOfAgricultureResearchTime)
    }
    func researchLabelsAnimalHusbandry() {
        labels(techLabelText: "Research Animal Husbandry", researchLabelText: "Allows pack animals, textiles and farm", costLabels: &Data.instance.beginningOfAnimalHusbandryResearchCost, time: Data.instance.beginningOfAnimalHusbandryResearchTime)
    }
    func researchLabelsBeginningOfIrrigation() {
        labels(techLabelText: "Research Irrigation", researchLabelText: "Increases food production", costLabels: &Data.instance.beginningOfIrrigationResearchCost, time: Data.instance.beginningOfIrrigationResearchTime)
    }
    func researchLabelsEngineeredIrrigation() {
        labels(techLabelText: "Research Irrigation improvements", researchLabelText: "Requires enigineering", costLabels: &Data.instance.enginneredIrragationReasearchCost, time: Data.instance.enginneredIrragationReasearchTime)
    }
    func researchLabelsPottery() {
        labels(techLabelText: "Research pottery", researchLabelText: "Can then research brick", costLabels: &Data.instance.beginningOfPotteryResearchCost , time: Data.instance.beginningOfPotteryResearchTime)
    }
    func researchLabelsPottersWheel() {
        labels(techLabelText: "Research potters wheel", researchLabelText: "Increases trade", costLabels: &Data.instance.pottersWheelResearchCost, time: Data.instance.pottersWheelResearchTime)
    }
    func researchLabelsBrick() {
        labels(techLabelText: "Research Brick", researchLabelText: "Allows brick buildings", costLabels: &Data.instance.brickResearchCost,time: Data.instance.brickResearchTime)
    }
    func researchLabelsBeginnigOfBuildingResearch() {
        labels(techLabelText: "Research Building", researchLabelText: "Allows religion research", costLabels: &Data.instance.beginningOfBuildingResearchCost,time: Data.instance.beginningOfBuildingResearchTime)
    }
    func researchLabelsReligion() {
        labels(techLabelText: "Research Religion", researchLabelText: "", costLabels: &Data.instance.beginningOfReligionResearchCost, time: Data.instance.beginningOfReligionResearchTime)
    }
    func researchLabelsBeginningOfTrade() {
        labels(techLabelText: "Research Trade", researchLabelText: "Increases tech research speed", costLabels: &Data.instance.beginningOfTradeResearchCost, time: Data.instance.beginningOfTradeResearchTime)
    }
    func researchLabelsBeginningOfManufactoring() {
        labels(techLabelText: "Research Manufactoring", researchLabelText: "Allows for metallurgy research", costLabels: &Data.instance.beginningOfManufactoringResearchCost, time: Data.instance.beginningOfManufactoringResearchTime)
    }
    func researchLabelsPackAnimals() {
        labels(techLabelText: "Research Pack Animals", researchLabelText: "", costLabels: &Data.instance.packAnimalsResearchCost, time: Data.instance.packAnimalsResearchTime)
    }
    func researchLabelsDugoutCanoe() {
        labels(techLabelText: "Research Dugout Canoe", researchLabelText: "", costLabels: &Data.instance.dugoutCanoeResearchCost, time: Data.instance.dugoutCanoeResearchTime)
    }
    func researchLabelsSail() {
        labels(techLabelText: "Research Sail", researchLabelText: "", costLabels: &Data.instance.sailResearchCost, time: Data.instance.sailResearchTime)
    }
    func researchLabelsBeginningsOfMetallurgy() {
        labels(techLabelText: "Research Metallurgy", researchLabelText: "work with gold, silver", costLabels: &Data.instance.beginningOfMetallurgyResearchCost, time: Data.instance.beginningOfMetallurgyResearchTime)
    }
    func researchLabelsMetallurgy() {
        labels(techLabelText: "Advance Metallurgy", researchLabelText:"work with copper and tin, work towards bronze making with bronze tools weapons and armour", costLabels: &Data.instance.metallurgyResearchCost, time: Data.instance.metallurgyResearchTime)
    }
    func researchLabelsBronze() {
        labels(techLabelText: "Research Bronze", researchLabelText: "build a bronze helmet and work towards iron working", costLabels: &Data.instance.bronzeworkingResearchCost, time: Data.instance.bronzeworkingResearchTime)
    }
    func researchLabelsIron() {
        labels(techLabelText: "Research Iron Working", researchLabelText: "Make better tools, weapons and armour", costLabels: &Data.instance.ironWorkingResearchCost, time: Data.instance.ironWorkingResearchTime)
    }
    func researchLabelsLiteracy() {
        labels(techLabelText: "Research Literacy", researchLabelText: "", costLabels: &Data.instance.literacyResearchCost, time: Data.instance.literacyResearchTime)
    }
    func reseachLabelsNumeracy() {
        labels(techLabelText: "Research Numeracy", researchLabelText: "", costLabels: &Data.instance.numeracyResearchCost, time: Data.instance.numeracyResearchTime)
    }
    func researchLabelsScience() {
        labels(techLabelText: "Research Science", researchLabelText: "You can then research physics and chemistry", costLabels: &Data.instance.scienceResearchCost, time: Data.instance.scienceResearchTime)
    }
    func researchLabelsPhysics() {
        labels(techLabelText: "Research Physics", researchLabelText: "You can research engineering", costLabels: &Data.instance.engineeringResearchCost, time: Data.instance.engineeringResearchTime)
    }
    func researchLabelsEnineering() {
        labels(techLabelText: "Research Enineering", researchLabelText: "You can research enineered irrigation", costLabels: &Data.instance.engineeringResearchCost, time: Data.instance.engineeringResearchTime)
    }
  func researchLabelsOilProduction() {
        labels(techLabelText: "Research Oil Production", researchLabelText: "Produce plastic", costLabels: &Data.instance.oilProductionResearchCost, time: Data.instance.oilProductionResearchTime)
    }
    func researchLabelsPlasticProduction() {
        labels(techLabelText: "Research Plastic Production", researchLabelText: "", costLabels: &Data.instance.plasticProductionResearchCost, time: Data.instance.plasticProductionResearchTime)
    }
    func researchLabelsSteelProduction() {
        labels(techLabelText: "Research Steel", researchLabelText: "Build better and greater", costLabels: &Data.instance.steelProductionResearchCost, time: Data.instance.steelProductionResearchTime)
    }
    func researchLabelsLegalCode() {
        labels(techLabelText: "Research Legal Code", researchLabelText: "Measure out land for irrigation for instance", costLabels: &Data.instance.legalCodeResearchCost, time: Data.instance.legalCodeResearchTime)
    }
    func researchLabelsSeaGoingVessel() {
        labels(techLabelText: "Research Sea Going Vessel", researchLabelText: "Increases trade", costLabels: &Data.instance.seaGoingVesselResearchCost, time: Data.instance.seaGoingVesselResearchTime)
    }
    func researchLabelsChemistry() {
        labels(techLabelText: "Research Chemistry", researchLabelText: "develop what you started to learn in the kitchen", costLabels: &Data.instance.chemistryResearchCost, time: Data.instance.chemistryResearchTime)
    }
    func researchLabelsResearched(tech: String) {
        labelsResearched(techLabelText: tech, researchLabelText: "RESEARCHED")
    }
}
