//
//  GameViewController.swift
//  WarThroughTheAges
//
//  Created by Timothy Head on 04/02/2021.
//

import UIKit
import QuartzCore
import SceneKit

//MARK:- THINGS TO DO
// give all models a ring under them
// finish chooseVillagerRole calls
class GameViewController: UIViewController, SCNSceneRendererDelegate {
static var world = GameWorld()
    let scene = SCNScene()
    var scnView = SCNView()
    var initialTime = TimeInterval()
    var handleTheTap = HandleTap()
    var unitResearch = StatesResearchUnitsPlayer()
    var vc = PlayerResearchViewController()
 
var tmp = 0
    @IBOutlet weak var views: SCNView!
    override func viewDidLoad() {
        super.viewDidLoad()
     
        // create a new scene
       
        
        // retrieve the SCNView
   
        scnView = self.views!
        // set the scene to the view
        scnView.scene = scene
        
        // allows the user to manipulate the camera
        scnView.allowsCameraControl = true
        
        // show statistics such as fps and timing information
        scnView.showsStatistics = true
        
        // configure the view
        scnView.backgroundColor = UIColor.black
        
        scnView.delegate = self
        
        scnView.isPlaying = true
        
       
        
       
        
       
        
        // add a tap gesture recognizer
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        scnView.addGestureRecognizer(tapGesture)
        
        scene.rootNode.addChildNode(GameViewController.world)
        
        scene.physicsWorld.contactDelegate = self
        
      //  GameViewController.world.cube.moveOnToCenterNearestTile()
        vc  = storyboard?.instantiateViewController(identifier: "playerResearchVC") as! PlayerResearchViewController
       
        
    }
    @IBAction func unwindToVC(unwindSegue: UIStoryboardSegue) {
        
    }
    @IBAction func unwindToThisVc(_ unwindSegue: UIStoryboardSegue) {
    
    }
    
    @IBAction func unwindToTheVc(_ unwindSegue: UIStoryboardSegue) {
     
    }
    
    @IBAction func createBuildingButton(_ sender: UIButton) {
        GameViewController.world.createBuildings()
        present(GameViewController.world.vc, animated: true, completion: nil)
    }
    @IBAction func researchWeaponsAndArmour(_ sender: Any) {
     
    }
    @objc
    func handleTap(_ gestureRecognize: UIGestureRecognizer) {
        // retrieve the SCNView
        let scnView = self.views!
        
        // check what nodes are tapped
        let p = gestureRecognize.location(in: scnView)
        let hitResults = scnView.hitTest(p, options: [:])
        // check that we clicked on at least one object
        if hitResults.count > 0 {
            // retrieved the first clicked object
            let result = hitResults[0]
            print("A \(result.node.name) \(result.node.position)")
            
            handleTheTap.handleTap(result: result, vc: vc)
            if result.node.name == "researchButton" {
                unitResearch.createVC(node: result.node)
                present(unitResearch.vc, animated: true, completion: nil)
            }
            if result.node.name?.contains("researchCenter_player") == true {
               
              show(vc, sender: self)
            }
          
        }
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }
    func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
       
        let time = time
    let delta = time - initialTime
        initialTime = time
        GameViewController.world.updateDelta(delta: TimeInterval(delta))
        if let pointofView = scnView.pointOfView {
            for tile in GameViewController.world.tileField.childNodes {
            let isMaybeVisible = scnView.isNode(tile, insideFrustumOf: pointofView)
                if !isMaybeVisible {
                    tile.isHidden = true
                } else {
                    tile.isHidden = false
                }
        }
            
        unitResearch.updateDelta(delta: TimeInterval(delta))
                GameViewController.world.hutplayer?.updateDelta(delta: delta)
                GameViewController.world.hutplayer2?.updateDelta(delta: delta)
                GameViewController.world.hutplayer?.villager?.updateDelta(delta: delta)
                GameViewController.world.ironMine.updateDelta(delta: delta)
                handleTheTap.updateDelta(delta: delta)
  
          
            self.vc.updateDelta(delta: delta)
            for obj in GameViewController.world.childNodes {
                if obj.name?.contains("spearMan_player_unit") == true {
                   let obj = obj as! SpearManPlayer
                    print(" \(obj.armour.helmetType) \(obj.name) \(obj.armour.shieldType) \(obj.armour.armourType) \(obj.weaponType.type))")
                }
            }
              
            
            
            
        }
        
    }
       

}
